"""
EcoLoop Backend Service
FastAPI REST API with SQLite database, role authorization,
QR verification logic, and AI segregation assistance.
"""

from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List, Optional
import datetime
import uuid
import random

from database import engine, get_db, Base
import models
import schemas

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="EcoLoop API – Smart Waste Collection and Recycling Management",
    description="Municipal environmental platform API connecting citizens, collectors, MRF recyclers, and admins.",
    version="1.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

POINTS_MAP = {
    "Plastic": 15,
    "Paper": 10,
    "Glass": 12,
    "Metal": 25,
    "Organic": 8,
    "Electronic Waste": 40,
    "Hazardous Waste": 20,
    "Mixed Waste": 5,
}

@app.get("/")
def read_root():
    return {
        "system": "EcoLoop Smart Waste Collection & Recycling Management System",
        "status": "online",
        "version": "1.0.0",
        "documentation": "/docs"
    }

# ----------------- AUTH & USERS -----------------
@app.get("/api/users", response_model=List[schemas.UserResponse])
def get_users(db: Session = Depends(get_db)):
    return db.query(models.User).all()

@app.get("/api/users/{user_id}", response_model=schemas.UserResponse)
def get_user(user_id: str, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# ----------------- COLLECTION REQUESTS -----------------
@app.get("/api/requests", response_model=List[schemas.CollectionRequestResponse])
def get_requests(
    status: Optional[str] = None,
    citizen_id: Optional[str] = None,
    collector_id: Optional[str] = None,
    db: Session = Depends(get_db)
):
    query = db.query(models.CollectionRequest)
    if status:
        query = query.filter(models.CollectionRequest.status == status)
    if citizen_id:
        query = query.filter(models.CollectionRequest.citizen_id == citizen_id)
    if collector_id:
        query = query.filter(models.CollectionRequest.collector_id == collector_id)
    return query.order_by(models.CollectionRequest.created_at.desc()).all()

@app.post("/api/requests", response_model=schemas.CollectionRequestResponse)
def create_request(
    req_data: schemas.CollectionRequestCreate,
    citizen_id: str = "user_cit_01",
    db: Session = Depends(get_db)
):
    citizen = db.query(models.User).filter(models.User.id == citizen_id).first()
    if not citizen:
        raise HTTPException(status_code=404, detail="Citizen not found")

    tracking_num = f"ECL-2026-{random.randint(1000, 9999)}"
    token = f"ECOLOOP-{tracking_num}-{str(uuid.uuid4())[:6].upper()}"

    new_req = models.CollectionRequest(
        id=f"req_{int(datetime.datetime.utcnow().timestamp())}",
        tracking_number=tracking_num,
        citizen_id=citizen.id,
        citizen_name=citizen.name,
        citizen_phone=citizen.phone,
        address=req_data.address,
        latitude=req_data.latitude or 12.9716,
        longitude=req_data.longitude or 77.5946,
        waste_category=req_data.waste_category,
        estimated_kg=req_data.estimated_kg,
        preferred_date=req_data.preferred_date,
        time_slot=req_data.time_slot,
        special_instructions=req_data.special_instructions,
        status="Pending",
        qr_code_token=token,
    )
    db.add(new_req)
    db.commit()
    db.refresh(new_req)
    return new_req

@app.put("/api/requests/{request_id}/status")
def update_status(
    request_id: str,
    new_status: str,
    db: Session = Depends(get_db)
):
    req = db.query(models.CollectionRequest).filter(models.CollectionRequest.id == request_id).first()
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    req.status = new_status
    db.commit()
    return {"message": "Status updated successfully", "status": new_status}

@app.put("/api/requests/{request_id}/assign")
def assign_collector(
    request_id: str,
    collector_id: str,
    db: Session = Depends(get_db)
):
    req = db.query(models.CollectionRequest).filter(models.CollectionRequest.id == request_id).first()
    collector = db.query(models.User).filter(models.User.id == collector_id).first()
    if not req or not collector:
        raise HTTPException(status_code=404, detail="Request or collector not found")

    req.collector_id = collector.id
    req.collector_name = collector.name
    req.status = "Assigned"
    db.commit()
    return {"message": f"Assigned to {collector.name}"}

# ----------------- QR VERIFICATION FLOW -----------------
@app.post("/api/verify-qr")
def verify_qr(
    verification: schemas.VerifyQrRequest,
    db: Session = Depends(get_db)
):
    token = verification.qr_token.strip().upper()
    req = db.query(models.CollectionRequest).filter(
        (models.CollectionRequest.qr_code_token == token) |
        (models.CollectionRequest.tracking_number == token) |
        (models.CollectionRequest.id == token)
    ).first()

    if not req:
        raise HTTPException(status_code=404, detail="Invalid QR Code or token unrecognized.")

    if req.status == "Verified":
        raise HTTPException(
            status_code=400,
            detail="Duplicate verification blocked: This collection was already processed and rewarded."
        )

    rate = POINTS_MAP.get(req.waste_category, 10)
    points_earned = int(verification.actual_kg * rate)
    now = datetime.datetime.utcnow()

    # Update request
    req.status = "Verified"
    req.actual_kg = verification.actual_kg
    req.verified_at = now
    req.eco_points_awarded = points_earned

    # Credit Citizen Wallet
    citizen = db.query(models.User).filter(models.User.id == req.citizen_id).first()
    if citizen:
        citizen.eco_points = (citizen.eco_points or 0) + points_earned

    # Add transaction log
    tx = models.EcoPointsTransaction(
        id=f"tx_{int(now.timestamp())}",
        user_id=req.citizen_id,
        type="earned",
        points=points_earned,
        description=f"Verified {verification.actual_kg} kg {req.waste_category} (#{req.tracking_number})",
        request_id=req.id,
        timestamp=now
    )
    db.add(tx)

    db.commit()
    return {
        "success": True,
        "message": f"Verification successful! {points_earned} EcoPoints deposited.",
        "tracking_number": req.tracking_number,
        "points_awarded": points_earned,
        "actual_kg": req.actual_kg
    }

# ----------------- REWARDS & REDEMPTION -----------------
@app.get("/api/rewards")
def get_rewards(db: Session = Depends(get_db)):
    return db.query(models.Reward).all()

@app.post("/api/rewards/redeem")
def redeem_reward(
    payload: schemas.RedeemRewardRequest,
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.id == payload.user_id).first()
    reward = db.query(models.Reward).filter(models.Reward.id == payload.reward_id).first()

    if not user or not reward:
        raise HTTPException(status_code=404, detail="User or reward not found")

    if (user.eco_points or 0) < reward.points_cost:
        raise HTTPException(status_code=400, detail="Insufficient EcoPoints balance")

    if reward.remaining_stock <= 0:
        raise HTTPException(status_code=400, detail="Reward is currently out of stock")

    voucher_code = f"{reward.code_prefix}-{random.randint(100000, 999999)}"
    now = datetime.datetime.utcnow()

    # Deduct user points and stock
    user.eco_points -= reward.points_cost
    reward.remaining_stock -= 1

    redemption = models.RewardRedemption(
        id=f"red_{int(now.timestamp())}",
        user_id=user.id,
        user_name=user.name,
        reward_id=reward.id,
        reward_title=reward.title,
        points_spent=reward.points_cost,
        voucher_code=voucher_code,
        redeemed_at=now,
        status="Active"
    )
    db.add(redemption)
    db.commit()

    return {
        "success": True,
        "voucher_code": voucher_code,
        "remaining_points": user.eco_points,
        "reward_title": reward.title
    }

# ----------------- ANALYTICS & KPIS -----------------
@app.get("/api/analytics/kpis")
def get_kpis(db: Session = Depends(get_db)):
    verified_requests = db.query(models.CollectionRequest).filter(models.CollectionRequest.status == "Verified").all()
    total_kg = sum([r.actual_kg or r.estimated_kg for r in verified_requests])

    co2_saved = round(total_kg * 1.48, 1)
    landfill_m3 = round(total_kg * 0.0018, 3)

    return {
        "total_citizens": db.query(models.User).filter(models.User.role == "citizen").count(),
        "total_collectors": db.query(models.User).filter(models.User.role == "collector").count(),
        "total_centres": db.query(models.RecyclingCentre).count(),
        "total_collected_kg": round(total_kg, 1),
        "total_recycled_kg": round(total_kg * 0.94, 1),
        "co2_avoided_kg": co2_saved,
        "landfill_avoided_m3": landfill_m3
    }
