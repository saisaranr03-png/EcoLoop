"""
EcoLoop Zero-Dependency SQLite Initializer
Uses Python's standard library `sqlite3` module.
Runs without installing any external packages!
"""

import sqlite3
import datetime

def init_sqlite_db():
    conn = sqlite3.connect("ecoloop.db")
    cursor = conn.cursor()

    print("Creating EcoLoop SQLite tables using standard library...")

    # Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        role TEXT NOT NULL,
        phone TEXT,
        address TEXT,
        eco_points INTEGER DEFAULT 0,
        rating REAL DEFAULT 5.0,
        assigned_zone TEXT,
        facility_name TEXT,
        created_at TEXT
    )
    """)

    # Collection Requests Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS collection_requests (
        id TEXT PRIMARY KEY,
        tracking_number TEXT UNIQUE NOT NULL,
        citizen_id TEXT NOT NULL,
        citizen_name TEXT NOT NULL,
        citizen_phone TEXT,
        address TEXT NOT NULL,
        latitude REAL,
        longitude REAL,
        waste_category TEXT NOT NULL,
        estimated_kg REAL NOT NULL,
        actual_kg REAL,
        photo_url TEXT,
        preferred_date TEXT NOT NULL,
        time_slot TEXT NOT NULL,
        special_instructions TEXT,
        status TEXT DEFAULT 'Pending',
        collector_id TEXT,
        collector_name TEXT,
        recycler_id TEXT,
        recycler_name TEXT,
        qr_code_token TEXT UNIQUE NOT NULL,
        eco_points_awarded INTEGER DEFAULT 0,
        created_at TEXT,
        updated_at TEXT,
        verified_at TEXT
    )
    """)

    # Recycling Centres Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS recycling_centres (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        phone TEXT,
        email TEXT,
        open_hours TEXT,
        accepted_categories TEXT,
        current_capacity_kg REAL DEFAULT 0.0,
        max_capacity_kg REAL DEFAULT 10000.0,
        status TEXT DEFAULT 'Open',
        efficiency_rating REAL DEFAULT 98.0,
        facility_type TEXT
    )
    """)

    # Rewards Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS rewards (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        points_cost INTEGER NOT NULL,
        partner_name TEXT NOT NULL,
        description TEXT,
        remaining_stock INTEGER DEFAULT 50,
        code_prefix TEXT NOT NULL
    )
    """)

    # Transactions Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ecopoints_transactions (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        type TEXT NOT NULL,
        points INTEGER NOT NULL,
        description TEXT NOT NULL,
        request_id TEXT,
        timestamp TEXT
    )
    """)

    # Check existing
    cursor.execute("SELECT COUNT(*) FROM users")
    count = cursor.fetchone()[0]
    if count > 0:
        print("Database already contains records.")
        conn.close()
        return

    print("Inserting demonstration records...")
    now = datetime.datetime.utcnow().isoformat()

    users = [
        ("user_cit_01", "Aravind Sharma", "aravind.citizen@ecoloop.org", "citizen", "+91 98450 23411", "42 Orchid Heights, Green Glen Layout, Bangalore", 485, 5.0, "East Zone - Sector 4", None, now),
        ("user_col_01", "Rajesh Kumar", "rajesh.collector@ecoloop.org", "collector", "+91 97312 88720", "Depot 3 Hub, Bangalore", 0, 4.9, "East Zone - Sector 4 & 5", None, now),
        ("user_rec_01", "EcoVision Recovery Hub", "ecovision.recycler@ecoloop.org", "recycler", "+91 80 4122 9000", "Plot 18B, Peenya Industrial Area, Bangalore", 0, 5.0, "Bangalore Metropolitan", "EcoVision Central MRF", now),
        ("user_adm_01", "Dr. Sarah Chen", "admin@ecoloop.org", "admin", "+91 80 2297 5000", "Municipal Directorate, City Hall", 0, 5.0, "All City Sectors", None, now),
    ]
    cursor.executemany("INSERT INTO users VALUES (?,?,?,?,?,?,?,?,?,?,?)", users)

    centres = [
        ("rec_01", "EcoVision Central MRF", "Plot 18B, Peenya Industrial Area Phase 2, Bangalore", 13.0285, 77.5186, "+91 80 4122 9000", "central@ecovisionmrf.org", "Mon - Sat: 08:00 AM - 07:00 PM", "Plastic, Paper, Glass, Metal, Electronic Waste", 8400.0, 15000.0, "Open", 98.4, "MRF (Material Recovery Facility)"),
        ("rec_02", "GreenLeaf Urban Compost Center", "Survey 44, Bellandur Lake Road, Bangalore", 12.9352, 77.6744, "+91 80 2843 1120", "operations@greenleafcompost.in", "Mon - Sun: 06:00 AM - 06:00 PM", "Organic", 5200.0, 8000.0, "Open", 95.8, "Compost Center"),
    ]
    cursor.executemany("INSERT INTO recycling_centres VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", centres)

    requests = [
        ("req_001", "ECL-2026-8912", "user_cit_01", "Aravind Sharma", "+91 98450 23411", "42 Orchid Heights, Bangalore", 12.9298, 77.6712, "Plastic", 5.5, 5.8, None, "2026-11-04", "09:00 AM - 11:00 AM", "Clean washed PET bottles", "Verified", "user_col_01", "Rajesh Kumar", "rec_01", "EcoVision Central MRF", "ECOLOOP-REQ001-SEC998", 87, now, now, now),
        ("req_003", "ECL-2026-9188", "user_cit_01", "Aravind Sharma", "+91 98450 23411", "42 Orchid Heights, Bangalore", 12.9298, 77.6712, "Electronic Waste", 3.5, None, None, "2026-11-06", "11:00 AM - 01:00 PM", "2 PC power supplies", "Accepted", "user_col_01", "Rajesh Kumar", None, None, "ECOLOOP-REQ003-SEC712", 0, now, now, None),
    ]
    cursor.executemany("INSERT INTO collection_requests VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", requests)

    rewards = [
        ("rew_01", "₹250 Organic Grocery Voucher", "Discount Voucher", 200, "Nature Fresh Organic Markets", "Valid across fresh produce", 45, "NF-ECO250"),
        ("rew_02", "EcoLoop Jute Carry Bag Set", "Eco Merchandise", 150, "EcoLoop Sustainability Labs", "Set of 3 washable bags", 30, "JUTE-TRIO"),
    ]
    cursor.executemany("INSERT INTO rewards VALUES (?,?,?,?,?,?,?,?)", rewards)

    conn.commit()
    conn.close()
    print("Zero-dependency SQLite initialization finished: ecoloop.db ready!")

if __name__ == "__main__":
    init_sqlite_db()
