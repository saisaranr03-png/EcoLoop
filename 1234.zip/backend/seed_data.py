"""
EcoLoop Database Seed Script
Populates SQLite ecoloop.db with initial demonstration records
across citizens, route workers, recycling centres, requests, and challenges.
"""

from database import engine, SessionLocal, Base
import models
import datetime

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()

    # Check if already seeded
    if db.query(models.User).first():
        print("Database already seeded with demo records.")
        db.close()
        return

    print("Seeding EcoLoop SQLite database...")

    # 1. Users
    u1 = models.User(
        id="user_cit_01",
        name="Aravind Sharma",
        email="aravind.citizen@ecoloop.org",
        role="citizen",
        phone="+91 98450 23411",
        address="42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore",
        eco_points=485,
        assigned_zone="East Zone - Sector 4"
    )
    u2 = models.User(
        id="user_col_01",
        name="Rajesh Kumar",
        email="rajesh.collector@ecoloop.org",
        role="collector",
        phone="+91 97312 88720",
        address="EcoLoop Municipal Hub Depot 3, Bangalore",
        rating=4.9,
        assigned_zone="East Zone - Sector 4 & 5"
    )
    u3 = models.User(
        id="user_rec_01",
        name="EcoVision Recovery Hub",
        email="ecovision.recycler@ecoloop.org",
        role="recycler",
        phone="+91 80 4122 9000",
        address="Plot 18B, Peenya Industrial Area Phase 2, Bangalore",
        facility_name="EcoVision Recovery Hub - Central MRF",
        assigned_zone="Bangalore Metropolitan Industrial Zone"
    )
    u4 = models.User(
        id="user_adm_01",
        name="Dr. Sarah Chen",
        email="admin@ecoloop.org",
        role="admin",
        phone="+91 80 2297 5000",
        address="Directorate of Municipal Waste Operations, City Hall",
        assigned_zone="All City Sectors"
    )

    db.add_all([u1, u2, u3, u4])

    # 2. Recycling Centres
    c1 = models.RecyclingCentre(
        id="rec_01",
        name="EcoVision Central MRF",
        address="Plot 18B, Peenya Industrial Area Phase 2, Bangalore",
        latitude=13.0285,
        longitude=77.5186,
        phone="+91 80 4122 9000",
        email="central@ecovisionmrf.org",
        open_hours="Mon - Sat: 08:00 AM - 07:00 PM",
        accepted_categories="Plastic, Paper, Glass, Metal, Electronic Waste",
        current_capacity_kg=8400.0,
        max_capacity_kg=15000.0,
        status="Open",
        efficiency_rating=98.4,
        facility_type="MRF (Material Recovery Facility)"
    )
    c2 = models.RecyclingCentre(
        id="rec_02",
        name="GreenLeaf Urban Compost Center",
        address="Survey 44, Bellandur Lake Road, Bangalore",
        latitude=12.9352,
        longitude=77.6744,
        phone="+91 80 2843 1120",
        email="operations@greenleafcompost.in",
        open_hours="Mon - Sun: 06:00 AM - 06:00 PM",
        accepted_categories="Organic",
        current_capacity_kg=5200.0,
        max_capacity_kg=8000.0,
        status="Open",
        efficiency_rating=95.8,
        facility_type="Compost Center"
    )
    db.add_all([c1, c2])

    # 3. Collection Requests
    r1 = models.CollectionRequest(
        id="req_001",
        tracking_number="ECL-2026-8912",
        citizen_id="user_cit_01",
        citizen_name="Aravind Sharma",
        citizen_phone="+91 98450 23411",
        address="42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore",
        latitude=12.9298,
        longitude=77.6712,
        waste_category="Plastic",
        estimated_kg=5.5,
        actual_kg=5.8,
        preferred_date="2026-11-04",
        time_slot="09:00 AM - 11:00 AM",
        special_instructions="Clean washed PET bottles and HDPE containers.",
        status="Verified",
        collector_id="user_col_01",
        collector_name="Rajesh Kumar",
        recycler_id="rec_01",
        recycler_name="EcoVision Central MRF",
        qr_code_token="ECOLOOP-REQ001-SEC998",
        eco_points_awarded=87,
        verified_at=datetime.datetime.utcnow()
    )
    r2 = models.CollectionRequest(
        id="req_003",
        tracking_number="ECL-2026-9188",
        citizen_id="user_cit_01",
        citizen_name="Aravind Sharma",
        citizen_phone="+91 98450 23411",
        address="42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore",
        latitude=12.9298,
        longitude=77.6712,
        waste_category="Electronic Waste",
        estimated_kg=3.5,
        preferred_date="2026-11-06",
        time_slot="11:00 AM - 01:00 PM",
        special_instructions="2 obsolete PC power supplies and charging cables.",
        status="Accepted",
        collector_id="user_col_01",
        collector_name="Rajesh Kumar",
        qr_code_token="ECOLOOP-REQ003-SEC712"
    )
    db.add_all([r1, r2])

    # 4. Rewards
    rew1 = models.Reward(
        id="rew_01",
        title="₹250 Organic Grocery Voucher",
        category="Discount Voucher",
        points_cost=200,
        partner_name="Nature Fresh Organic Markets",
        description="Valid across all fresh produce and sustainable kitchen essentials.",
        remaining_stock=45,
        code_prefix="NF-ECO250"
    )
    rew2 = models.Reward(
        id="rew_02",
        title="EcoLoop Jute Carry Bag Set",
        category="Eco Merchandise",
        points_cost=150,
        partner_name="EcoLoop Sustainability Labs",
        description="Set of 3 washable organic jute shopping totes with reinforced handles.",
        remaining_stock=30,
        code_prefix="JUTE-TRIO"
    )
    db.add_all([rew1, rew2])

    # Commit
    db.commit()
    db.close()
    print("Database seeding completed successfully!")

if __name__ == "__main__":
    seed()
