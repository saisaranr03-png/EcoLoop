"""
EcoLoop Pydantic Validation Schemas
"""

from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

class UserBase(BaseModel):
    name: str
    email: str
    role: str
    phone: Optional[str] = None
    address: Optional[str] = None
    assigned_zone: Optional[str] = None

class UserCreate(UserBase):
    pass

class UserResponse(UserBase):
    id: str
    eco_points: int = 0
    rating: Optional[float] = 5.0
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class CollectionRequestCreate(BaseModel):
    waste_category: str
    estimated_kg: float
    address: str
    preferred_date: str
    time_slot: str
    special_instructions: Optional[str] = None
    latitude: Optional[float] = 12.9716
    longitude: Optional[float] = 77.5946

class CollectionRequestResponse(BaseModel):
    id: str
    tracking_number: str
    citizen_id: str
    citizen_name: str
    citizen_phone: Optional[str] = None
    address: str
    latitude: float
    longitude: float
    waste_category: str
    estimated_kg: float
    actual_kg: Optional[float] = None
    preferred_date: str
    time_slot: str
    special_instructions: Optional[str] = None
    status: str
    collector_id: Optional[str] = None
    collector_name: Optional[str] = None
    qr_code_token: str
    eco_points_awarded: int = 0
    created_at: Optional[datetime] = None
    verified_at: Optional[datetime] = None

    class Config:
        from_attributes = True

class VerifyQrRequest(BaseModel):
    qr_token: str
    actual_kg: float
    collector_notes: Optional[str] = None

class RedeemRewardRequest(BaseModel):
    user_id: str
    reward_id: str
