"""
EcoLoop SQLAlchemy Database Models
Includes Users, Collection Requests, Recycling Centres,
Rewards, Transactions, and Challenges.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, index=True, nullable=False)
    role = Column(String, nullable=False) # 'citizen', 'collector', 'recycler', 'admin'
    phone = Column(String)
    address = Column(String)
    eco_points = Column(Integer, default=0)
    rating = Column(Float, default=5.0)
    assigned_zone = Column(String)
    facility_name = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    requests = relationship("CollectionRequest", back_populates="citizen", foreign_keys="CollectionRequest.citizen_id")
    transactions = relationship("EcoPointsTransaction", back_populates="user")
    redemptions = relationship("RewardRedemption", back_populates="user")

class CollectionRequest(Base):
    __tablename__ = "collection_requests"

    id = Column(String, primary_key=True, index=True)
    tracking_number = Column(String, unique=True, index=True, nullable=False)
    citizen_id = Column(String, ForeignKey("users.id"), nullable=False)
    citizen_name = Column(String, nullable=False)
    citizen_phone = Column(String)
    address = Column(String, nullable=False)
    latitude = Column(Float, default=12.9716)
    longitude = Column(Float, default=77.5946)
    waste_category = Column(String, nullable=False) # Plastic, Paper, Glass, Metal, Organic, E-Waste, Hazardous
    estimated_kg = Column(Float, nullable=False)
    actual_kg = Column(Float, nullable=True)
    photo_url = Column(String, nullable=True)
    preferred_date = Column(String, nullable=False)
    time_slot = Column(String, nullable=False)
    special_instructions = Column(Text, nullable=True)
    status = Column(String, default="Pending") # Pending, Assigned, Accepted, On the Way, Collected, Verified
    collector_id = Column(String, nullable=True)
    collector_name = Column(String, nullable=True)
    recycler_id = Column(String, nullable=True)
    recycler_name = Column(String, nullable=True)
    qr_code_token = Column(String, unique=True, index=True, nullable=False)
    eco_points_awarded = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    verified_at = Column(DateTime, nullable=True)

    citizen = relationship("User", foreign_keys=[citizen_id], back_populates="requests")

class RecyclingCentre(Base):
    __tablename__ = "recycling_centres"

    id = Column(String, primary_key=True, index=True)
    name = Column(String, nullable=False)
    address = Column(String, nullable=False)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    phone = Column(String)
    email = Column(String)
    open_hours = Column(String)
    accepted_categories = Column(String) # JSON or comma-separated string
    current_capacity_kg = Column(Float, default=0.0)
    max_capacity_kg = Column(Float, default=10000.0)
    status = Column(String, default="Open")
    efficiency_rating = Column(Float, default=98.0)
    facility_type = Column(String, default="Material Recovery Facility (MRF)")

class Reward(Base):
    __tablename__ = "rewards"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)
    points_cost = Column(Integer, nullable=False)
    partner_name = Column(String, nullable=False)
    description = Column(Text)
    remaining_stock = Column(Integer, default=50)
    code_prefix = Column(String, nullable=False)

class RewardRedemption(Base):
    __tablename__ = "reward_redemptions"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    user_name = Column(String, nullable=False)
    reward_id = Column(String, nullable=False)
    reward_title = Column(String, nullable=False)
    points_spent = Column(Integer, nullable=False)
    voucher_code = Column(String, unique=True, index=True, nullable=False)
    redeemed_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="Active")

    user = relationship("User", back_populates="redemptions")

class EcoPointsTransaction(Base):
    __tablename__ = "ecopoints_transactions"

    id = Column(String, primary_key=True, index=True)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    type = Column(String, nullable=False) # 'earned', 'redeemed'
    points = Column(Integer, nullable=False)
    description = Column(String, nullable=False)
    request_id = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="transactions")

class CommunityChallenge(Base):
    __tablename__ = "community_challenges"

    id = Column(String, primary_key=True, index=True)
    title = Column(String, nullable=False)
    category = Column(String, nullable=False)
    target_kg = Column(Float, nullable=False)
    current_kg = Column(Float, default=0.0)
    participants_count = Column(Integer, default=0)
    reward_points = Column(Integer, default=100)
    deadline = Column(String, nullable=False)
    badge_name = Column(String, nullable=False)
    description = Column(Text)
