# EcoLoop – Smart Waste Collection and Recycling Management System

A centralized, full-stack municipal environmental technology platform connecting **Citizens**, **Waste Collection Workers**, **Recycling Centres (MRFs)**, and **City Administrators** into a closed-loop circular economy.

---

## 1. System Architecture & Roles

```
                      ┌──────────────────────────────────────┐
                      │          EcoLoop Web App             │
                      │  (React 19 + Tailwind + Leaflet)     │
                      └──────────────────┬───────────────────┘
                                         │
                 ┌───────────────────────┴───────────────────────┐
                 │                                               │
      ┌──────────▼──────────┐                         ┌──────────▼──────────┐
      │  FastAPI Backend    │                         │  Client-Side Store  │
      │  (Python / SQLite)  │                         │  (Instant Offline)  │
      └──────────┬──────────┘                         └─────────────────────┘
                 │
       ┌─────────▼─────────┐
       │   SQLite Database │
       │  (ecoloop.db)     │
       └───────────────────┘
```

The system provides 4 dedicated, role-specific experiences:

1. **Citizen Portal (`aravind.citizen@ecoloop.org`)**:
   - Schedule on-demand smart waste pickups across 8 material categories.
   - Live optical AI waste classification with transparent heuristics.
   - Interactive AI Segregation Assistant with 50+ item household waste guide.
   - Real-time pickup status tracker with downloadable doorstep QR verification code.
   - EcoPoints Green Wallet with instant voucher code redemption.
   - Environmental Impact Calculator (landfill volume, CO₂e, water, trees saved).
   - Interactive Leaflet map to locate authorized municipal recycling depots.
   - Community challenges (Zero Plastic Month, Cardboard Recovery Sprint).

2. **Collector Route Operator (`rajesh.collector@ecoloop.org`)**:
   - Assigned municipal pickup schedule and stop queue.
   - Turn-by-turn route overview with GPS Leaflet coordinates.
   - Doorstep QR Code Scanner & Digital Scale weight recorder.
   - Anti-fraud verification: points are awarded only upon physical weight confirmation.
   - Route status updates: *Assigned* → *Accepted* → *On the Way* → *Verified*.

3. **Recycling Centre Facility Manager (`ecovision.recycler@ecoloop.org`)**:
   - Material recovery facility (MRF) inventory and storage capacity tracking.
   - Multi-stage bulk batch pipeline (*Intake* → *Optical Sorting* → *Shredding/Baling* → *Reprocessed*).
   - Gate configuration: toggle accepted material categories and check contamination rates.

4. **Municipal Administrator (`admin@ecoloop.org`)**:
   - Citywide KPI command center (total diverted kg, active citizens, EV fleet efficiency).
   - One-click collector dispatch and assignment to pending resident requests.
   - Waste category distribution charts and greenhouse gas reduction analytics.
   - User, route staff, and MRF facility registries.
   - One-click CSV Audit Report export for municipal green compliance.

---

## 2. Demo User Credentials

Use the top-right **Role Switcher** in the web interface for 1-click exploration, or use these credentials:

| Role | Name | Email | Default Zone |
| :--- | :--- | :--- | :--- |
| **Citizen** | Aravind Sharma | `aravind.citizen@ecoloop.org` | East Zone - Sector 4 |
| **Collector** | Rajesh Kumar | `rajesh.collector@ecoloop.org` | East Zone - Sector 4 & 5 (Truck #KA-05-ET-4912) |
| **Recycling Centre** | EcoVision Hub | `ecovision.recycler@ecoloop.org` | Peenya Industrial Area Phase 2 |
| **Administrator** | Dr. Sarah Chen | `admin@ecoloop.org` | Municipal Directorate / City Hall |

---

## 3. Seven Core Innovative Features

1. **Smart Waste Identification**: Optical analysis with instant polymer/material recognition, recommended bin classification, and contamination safety guidelines.
2. **AI Waste Segregation Assistant**: Natural language Q&A for complex household disposal queries (batteries, greasy pizza boxes, CFL tubes) backed by a 50+ item searchable encyclopedia.
3. **EcoPoints & Gamified Rewards**: Tamper-proof digital points awarded strictly after collector doorstep weighing, redeemable for organic grocery discounts, insulated flasks, and tree planting.
4. **Environmental Impact Calculator**: Uses US EPA WARM life-cycle assessment conversion factors (~1.48 kg CO₂e avoided per kg recycled, 0.0018 m³ landfill saved).
5. **Smart Pickup Scheduling**: Intuitive multi-step booking with category selection, estimated weight, date/time slot, and address mapping.
6. **QR-Based Collection Verification**: Unique QR code generated for every booking; collector scans and registers measured scale weight to deposit points without duplication.
7. **Community Challenges**: Neighbourhood goals with live progress bars, community leaderboards, and bonus points.

---

## 4. Local VS Code Execution Instructions

### A. Running the Web Application (Interactive UI + Client Store)

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev
```

Open your browser to: **`http://localhost:3000`**

---

### B. Running the Python FastAPI Backend (SQLite)

```bash
# 1. Navigate to backend directory
cd backend

# 2. Create and activate a Python virtual environment (optional but recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# 3. Install required Python packages
pip install -r requirements.txt

# 4. Initialize and seed SQLite database
python3 seed_data.py

# 5. Start the FastAPI server with live reloading
uvicorn main:app --reload --port 8000
```

- API Base URL: **`http://localhost:8000`**
- Interactive Swagger API Docs: **`http://localhost:8000/docs`**
- Redoc Documentation: **`http://localhost:8000/redoc`**

---

## 5. REST API Endpoints Overview

- `GET /api/requests` - Retrieve all collection requests (supports `status`, `citizen_id`, `collector_id` filters)
- `POST /api/requests` - Schedule a new waste pickup
- `PUT /api/requests/{id}/status` - Update status (*Accepted*, *On the Way*, *Verified*)
- `PUT /api/requests/{id}/assign` - Dispatch collector to a request
- `POST /api/verify-qr` - Collector scans QR code, records verified kg, credits citizen EcoPoints
- `GET /api/rewards` - List available catalog vouchers
- `POST /api/rewards/redeem` - Deduct EcoPoints and issue voucher code
- `GET /api/analytics/kpis` - Aggregate municipal solid waste metrics
- `GET /api/users` - Registered system stakeholders

---

## 6. College Project Exhibition & Viva Checklist

- [x] Functional registration and role-based access control.
- [x] Citizens submit collection requests with categories, photos, and time slots.
- [x] Requests persist in database with unique tracking IDs.
- [x] Administrators can assign collectors with 1 click.
- [x] Collectors can update status to *On the Way* and navigate to addresses.
- [x] QR code verification works with real scale weight inputs.
- [x] EcoPoints wallet credits instantly and anti-fraud rules prevent double redemption.
- [x] Leaflet and OpenStreetMap render real recycling centers and pickup route polylines.
- [x] Transparent rule-based AI computer vision and segregation chatbot.
- [x] CSV audit export and environmental calculations based on EPA WARM conversion factors.
