/**
 * Schedule Waste Pickup Modal for Citizens
 * Multi-step booking form with category selection, estimated weight,
 * time-slot scheduling, and live EcoPoints calculation.
 */

import React, { useState } from 'react';
import { WasteCategory } from '../types';
import { store, CATEGORY_POINTS_PER_KG } from '../services/store';
import { X, Calendar, Clock, MapPin, Sparkles, CheckCircle2 } from 'lucide-react';

interface SchedulePickupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const CATEGORIES: { label: WasteCategory; icon: string; rate: number; hint: string }[] = [
  { label: 'Plastic', icon: '🧴', rate: 15, hint: 'PET Bottles, HDPE Milk Jugs, Containers' },
  { label: 'Paper', icon: '📦', rate: 10, hint: 'Cardboard, Books, Cartons, Office Paper' },
  { label: 'Glass', icon: '🫙', rate: 12, hint: 'Sauce Jars, Clear & Amber Beverage Bottles' },
  { label: 'Metal', icon: '🥫', rate: 25, hint: 'Soda Cans, Steel Food Tins, Scrap Wire' },
  { label: 'Organic', icon: '🥬', rate: 8, hint: 'Raw Kitchen Scraps, Peels, Garden Twigs' },
  { label: 'Electronic Waste', icon: '🔌', rate: 40, hint: 'Gadgets, Cables, Adapters, Chargers' },
  { label: 'Hazardous Waste', icon: '⚠️', rate: 20, hint: 'Batteries, Paints, Fluorescent Tubes' },
  { label: 'Mixed Waste', icon: '🗑️', rate: 5, hint: 'Non-segregated General Dry Refuse' },
];

export const SchedulePickupModal: React.FC<SchedulePickupModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const currentUser = store.getCurrentUser();
  const [category, setCategory] = useState<WasteCategory>('Plastic');
  const [estimatedKg, setEstimatedKg] = useState('4.5');
  const [address, setAddress] = useState(currentUser.address || '42 Orchid Heights, Bangalore');
  const [preferredDate, setPreferredDate] = useState(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [timeSlot, setTimeSlot] = useState('09:00 AM - 11:00 AM');
  const [instructions, setInstructions] = useState('Rinsed clean in two tied reusable bags at front door.');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedRequest, setSubmittedRequest] = useState<any>(null);

  if (!isOpen) return null;

  const currentRate = CATEGORY_POINTS_PER_KG[category] || 10;
  const kgNumber = parseFloat(estimatedKg) || 0;
  const estimatedPoints = Math.round(kgNumber * currentRate);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      const newReq = store.createRequest({
        wasteCategory: category,
        estimatedKg: kgNumber,
        address,
        preferredDate,
        timeSlot,
        specialInstructions: instructions,
      });

      setIsSubmitting(false);
      setSubmittedRequest(newReq);
      onSuccess?.();
    }, 450);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95 duration-150 my-6">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
          <div>
            <h3 className="font-bold text-neutral-900 text-base">Schedule Smart Waste Pickup</h3>
            <p className="text-xs text-neutral-500">Doorstep municipal collection with verified EcoPoints rewards</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submittedRequest ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <div>
              <h4 className="text-base font-bold text-neutral-900">Pickup Scheduled Successfully!</h4>
              <p className="text-xs text-neutral-500 mt-1">
                Tracking ID: <span className="font-mono font-semibold text-neutral-800">#{submittedRequest.trackingNumber}</span>
              </p>
            </div>
            <div className="p-3 bg-neutral-50 rounded-xl text-left text-xs space-y-2 border border-neutral-100 max-w-sm mx-auto">
              <div className="flex justify-between">
                <span className="text-neutral-500">Waste Material:</span>
                <span className="font-semibold text-neutral-800">{submittedRequest.wasteCategory} ({submittedRequest.estimatedKg} kg)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-500">Pickup Window:</span>
                <span className="text-neutral-800">{submittedRequest.preferredDate} · {submittedRequest.timeSlot}</span>
              </div>
              <div className="flex justify-between text-emerald-700 font-semibold pt-1 border-t border-neutral-200">
                <span>Estimated Reward:</span>
                <span>~{estimatedPoints} EcoPoints</span>
              </div>
            </div>
            <p className="text-[11px] text-neutral-400">
              A collector will be assigned. You can view and present your pickup QR code anytime in your dashboard.
            </p>
            <button
              onClick={() => {
                setSubmittedRequest(null);
                onClose();
              }}
              className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors"
            >
              Back to Dashboard
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-4 space-y-4">
            {/* Category Select Grid */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-2">
                1. Select Waste Category
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {CATEGORIES.map(cat => (
                  <button
                    key={cat.label}
                    type="button"
                    onClick={() => setCategory(cat.label)}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      category === cat.label
                        ? 'bg-emerald-50/80 border-emerald-600 ring-1 ring-emerald-600'
                        : 'bg-white border-neutral-200 hover:bg-neutral-50'
                    }`}
                  >
                    <div className="text-xl mb-1">{cat.icon}</div>
                    <div className="font-semibold text-xs text-neutral-800">{cat.label}</div>
                    <div className="text-[10px] text-emerald-700 font-medium">+{cat.rate} pts/kg</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Estimated Weight & Live Reward Calculator */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1">
                  2. Approximate Weight (KG)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="0.5"
                    min="0.5"
                    max="100"
                    value={estimatedKg}
                    onChange={e => setEstimatedKg(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                    required
                  />
                  <span className="absolute right-3 top-2.5 text-xs text-neutral-400">kg</span>
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-emerald-800 font-medium block">Projected Reward</span>
                  <span className="text-base font-extrabold text-emerald-700 font-mono">+{estimatedPoints}</span>
                  <span className="text-[10px] text-emerald-600 ml-1">EcoPoints</span>
                </div>
                <div className="w-8 h-8 rounded-full bg-emerald-600/10 text-emerald-700 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Date & Time Slot */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-neutral-400" /> Preferred Date
                </label>
                <input
                  type="date"
                  value={preferredDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={e => setPreferredDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-neutral-700 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-neutral-400" /> Time Slot
                </label>
                <select
                  value={timeSlot}
                  onChange={e => setTimeSlot(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-white"
                >
                  <option value="07:00 AM - 09:00 AM">Morning Early (07:00 AM - 09:00 AM)</option>
                  <option value="09:00 AM - 11:00 AM">Morning Regular (09:00 AM - 11:00 AM)</option>
                  <option value="11:00 AM - 01:00 PM">Midday (11:00 AM - 01:00 PM)</option>
                  <option value="02:00 PM - 04:00 PM">Afternoon (02:00 PM - 04:00 PM)</option>
                  <option value="04:00 PM - 06:00 PM">Evening (04:00 PM - 06:00 PM)</option>
                </select>
              </div>
            </div>

            {/* Address */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1 flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-neutral-400" /> Collection Address
              </label>
              <input
                type="text"
                value={address}
                onChange={e => setAddress(e.target.value)}
                placeholder="Apartment, Street, Landmark, Bangalore"
                className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
                required
              />
            </div>

            {/* Special Instructions */}
            <div>
              <label className="block text-xs font-semibold text-neutral-700 mb-1">
                Instructions for Waste Collector (Optional)
              </label>
              <input
                type="text"
                value={instructions}
                onChange={e => setInstructions(e.target.value)}
                placeholder="e.g. In blue bags next to security guard gate"
                className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
              />
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2 px-3 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-lg transition-colors shadow-xs"
              >
                {isSubmitting ? 'Scheduling...' : 'Confirm Pickup Request'}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
