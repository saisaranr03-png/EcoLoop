/**
 * Waste Collector Dashboard
 * Dedicated operational portal for municipal collection field staff:
 * route dispatching, daily pickup schedule, address navigation,
 * doorstep QR scale verification, and performance logs.
 */

import React, { useState, useEffect } from 'react';
import { store } from '../services/store';
import { CollectionRequest } from '../types';
import { LeafletMap } from './LeafletMap';
import { QrScannerModal } from './QrScannerModal';
import {
  Truck,
  MapPin,
  Phone,
  QrCode,
  CheckCircle2,
  Clock,
  Compass,
  Scale,
  Navigation,
  Calendar,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';

export const CollectorDashboard: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const [allRequests, setAllRequests] = useState<CollectionRequest[]>(store.getRequests());
  const [selectedRequest, setSelectedRequest] = useState<CollectionRequest | null>(null);
  const [isQrScannerOpen, setIsQrScannerOpen] = useState(false);
  const [activeFilter, setActiveFilter] = useState<'all' | 'assigned' | 'active' | 'completed'>('assigned');

  useEffect(() => {
    const unsub = store.subscribe(() => {
      setAllRequests(store.getRequests());
    });
    return unsub;
  }, []);

  // Filter requests
  const myAssignedRequests = allRequests.filter(
    r => r.collectorId === currentUser.id || !r.collectorId
  );

  const completedRequests = allRequests.filter(
    r => r.status === 'Verified' && r.collectorId === currentUser.id
  );

  const activeRouteStops = myAssignedRequests.filter(
    r => r.status === 'Assigned' || r.status === 'Accepted' || r.status === 'On the Way'
  );

  const totalCollectedTodayKg = completedRequests.reduce(
    (sum, r) => sum + (r.actualKg || r.estimatedKg),
    0
  );

  const handleUpdateStatus = (
    requestId: string,
    newStatus: 'Accepted' | 'On the Way' | 'Collected' | 'Cancelled'
  ) => {
    store.updateRequestStatus(requestId, newStatus);
  };

  const handleAcceptAssignment = (req: CollectionRequest) => {
    store.assignCollector(req.id, currentUser.id, currentUser.name);
    store.updateRequestStatus(req.id, 'Accepted');
  };

  return (
    <div className="space-y-6">
      {/* Top Profile & Operations Status Header */}
      <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-neutral-900">
              {currentUser.name} · Route Operator
            </h1>
            <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 py-0.5 px-2.5 rounded-full border border-emerald-200">
              Collector Staff
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Zone: <span className="font-semibold text-neutral-800">{currentUser.assignedZone}</span> ·
            Truck #KA-05-ET-4912 (Zero-Emission EV Compactor) · Rating: ★ {currentUser.rating || 4.9}
          </p>
        </div>

        <button
          onClick={() => {
            setSelectedRequest(null);
            setIsQrScannerOpen(true);
          }}
          className="flex items-center gap-2 py-2 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
        >
          <QrCode className="w-4 h-4" /> Scan Citizen Doorstep QR
        </button>
      </div>

      {/* KPI Performance Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Stops on Route</span>
            <Truck className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {activeRouteStops.length}
            </span>
            <span className="text-xs text-neutral-500 font-medium">pending stops</span>
          </div>
          <span className="text-[10px] text-blue-700 mt-0.5 block">East Zone Route Sector 4</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Today's Weight Weighed</span>
            <Scale className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-emerald-700">
              {totalCollectedTodayKg.toFixed(1)}
            </span>
            <span className="text-xs text-neutral-500 font-medium">kg collected</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-0.5 block">Delivered to EcoVision MRF</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Verified Pickups</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {completedRequests.length}
            </span>
            <span className="text-xs text-neutral-500 font-medium">households</span>
          </div>
          <span className="text-[10px] text-neutral-400 mt-0.5 block">100% digital QR matched</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Operator Rating</span>
            <TrendingUp className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">4.92</span>
            <span className="text-xs text-neutral-500 font-medium">/ 5.0</span>
          </div>
          <span className="text-[10px] text-amber-700 mt-0.5 block">Top 5% City Efficiency</span>
        </div>
      </div>

      {/* Route Map & Active Stops View */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Pickup Stops Queue */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs flex items-center justify-between">
            <h3 className="font-bold text-xs text-neutral-900">Assigned Municipal Collection Queue</h3>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setActiveFilter('assigned')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  activeFilter === 'assigned'
                    ? 'bg-emerald-600 text-white'
                    : 'text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                Pending & Active ({activeRouteStops.length})
              </button>
              <button
                onClick={() => setActiveFilter('completed')}
                className={`px-2.5 py-1 text-xs rounded-md font-medium transition-colors ${
                  activeFilter === 'completed'
                    ? 'bg-emerald-600 text-white'
                    : 'text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                Completed Today ({completedRequests.length})
              </button>
            </div>
          </div>

          {/* Request Cards */}
          <div className="space-y-3">
            {(activeFilter === 'assigned' ? activeRouteStops : completedRequests).map(req => {
              const isVerified = req.status === 'Verified';

              return (
                <div
                  key={req.id}
                  className="bg-white rounded-2xl p-5 border border-neutral-200 shadow-xs hover:border-emerald-300 transition-all space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-neutral-100">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-xl bg-neutral-100 flex items-center justify-center font-bold text-xs font-mono text-neutral-700">
                        📦
                      </div>
                      <div>
                        <span className="font-mono text-xs font-bold text-neutral-900">
                          #{req.trackingNumber}
                        </span>
                        <span className="text-[11px] text-neutral-500 ml-2">
                          {req.wasteCategory} · {req.estimatedKg} kg approx
                        </span>
                      </div>
                    </div>
                    <span
                      className={`text-[11px] font-semibold py-0.5 px-2.5 rounded-md self-start sm:self-auto ${
                        isVerified
                          ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          : req.status === 'On the Way'
                          ? 'bg-amber-50 text-amber-800 border border-amber-200'
                          : 'bg-blue-50 text-blue-800 border border-blue-200'
                      }`}
                    >
                      Status: {req.status}
                    </span>
                  </div>

                  {/* Citizen Contact & Address */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="flex items-start gap-1.5 text-neutral-700">
                      <MapPin className="w-3.5 h-3.5 text-neutral-400 shrink-0 mt-0.5" />
                      <div>
                        <span className="font-medium text-neutral-800">{req.citizenName}</span>
                        <p className="text-[11px] text-neutral-500 leading-snug">{req.address}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 text-neutral-600 sm:justify-end">
                      <a
                        href={`tel:${req.citizenPhone}`}
                        className="flex items-center gap-1 text-[11px] font-medium text-emerald-700 hover:text-emerald-800"
                      >
                        <Phone className="w-3 h-3" /> {req.citizenPhone}
                      </a>
                      <span className="text-[11px] text-neutral-400">·</span>
                      <span className="text-[11px] text-neutral-500 font-mono">
                        {req.preferredDate} ({req.timeSlot})
                      </span>
                    </div>
                  </div>

                  {req.specialInstructions && (
                    <div className="p-2 bg-neutral-50 rounded-lg text-[11px] text-neutral-600 border border-neutral-100">
                      <strong>Instructions:</strong> {req.specialInstructions}
                    </div>
                  )}

                  {/* Action Controls for Collector */}
                  <div className="pt-2 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      {req.status === 'Assigned' && (
                        <button
                          onClick={() => handleAcceptAssignment(req)}
                          className="py-1.5 px-3 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                        >
                          Accept Assignment
                        </button>
                      )}
                      {req.status === 'Accepted' && (
                        <button
                          onClick={() => handleUpdateStatus(req.id, 'On the Way')}
                          className="py-1.5 px-3 text-xs font-semibold text-white bg-amber-600 hover:bg-amber-700 rounded-lg transition-colors flex items-center gap-1"
                        >
                          <Navigation className="w-3 h-3" /> Start Route (On the Way)
                        </button>
                      )}
                      {req.status === 'On the Way' && (
                        <span className="text-xs font-semibold text-amber-700 flex items-center gap-1">
                          <Navigation className="w-3.5 h-3.5 animate-pulse" /> Vehicle En Route to Citizen
                        </span>
                      )}
                    </div>

                    {!isVerified ? (
                      <button
                        onClick={() => {
                          setSelectedRequest(req);
                          setIsQrScannerOpen(true);
                        }}
                        className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors shadow-xs"
                      >
                        <QrCode className="w-3.5 h-3.5" /> Scan QR & Weigh Material
                      </button>
                    ) : (
                      <div className="text-xs text-emerald-800 font-semibold font-mono flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" /> Verified: {req.actualKg} kg weighed
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {activeRouteStops.length === 0 && activeFilter === 'assigned' && (
              <div className="bg-white p-8 rounded-2xl border border-neutral-200 text-center text-xs text-neutral-500">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                <p className="font-semibold text-neutral-800">All assigned pickups completed!</p>
                <p className="mt-0.5">Check with municipal dispatch for new scheduled pickups.</p>
              </div>
            )}
          </div>
        </div>

        {/* Right 1 Col: Live Route Map View */}
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-bold text-xs text-neutral-900 flex items-center gap-1.5">
                <Compass className="w-4 h-4 text-emerald-600" /> Today's Collection Route Map
              </h3>
              <span className="text-[10px] text-neutral-400 font-mono">GPS Active</span>
            </div>
            <p className="text-[11px] text-neutral-500 mb-3">
              Optimized stops across Sector 4 delivering to EcoVision MRF depot.
            </p>

            <LeafletMap
              requests={activeRouteStops}
              centres={store.getCentres()}
              height="340px"
              onSelectRequest={req => setSelectedRequest(req)}
            />
          </div>

          {/* Quick Depot Info */}
          <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200 text-xs space-y-2">
            <h4 className="font-semibold text-neutral-800">Discharge Hub (MRF):</h4>
            <p className="text-[11px] text-neutral-600 leading-snug">
              EcoVision Central MRF · Peenya Industrial Area Phase 2
            </p>
            <div className="text-[11px] text-neutral-500 pt-1 border-t border-neutral-200">
              Unloading Bay 3 designated for segregated PET, fiberboard, and glass containers.
            </div>
          </div>
        </div>
      </div>

      {/* QR Scanner & Verification Modal */}
      <QrScannerModal
        isOpen={isQrScannerOpen}
        onClose={() => {
          setIsQrScannerOpen(false);
          setSelectedRequest(null);
        }}
        preSelectedRequest={selectedRequest}
        onVerifiedSuccess={() => {
          setAllRequests(store.getRequests());
        }}
      />
    </div>
  );
};
