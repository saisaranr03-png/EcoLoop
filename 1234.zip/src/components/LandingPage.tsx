/**
 * EcoLoop Landing Page
 * Startup-grade marketing presentation with 4-role interactive quick switcher,
 * smart features spotlight, how it works, waste segregation guide, and live city metrics.
 */

import React from 'react';
import { UserRole } from '../types';
import { LeafletMap } from './LeafletMap';
import { store } from '../services/store';
import {
  Recycle,
  Sparkles,
  ShieldCheck,
  QrCode,
  Truck,
  Factory,
  Coins,
  ArrowRight,
  TrendingUp,
  MapPin,
  CheckCircle2,
  Users,
  Compass,
} from 'lucide-react';

interface LandingPageProps {
  onSelectRole: (role: UserRole) => void;
  onOpenSchedule: () => void;
  onOpenVision: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onSelectRole,
  onOpenSchedule,
  onOpenVision,
}) => {
  const kpis = store.getPlatformKPIs();

  return (
    <div className="space-y-16 pb-12">
      {/* HERO SECTION */}
      <section className="relative rounded-3xl overflow-hidden border border-neutral-200/80 shadow-sm bg-neutral-900 text-white min-h-[540px] flex items-center">
        {/* Background Image with Scrim */}
        <div className="absolute inset-0 z-0">
          <img
            src="/src/assets/images/ecoloop_hero_city_1793887333227.jpg"
            alt="Modern sustainable green smart city with electric recycling fleet"
            className="w-full h-full object-cover object-center opacity-40 mix-blend-luminosity scale-105"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-neutral-950 via-neutral-950/80 to-transparent" />
        </div>

        <div className="relative z-10 p-8 sm:p-12 lg:p-16 max-w-3xl space-y-6">
          <div className="inline-flex items-center gap-2 py-1 px-3.5 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-semibold backdrop-blur-xs">
            <Sparkles className="w-3.5 h-3.5" /> Next-Gen Municipal Solid Waste Technology
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white text-balance leading-tight">
            Smart Waste Collection & Circular Recycling System
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed max-w-2xl">
            Connecting citizens, municipal route collectors, certified recycling centres, and urban administrators
            in one synchronized network with optical AI identification, doorstep QR verification, and real EcoPoints rewards.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => onSelectRole('citizen')}
              className="py-3 px-6 rounded-xl font-bold text-xs bg-emerald-500 hover:bg-emerald-400 text-neutral-950 transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              Enter Citizen Portal <ArrowRight className="w-4 h-4" />
            </button>
            <a
              href="/ecoloop_project_report.pdf"
              download="EcoLoop_Project_Report_Barath_SaiSaran_Sanjai.pdf"
              target="_blank"
              rel="noopener noreferrer"
              className="py-3 px-5 rounded-xl font-semibold text-xs bg-blue-600 hover:bg-blue-500 text-white transition-colors flex items-center gap-2 shadow-xs"
            >
              📄 Download 24-Page Project Report (PDF)
            </a>
            <a
              href="/ecoloop_complete_project.zip"
              download="ecoloop_complete_project.zip"
              className="py-3 px-5 rounded-xl font-semibold text-xs bg-white text-neutral-950 hover:bg-neutral-100 transition-colors flex items-center gap-2 shadow-xs"
            >
              📥 Download Source (.ZIP)
            </a>
            <button
              onClick={onOpenVision}
              className="py-3 px-5 rounded-xl font-semibold text-xs bg-white/10 hover:bg-white/20 text-white border border-white/20 backdrop-blur-xs transition-colors flex items-center gap-2"
            >
              Try AI Waste Identifier
            </button>
          </div>

          {/* Quick Demo Switcher Strip */}
          <div className="pt-4 border-t border-white/10">
            <span className="text-[11px] font-medium text-neutral-400 uppercase tracking-wider block mb-2">
              Instant 1-Click Role Exploration:
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onSelectRole('citizen')}
                className="py-1 px-3 text-[11px] font-medium rounded-lg bg-white/10 hover:bg-emerald-500 hover:text-neutral-950 transition-colors"
              >
                1. Citizen Portal
              </button>
              <button
                onClick={() => onSelectRole('collector')}
                className="py-1 px-3 text-[11px] font-medium rounded-lg bg-white/10 hover:bg-blue-500 hover:text-white transition-colors"
              >
                2. Collector Route Dashboard
              </button>
              <button
                onClick={() => onSelectRole('recycler')}
                className="py-1 px-3 text-[11px] font-medium rounded-lg bg-white/10 hover:bg-teal-500 hover:text-neutral-950 transition-colors"
              >
                3. Recycling Facility (MRF)
              </button>
              <button
                onClick={() => onSelectRole('admin')}
                className="py-1 px-3 text-[11px] font-medium rounded-lg bg-white/10 hover:bg-purple-500 hover:text-white transition-colors"
              >
                4. Municipal Admin Console
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* METRICS TICKER STRIP */}
      <section className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Total Diverted from Landfill</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-700">
              {kpis.totalWasteRecycledKg.toLocaleString()}
            </span>
            <span className="text-xs text-neutral-500">kg</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-1 block">94% circular diversion</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Verified Citizen Pickups</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">{kpis.completedCollections}</span>
            <span className="text-xs text-neutral-500">doorstep runs</span>
          </div>
          <span className="text-[10px] text-neutral-400 mt-1 block">QR scale authenticated</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Avoided Carbon Footprint</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-teal-700">{kpis.impact.co2AvoidedKg}</span>
            <span className="text-xs text-neutral-500">kg CO₂e</span>
          </div>
          <span className="text-[10px] text-teal-700 mt-1 block">US EPA WARM standard</span>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Active Urban Citizens</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">{kpis.totalCitizens}</span>
            <span className="text-xs text-neutral-500">residents</span>
          </div>
          <span className="text-[10px] text-neutral-400 mt-1 block">Across 8 City Wards</span>
        </div>
      </section>

      {/* HOW ECOLOOP WORKS */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
            Closed-Loop Workflow
          </span>
          <h2 className="text-2xl font-extrabold text-neutral-900">
            How EcoLoop Solves the Urban Waste Crisis
          </h2>
          <p className="text-xs text-neutral-500 leading-relaxed">
            Eliminating contaminated municipal landfill waste through doorstep verified sorting,
            digital traceability, and economic citizen incentives.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-2">
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center text-xs">
              01
            </div>
            <h3 className="font-bold text-sm text-neutral-900">Smart Schedule & AI Identification</h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Resident takes a photo or selects waste category (Plastic, Paper, Glass, E-Waste) and schedules a pickup window.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-2">
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs">
              02
            </div>
            <h3 className="font-bold text-sm text-neutral-900">EV Collector Dispatch</h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Route operator navigates using in-app Leaflet GPS stops and arrives at the resident doorstep with digital scales.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-2">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-800 font-bold flex items-center justify-center text-xs">
              03
            </div>
            <h3 className="font-bold text-sm text-neutral-900">Doorstep QR Scale Verification</h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Collector scans the citizen's unique QR code, weighs the segregated haul, and logs exact kilograms.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-2">
            <div className="w-9 h-9 rounded-xl bg-teal-100 text-teal-800 font-bold flex items-center justify-center text-xs">
              04
            </div>
            <h3 className="font-bold text-sm text-neutral-900">MRF Processing & Rewards</h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Recycling facility baling into pure circular raw material while resident instantly unlocks EcoPoints vouchers.
            </p>
          </div>
        </div>
      </section>

      {/* SPLIT SHOWCASE: WASTE SEGREGATION & MRF FACILITY */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Material Quality & Segregation
            </span>
            <h3 className="text-xl font-bold text-neutral-900">
              Clean Segregation at Source Unlocks High-Value Reprocessing
            </h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              When waste is mixed, 80% becomes contaminated and ends up in open dumps. EcoLoop's built-in AI Segregation
              Bot and optical scanner educate citizens to sort clean cardboard, clear PET, and metals separately.
            </p>
          </div>

          <div className="rounded-2xl overflow-hidden border border-neutral-200">
            <img
              src="/src/assets/images/ecoloop_segregation_1793887334056.jpg"
              alt="Neatly organized recyclable materials including glass bottles, cardboard, aluminum cans"
              className="w-full h-56 object-cover object-center"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-semibold text-neutral-700">8 Supported Waste Streams</span>
            <button
              onClick={() => onSelectRole('citizen')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              Explore Waste Guide <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-neutral-200 shadow-xs flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Industrial Material Recovery
            </span>
            <h3 className="text-xl font-bold text-neutral-900">
              Automated MRFs & Certified Recycling Processing
            </h3>
            <p className="text-xs text-neutral-600 leading-relaxed">
              Recovered materials enter authorized municipal material recovery facilities (MRFs) with optical sorting lines,
              shredders, and pelletizers. Every kilogram is weighed and accounted for in the municipal audit ledger.
            </p>
          </div>

          <div className="rounded-2xl overflow-hidden border border-neutral-200">
            <img
              src="/src/assets/images/ecoloop_facility_1793887333857.jpg"
              alt="Modern clean automated recycling center and material recovery facility"
              className="w-full h-56 object-cover object-center"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs font-semibold text-neutral-700">98.4% Material Purity</span>
            <button
              onClick={() => onSelectRole('recycler')}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
            >
              View MRF Operations <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* RECYCLING MAP TEASER */}
      <section className="bg-white rounded-3xl p-6 sm:p-8 border border-neutral-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              Interactive City Geographic Infrastructure
            </span>
            <h3 className="text-xl font-bold text-neutral-900">
              Locate Nearby Municipal Recovery Centers
            </h3>
          </div>
          <button
            onClick={() => onSelectRole('citizen')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 self-start sm:self-auto"
          >
            Open Full Interactive Map <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <LeafletMap centres={store.getCentres()} height="360px" />
      </section>

      {/* CALL TO ACTION */}
      <section className="bg-gradient-to-r from-emerald-800 to-emerald-950 text-white rounded-3xl p-8 sm:p-12 text-center space-y-4 shadow-sm">
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
          Join the City of Bangalore Circular Waste Movement
        </h2>
        <p className="text-xs sm:text-sm text-emerald-200 max-w-xl mx-auto leading-relaxed">
          Schedule your first doorstep waste pickup today, eliminate plastic pollution, and convert your recyclables into shopping vouchers.
        </p>
        <div className="pt-2 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => onSelectRole('citizen')}
            className="py-3 px-6 text-xs font-bold bg-white text-emerald-950 hover:bg-emerald-50 rounded-xl transition-colors shadow-sm"
          >
            Start Recycling as Citizen
          </button>
          <button
            onClick={() => onSelectRole('admin')}
            className="py-3 px-6 text-xs font-bold bg-emerald-700/60 hover:bg-emerald-700 text-white border border-emerald-500/30 rounded-xl transition-colors"
          >
            Access Municipal Admin Console
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="pt-8 border-t border-neutral-200 text-xs text-neutral-500 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
            ♻
          </div>
          <span className="font-bold text-neutral-800">EcoLoop System</span>
          <span className="text-neutral-400">· Smart Waste Collection & Recycling Management</span>
        </div>
        <div className="flex items-center gap-4 text-neutral-500">
          <span>College Exhibition Edition</span>
          <span>·</span>
          <span>FastAPI + SQLite + React</span>
          <span>·</span>
          <span>© 2026 EcoLoop</span>
        </div>
      </footer>
    </div>
  );
};
