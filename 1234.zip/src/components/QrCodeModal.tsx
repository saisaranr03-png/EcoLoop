/**
 * QR Code Display Modal for Citizens
 * Shows high-resolution QR verification code with pickup details for collection workers to scan.
 */

import React, { useEffect, useRef } from 'react';
import { CollectionRequest } from '../types';
import { drawQrToCanvas } from '../utils/qrGenerator';
import { X, Download, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface QrCodeModalProps {
  request: CollectionRequest | null;
  onClose: () => void;
}

export const QrCodeModal: React.FC<QrCodeModalProps> = ({ request, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (request && canvasRef.current) {
      drawQrToCanvas(canvasRef.current, request.qrCodeToken, 240);
    }
  }, [request]);

  if (!request) return null;

  const handleDownload = () => {
    if (!canvasRef.current) return;
    const url = canvasRef.current.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `EcoLoop-QR-${request.trackingNumber}.png`;
    a.click();
  };

  const isVerified = request.status === 'Verified';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
          <div>
            <h3 className="font-bold text-neutral-900 text-base">Pickup Verification QR</h3>
            <p className="text-xs text-neutral-500 font-mono">#{request.trackingNumber}</p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-5 flex flex-col items-center text-center">
          <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/80 shadow-xs mb-3">
            <canvas ref={canvasRef} className="rounded-lg" />
          </div>

          {isVerified ? (
            <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-semibold py-1 px-3 bg-emerald-50 rounded-full">
              <CheckCircle2 className="w-4 h-4" /> Collection Verified & Rewarded
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-neutral-600 text-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Present this QR code to the collector at your doorstep</span>
            </div>
          )}

          <div className="w-full mt-4 p-3 bg-neutral-50 rounded-xl text-left text-xs space-y-1.5 text-neutral-600 border border-neutral-100">
            <div className="flex justify-between">
              <span className="text-neutral-500">Material Category:</span>
              <span className="font-semibold text-neutral-800">{request.wasteCategory}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Scheduled Weight:</span>
              <span className="font-mono font-medium text-neutral-800">{request.estimatedKg} kg</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Pickup Window:</span>
              <span className="text-neutral-800">{request.preferredDate} ({request.timeSlot})</span>
            </div>
            {request.ecoPointsAwarded && (
              <div className="flex justify-between pt-1 border-t border-neutral-200/60 font-semibold text-emerald-700">
                <span>EcoPoints Earned:</span>
                <span className="font-mono">+{request.ecoPointsAwarded} pts</span>
              </div>
            )}
          </div>
        </div>

        <div className="flex gap-2.5 pt-2">
          <button
            onClick={handleDownload}
            className="flex-1 flex items-center justify-center gap-2 py-2 px-3 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
          >
            <Download className="w-4 h-4" /> Save QR Code
          </button>
          <button
            onClick={onClose}
            className="flex-1 py-2 px-3 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
