/**
 * Community Environmental Challenges
 * Implements Feature 7: Gamified neighbourhood challenges with progress bars,
 * participant rosters, bonus EcoPoints, and achievement badge rewards.
 */

import React, { useState } from 'react';
import { store } from '../services/store';
import { CommunityChallenge } from '../types';
import { Target, Users, Calendar, Award, CheckCircle, ArrowRight } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CommunityChallengesTabProps {
  onScheduleForCategory?: (cat: any) => void;
}

export const CommunityChallengesTab: React.FC<CommunityChallengesTabProps> = ({
  onScheduleForCategory,
}) => {
  const [challenges, setChallenges] = useState<CommunityChallenge[]>(store.getChallenges());

  const handleToggleJoin = (id: string) => {
    store.toggleJoinChallenge(id);
    setChallenges(store.getChallenges());
    try {
      confetti({ particleCount: 35, spread: 50, origin: { y: 0.7 } });
    } catch {
      // ignore
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-lg font-bold text-neutral-900">City Community Challenges</h2>
          <p className="text-xs text-neutral-500">
            Collaborate with neighbours across Bangalore to divert waste streams and earn bonus EcoPoints
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {challenges.map(chal => {
          const percent = Math.min(100, Math.round((chal.currentKg / chal.targetKg) * 100));
          return (
            <div
              key={chal.id}
              className={`bg-white rounded-2xl p-5 border shadow-xs flex flex-col justify-between transition-all ${
                chal.isJoined ? 'border-emerald-300 ring-1 ring-emerald-500/20' : 'border-neutral-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between text-xs text-neutral-500 mb-2">
                  <span className="font-semibold text-emerald-800 bg-emerald-50 py-0.5 px-2 rounded-md">
                    {chal.category}
                  </span>
                  <span className="flex items-center gap-1 font-mono text-[11px]">
                    <Calendar className="w-3 h-3 text-neutral-400" /> Ends {chal.deadline}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-neutral-900">{chal.title}</h3>
                <p className="text-xs text-neutral-600 mt-1 leading-relaxed">{chal.description}</p>

                {/* Progress Bar */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-neutral-500 font-medium">Community Progress</span>
                    <span className="font-mono font-bold text-neutral-800">
                      {chal.currentKg} / {chal.targetKg} kg ({percent}%)
                    </span>
                  </div>
                  <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full transition-all duration-500"
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 text-neutral-600">
                    <Users className="w-4 h-4 text-neutral-400" />
                    <span>{chal.participantsCount} citizens joined</span>
                  </div>
                  <div className="flex items-center gap-1 text-emerald-700 font-semibold font-mono">
                    <Award className="w-4 h-4" />
                    <span>+{chal.rewardPoints} Bonus pts</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleJoin(chal.id)}
                  className={`flex-1 py-2 px-3 text-xs font-semibold rounded-xl transition-colors ${
                    chal.isJoined
                      ? 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                      : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                  }`}
                >
                  {chal.isJoined ? '✓ Challenge Active (Joined)' : 'Join Challenge'}
                </button>
                {chal.isJoined && chal.category !== 'All Categories' && (
                  <button
                    type="button"
                    onClick={() => onScheduleForCategory?.(chal.category)}
                    className="py-2 px-3 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 rounded-xl transition-colors flex items-center gap-1"
                  >
                    Schedule Pickup <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
