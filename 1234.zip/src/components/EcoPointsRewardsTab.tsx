/**
 * EcoPoints Wallet & Rewards Redemption Center
 * Implements Feature 3: EcoPoints balance, transaction history, rewards store with
 * instant voucher code generation, achievement badges, and monthly community leaderboard.
 */

import React, { useState } from 'react';
import { store } from '../services/store';
import { RewardItem, RewardRedemption } from '../types';
import {
  Coins,
  Gift,
  Award,
  Trophy,
  History,
  CheckCircle2,
  AlertCircle,
  Copy,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const EcoPointsRewardsTab: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const [rewards, setRewards] = useState<RewardItem[]>(store.getRewards());
  const [transactions, setTransactions] = useState(store.getTransactions(currentUser.id));
  const [redemptions, setRedemptions] = useState(store.getRedemptions(currentUser.id));
  const [activeSubView, setActiveSubView] = useState<'rewards' | 'history' | 'leaderboard' | 'badges'>('rewards');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | null; text: string }>({
    type: null,
    text: '',
  });
  const [recentVoucher, setRecentVoucher] = useState<RewardRedemption | null>(null);

  const handleRedeem = (rewardId: string) => {
    const res = store.redeemReward(rewardId);
    if (res.success && res.redemption) {
      setFeedback({ type: 'success', text: res.message });
      setRecentVoucher(res.redemption);
      setRewards(store.getRewards());
      setTransactions(store.getTransactions(currentUser.id));
      setRedemptions(store.getRedemptions(currentUser.id));

      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.6 },
        });
      } catch {
        // ignore
      }
    } else {
      setFeedback({ type: 'error', text: res.message });
    }
  };

  const copyVoucherCode = (code: string) => {
    navigator.clipboard?.writeText(code);
    setFeedback({ type: 'success', text: `Voucher code ${code} copied to clipboard!` });
  };

  // Mock Leaderboard
  const LEADERBOARD = [
    { rank: 1, name: 'Sunita Rao', zone: 'Indiranagar', points: 1420, kg: 88.5, badge: 'Eco Champion' },
    { rank: 2, name: 'Aravind Sharma (You)', zone: 'Green Glen Layout', points: currentUser.ecoPoints || 485, kg: 28.4, badge: 'Zero-Waste Hero' },
    { rank: 3, name: 'Priya Sundaram', zone: 'Whitefield', points: 410, kg: 22.0, badge: 'Plastic Crusher' },
    { rank: 4, name: 'Karthik Menon', zone: 'HSR Layout', points: 380, kg: 19.5, badge: 'Fiber Recycler' },
    { rank: 5, name: 'Anita Desai', zone: 'Koramangala', points: 320, kg: 16.0, badge: 'Compost Pioneer' },
  ];

  // Badges
  const BADGES = [
    { name: 'First Sort', desc: 'Completed your 1st verified waste pickup', unlocked: true, icon: '🌱' },
    { name: 'Plastic Buster', desc: 'Recycled over 10 kg of clean PET & HDPE', unlocked: true, icon: '🧴' },
    { name: 'Fiber Guardian', desc: 'Diverted 20 kg of cardboard from landfill', unlocked: true, icon: '📦' },
    { name: 'Hazard Neutralizer', desc: 'Properly segregated lithium batteries or e-waste', unlocked: false, icon: '⚡' },
    { name: 'Master Diverter', desc: 'Achieved 500+ verified EcoPoints', unlocked: (currentUser.ecoPoints || 0) >= 500, icon: '🏆' },
    { name: 'Centennial Recycler', desc: 'Completed 10 collection pickups', unlocked: false, icon: '🌟' },
  ];

  return (
    <div className="space-y-4">
      {/* Top Wallet Summary Strip */}
      <div className="bg-gradient-to-r from-emerald-800 to-emerald-950 text-white rounded-2xl p-6 shadow-sm border border-emerald-700/50 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="space-y-1 text-center md:text-left">
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300">
            EcoLoop Certified Green Wallet
          </span>
          <div className="flex items-baseline justify-center md:justify-start gap-2">
            <span className="text-4xl font-extrabold font-mono tabular-nums tracking-tight">
              {currentUser.ecoPoints || 0}
            </span>
            <span className="text-sm font-medium text-emerald-200">EcoPoints Available</span>
          </div>
          <p className="text-xs text-emerald-300/80 max-w-md">
            Awarded strictly after collector doorstep verification. Guaranteed non-duplicable blockchain-style ledger.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl text-center min-w-28 border border-white/10">
            <span className="text-xs text-emerald-200 block">Redeemed</span>
            <span className="text-base font-bold font-mono">{redemptions.length}</span>
            <span className="text-[10px] text-emerald-300 block">Vouchers</span>
          </div>
          <div className="p-3 bg-white/10 backdrop-blur-sm rounded-xl text-center min-w-28 border border-white/10">
            <span className="text-xs text-emerald-200 block">City Rank</span>
            <span className="text-base font-bold font-mono">#2</span>
            <span className="text-[10px] text-emerald-300 block">In Sector 4</span>
          </div>
        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center justify-between border-b border-neutral-200 pb-2">
        <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg">
          <button
            onClick={() => setActiveSubView('rewards')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubView === 'rewards'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Gift className="w-3.5 h-3.5" /> Rewards Store
          </button>
          <button
            onClick={() => setActiveSubView('history')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubView === 'history'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <History className="w-3.5 h-3.5" /> Wallet Ledger ({transactions.length})
          </button>
          <button
            onClick={() => setActiveSubView('leaderboard')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubView === 'leaderboard'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" /> Leaderboard
          </button>
          <button
            onClick={() => setActiveSubView('badges')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubView === 'badges'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Award className="w-3.5 h-3.5" /> Achievements
          </button>
        </div>
      </div>

      {/* Feedback banner */}
      {feedback.text && (
        <div
          className={`p-3 rounded-xl text-xs flex items-center justify-between ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{feedback.text}</span>
          </div>
          <button
            onClick={() => setFeedback({ type: null, text: '' })}
            className="text-neutral-400 hover:text-neutral-600"
          >
            ✕
          </button>
        </div>
      )}

      {/* Active Voucher Spotlight if just redeemed */}
      {recentVoucher && (
        <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold">
              <Gift className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-semibold text-emerald-700 tracking-wider">
                Freshly Generated Voucher Code
              </span>
              <h4 className="text-xs font-bold text-neutral-900">{recentVoucher.rewardTitle}</h4>
              <p className="text-xs font-mono font-bold text-emerald-800 mt-0.5">
                {recentVoucher.voucherCode}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => copyVoucherCode(recentVoucher.voucherCode)}
              className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-emerald-800 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-50 transition-colors"
            >
              <Copy className="w-3.5 h-3.5" /> Copy Code
            </button>
            <button
              onClick={() => setRecentVoucher(null)}
              className="text-xs text-neutral-500 hover:text-neutral-700 px-2 py-1"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* VIEW 1: REWARDS STORE */}
      {activeSubView === 'rewards' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {rewards.map(reward => {
            const canAfford = (currentUser.ecoPoints || 0) >= reward.pointsCost;
            return (
              <div
                key={reward.id}
                className="bg-white rounded-2xl p-4 border border-neutral-200 shadow-xs flex flex-col justify-between hover:border-emerald-300 transition-all"
              >
                <div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-500 mb-2">
                    <span className="font-medium text-emerald-700">{reward.category}</span>
                    <span className="font-mono text-neutral-400">{reward.remainingStock} in stock</span>
                  </div>
                  <h4 className="text-sm font-bold text-neutral-900 leading-snug">{reward.title}</h4>
                  <p className="text-xs text-neutral-500 mt-0.5">By {reward.partnerName}</p>
                  <p className="text-xs text-neutral-600 mt-2 leading-relaxed">{reward.description}</p>
                </div>

                <div className="pt-4 mt-3 border-t border-neutral-100 flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <Coins className="w-4 h-4 text-amber-500" />
                    <span className="text-sm font-bold font-mono text-neutral-900">
                      {reward.pointsCost}
                    </span>
                    <span className="text-[11px] text-neutral-500">pts</span>
                  </div>
                  <button
                    onClick={() => handleRedeem(reward.id)}
                    disabled={!canAfford || reward.remainingStock <= 0}
                    className={`py-1.5 px-3.5 text-xs font-semibold rounded-lg transition-colors shadow-xs ${
                      canAfford && reward.remainingStock > 0
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                        : 'bg-neutral-100 text-neutral-400 cursor-not-allowed'
                    }`}
                  >
                    {!canAfford ? 'Need More Points' : 'Redeem Reward'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* VIEW 2: LEDGER */}
      {activeSubView === 'history' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100">
            <h3 className="font-bold text-xs text-neutral-900">Audit-Verified Transaction History</h3>
            <p className="text-[11px] text-neutral-500">Every point earned is traceable to a physical scale weight and QR token</p>
          </div>
          <div className="divide-y divide-neutral-100">
            {transactions.map(tx => (
              <div key={tx.id} className="p-3.5 flex items-center justify-between hover:bg-neutral-50/60">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                      tx.type === 'earned'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {tx.type === 'earned' ? '+' : '-'}
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-neutral-800">{tx.description}</p>
                    <p className="text-[10px] text-neutral-400">
                      {new Date(tx.timestamp).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div
                  className={`text-xs font-bold font-mono ${
                    tx.type === 'earned' ? 'text-emerald-700' : 'text-amber-700'
                  }`}
                >
                  {tx.type === 'earned' ? `+${tx.points}` : `${tx.points}`} pts
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 3: LEADERBOARD */}
      {activeSubView === 'leaderboard' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100">
            <h3 className="font-bold text-xs text-neutral-900">Monthly City Recycling Champions</h3>
            <p className="text-[11px] text-neutral-500">Top citizens diverting municipal solid waste from landfills</p>
          </div>
          <div className="divide-y divide-neutral-100">
            {LEADERBOARD.map(user => (
              <div
                key={user.rank}
                className={`p-3.5 flex items-center justify-between ${
                  user.name.includes('(You)') ? 'bg-emerald-50/60 font-semibold' : 'hover:bg-neutral-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold font-mono ${
                      user.rank === 1
                        ? 'bg-amber-400 text-amber-950'
                        : user.rank === 2
                        ? 'bg-neutral-300 text-neutral-800'
                        : user.rank === 3
                        ? 'bg-amber-700 text-amber-100'
                        : 'text-neutral-500'
                    }`}
                  >
                    {user.rank}
                  </div>
                  <div>
                    <div className="text-xs text-neutral-800 flex items-center gap-2">
                      <span>{user.name}</span>
                      <span className="text-[10px] text-emerald-700 font-medium">{user.badge}</span>
                    </div>
                    <span className="text-[10px] text-neutral-400">{user.zone}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold font-mono text-emerald-700 block">
                    {user.points} pts
                  </span>
                  <span className="text-[10px] text-neutral-400 font-mono">{user.kg} kg diverted</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* VIEW 4: ACHIEVEMENTS & BADGES */}
      {activeSubView === 'badges' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {BADGES.map((b, i) => (
            <div
              key={i}
              className={`p-4 rounded-2xl border text-center transition-all ${
                b.unlocked
                  ? 'bg-white border-emerald-300 shadow-xs'
                  : 'bg-neutral-50 border-neutral-200 opacity-60'
              }`}
            >
              <div className="text-3xl mb-2">{b.icon}</div>
              <h4 className="text-xs font-bold text-neutral-800">{b.name}</h4>
              <p className="text-[11px] text-neutral-500 mt-1 leading-snug">{b.desc}</p>
              <span
                className={`inline-block mt-3 text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                  b.unlocked ? 'bg-emerald-100 text-emerald-800' : 'bg-neutral-200 text-neutral-600'
                }`}
              >
                {b.unlocked ? '✓ Unlocked' : 'Locked'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
