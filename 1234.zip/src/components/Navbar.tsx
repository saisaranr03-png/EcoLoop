/**
 * EcoLoop Top Bar Navigation
 * Adheres to 3-Zone Top Bar Contract:
 * [Brand Wordmark] --- [Nav Links] --- [Role Switcher & Profile]
 */

import React, { useState } from 'react';
import { UserRole, UserProfile } from '../types';
import { store, DEMO_USERS } from '../services/store';
import {
  Recycle,
  User,
  ChevronDown,
  RotateCcw,
  Sparkles,
  Shield,
  Truck,
  Factory,
} from 'lucide-react';

interface NavbarProps {
  currentView: 'landing' | UserRole;
  onNavigate: (view: 'landing' | UserRole) => void;
  onOpenSchedule?: () => void;
  onOpenVision?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onOpenSchedule }) => {
  const currentUser = store.getCurrentUser();
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const handleRoleSelect = (role: UserRole) => {
    store.switchRole(role);
    onNavigate(role);
    setIsRoleDropdownOpen(false);
  };

  const handleResetData = () => {
    if (window.confirm('Reset all demo collection data, points, and requests to default state?')) {
      store.resetToFactoryDemo();
      onNavigate('citizen');
    }
  };

  const getRoleIcon = (role: UserRole) => {
    switch (role) {
      case 'citizen':
        return <User className="w-3.5 h-3.5 text-emerald-600" />;
      case 'collector':
        return <Truck className="w-3.5 h-3.5 text-blue-600" />;
      case 'recycler':
        return <Factory className="w-3.5 h-3.5 text-teal-600" />;
      case 'admin':
        return <Shield className="w-3.5 h-3.5 text-purple-600" />;
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-neutral-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single Brand Wordmark */}
        <button
          onClick={() => onNavigate('landing')}
          className="flex items-center gap-2 text-lg font-bold tracking-tight text-neutral-900 whitespace-nowrap shrink-0 hover:opacity-80 transition-opacity"
        >
          <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            ♻
          </div>
          <span className="text-neutral-900">EcoLoop</span>
        </button>

        {/* Zone 2: Concise Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-neutral-600">
          <button
            onClick={() => onNavigate('landing')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              currentView === 'landing' ? 'text-emerald-700 font-bold' : 'hover:text-neutral-900'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => handleRoleSelect('citizen')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              currentView === 'citizen' ? 'text-emerald-700 font-bold' : 'hover:text-neutral-900'
            }`}
          >
            Citizen Portal
          </button>
          <button
            onClick={() => handleRoleSelect('collector')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              currentView === 'collector' ? 'text-blue-700 font-bold' : 'hover:text-neutral-900'
            }`}
          >
            Collector Route
          </button>
          <button
            onClick={() => handleRoleSelect('recycler')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              currentView === 'recycler' ? 'text-teal-700 font-bold' : 'hover:text-neutral-900'
            }`}
          >
            Recycling Centre
          </button>
          <button
            onClick={() => handleRoleSelect('admin')}
            className={`transition-colors whitespace-nowrap shrink-0 ${
              currentView === 'admin' ? 'text-purple-700 font-bold' : 'hover:text-neutral-900'
            }`}
          >
            Municipal Admin
          </button>
        </nav>

        {/* Zone 3: Interactive Role Switcher & Action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <a
            href="/ecoloop_project_report.pdf"
            download="EcoLoop_Project_Report_Barath_SaiSaran_Sanjai.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-blue-800 bg-blue-50 hover:bg-blue-100 border border-blue-300 rounded-xl transition-colors shadow-xs"
            title="Download 24-page College Project Report PDF"
          >
            <span className="text-sm">📄</span>
            <span className="hidden sm:inline">Report PDF</span>
          </a>

          <a
            href="/ecoloop_complete_project.zip"
            download="ecoloop_complete_project.zip"
            className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-xl transition-colors shadow-xs"
            title="Download full project source code as .ZIP"
          >
            <span className="text-sm">📥</span>
            <span className="hidden sm:inline">Download ZIP</span>
          </a>

          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-2 py-1.5 px-3 text-xs font-semibold rounded-xl bg-neutral-100 hover:bg-neutral-200/80 text-neutral-800 transition-colors border border-neutral-200/60"
            >
              {getRoleIcon(currentUser.role)}
              <span className="capitalize">{currentUser.role} View</span>
              <ChevronDown className="w-3.5 h-3.5 text-neutral-400" />
            </button>

            {isRoleDropdownOpen && (
              <div className="absolute right-0 mt-2 w-56 rounded-2xl bg-white shadow-xl border border-neutral-200 p-2 text-xs space-y-1 animate-in fade-in zoom-in-95 duration-100 z-50">
                <span className="text-[10px] uppercase font-bold text-neutral-400 px-2.5 py-1 block">
                  Switch Active Role
                </span>

                <button
                  onClick={() => handleRoleSelect('citizen')}
                  className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-600" />
                    <div>
                      <p className="font-semibold text-neutral-900">Aravind Sharma</p>
                      <p className="text-[10px] text-neutral-500">Citizen / Resident</p>
                    </div>
                  </div>
                  {currentUser.role === 'citizen' && (
                    <span className="text-emerald-600 text-xs font-bold">✓</span>
                  )}
                </button>

                <button
                  onClick={() => handleRoleSelect('collector')}
                  className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Truck className="w-4 h-4 text-blue-600" />
                    <div>
                      <p className="font-semibold text-neutral-900">Rajesh Kumar</p>
                      <p className="text-[10px] text-neutral-500">Route Collector Staff</p>
                    </div>
                  </div>
                  {currentUser.role === 'collector' && (
                    <span className="text-blue-600 text-xs font-bold">✓</span>
                  )}
                </button>

                <button
                  onClick={() => handleRoleSelect('recycler')}
                  className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Factory className="w-4 h-4 text-teal-600" />
                    <div>
                      <p className="font-semibold text-neutral-900">EcoVision MRF</p>
                      <p className="text-[10px] text-neutral-500">Recycling Facility Manager</p>
                    </div>
                  </div>
                  {currentUser.role === 'recycler' && (
                    <span className="text-teal-600 text-xs font-bold">✓</span>
                  )}
                </button>

                <button
                  onClick={() => handleRoleSelect('admin')}
                  className="w-full flex items-center justify-between p-2 rounded-xl hover:bg-neutral-50 text-left transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Shield className="w-4 h-4 text-purple-600" />
                    <div>
                      <p className="font-semibold text-neutral-900">Dr. Sarah Chen</p>
                      <p className="text-[10px] text-neutral-500">Municipal Administrator</p>
                    </div>
                  </div>
                  {currentUser.role === 'admin' && (
                    <span className="text-purple-600 text-xs font-bold">✓</span>
                  )}
                </button>

                <div className="pt-1 border-t border-neutral-100 mt-1">
                  <button
                    onClick={handleResetData}
                    className="w-full flex items-center gap-2 p-2 rounded-xl text-neutral-500 hover:text-red-700 hover:bg-red-50 text-[11px] transition-colors"
                  >
                    <RotateCcw className="w-3.5 h-3.5" /> Reset Demo Database
                  </button>
                </div>
              </div>
            )}
          </div>

          {currentView === 'citizen' && onOpenSchedule && (
            <button
              onClick={onOpenSchedule}
              className="hidden sm:inline-flex py-1.5 px-3.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
            >
              + Schedule Pickup
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
