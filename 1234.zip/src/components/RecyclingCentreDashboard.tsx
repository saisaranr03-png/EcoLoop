/**
 * Recycling Centre Dashboard
 * Operational dashboard for facility managers & material recovery staff:
 * incoming haul intake, sorting line status, material processing stages,
 * capacity monitoring, and accepted waste categories.
 */

import React, { useState, useEffect } from 'react';
import { store } from '../services/store';
import { RecyclingCentre, WasteCategory, CollectionRequest } from '../types';
import {
  Factory,
  Layers,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  TrendingUp,
  Settings,
  Scale,
  Sparkles,
} from 'lucide-react';

interface ProcessingBatch {
  id: string;
  category: WasteCategory;
  weightKg: number;
  stage: 'Intake' | 'Optical Sorting' | 'Shredding/Baling' | 'Reprocessed (Pellet/Pulp)';
  receivedAt: string;
  purityScore: number;
}

export const RecyclingCentreDashboard: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const [centre, setCentre] = useState<RecyclingCentre>(
    store.getCentres()[0] || {
      id: 'rec_01',
      name: 'EcoVision Central MRF',
      address: 'Plot 18B, Peenya Industrial Area Phase 2, Bangalore',
      latitude: 13.0285,
      longitude: 77.5186,
      phone: '+91 80 4122 9000',
      email: 'central@ecovisionmrf.org',
      openHours: 'Mon - Sat: 08:00 AM - 07:00 PM',
      acceptedCategories: ['Plastic', 'Paper', 'Glass', 'Metal', 'Electronic Waste'],
      currentCapacityKg: 8400,
      maxCapacityKg: 15000,
      status: 'Open',
      efficiencyRating: 98.4,
      facilityType: 'MRF (Material Recovery Facility)',
    }
  );

  const [batches, setBatches] = useState<ProcessingBatch[]>([
    {
      id: 'batch_901',
      category: 'Plastic',
      weightKg: 142.5,
      stage: 'Optical Sorting',
      receivedAt: 'Today, 08:30 AM',
      purityScore: 97.2,
    },
    {
      id: 'batch_902',
      category: 'Paper',
      weightKg: 280.0,
      stage: 'Shredding/Baling',
      receivedAt: 'Today, 09:15 AM',
      purityScore: 99.1,
    },
    {
      id: 'batch_903',
      category: 'Metal',
      weightKg: 64.0,
      stage: 'Reprocessed (Pellet/Pulp)',
      receivedAt: 'Yesterday, 04:00 PM',
      purityScore: 98.5,
    },
    {
      id: 'batch_904',
      category: 'Electronic Waste',
      weightKg: 45.0,
      stage: 'Intake',
      receivedAt: 'Today, 11:00 AM',
      purityScore: 94.0,
    },
  ]);

  const [activeTab, setActiveTab] = useState<'batches' | 'categories' | 'stats'>('batches');
  const [isUpdatingStatus, setIsUpdatingStatus] = useState(false);

  const capacityPercent = Math.round((centre.currentCapacityKg / centre.maxCapacityKg) * 100);

  const handleAdvanceStage = (batchId: string) => {
    const stageOrder: ProcessingBatch['stage'][] = [
      'Intake',
      'Optical Sorting',
      'Shredding/Baling',
      'Reprocessed (Pellet/Pulp)',
    ];

    setBatches(prev =>
      prev.map(b => {
        if (b.id === batchId) {
          const currentIndex = stageOrder.indexOf(b.stage);
          const nextIndex = Math.min(stageOrder.length - 1, currentIndex + 1);
          return { ...b, stage: stageOrder[nextIndex] };
        }
        return b;
      })
    );
  };

  const handleToggleCategory = (category: WasteCategory) => {
    const updated = centre.acceptedCategories.includes(category)
      ? centre.acceptedCategories.filter(c => c !== category)
      : [...centre.acceptedCategories, category];

    setCentre({ ...centre, acceptedCategories: updated });
  };

  const handleToggleFacilityStatus = () => {
    const nextStatus = centre.status === 'Open' ? 'Operating' : centre.status === 'Operating' ? 'Maintenance' : 'Open';
    store.updateCentreStatus(centre.id, nextStatus);
    setCentre({ ...centre, status: nextStatus });
  };

  return (
    <div className="space-y-6">
      {/* Top Facility Banner */}
      <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-neutral-900">{centre.name}</h1>
            <span
              className={`text-[11px] font-semibold py-0.5 px-2.5 rounded-full border ${
                centre.status === 'Open'
                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                  : centre.status === 'Operating'
                  ? 'bg-blue-50 text-blue-800 border-blue-200'
                  : 'bg-amber-50 text-amber-800 border-amber-200'
              }`}
            >
              {centre.status}
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            {centre.address} · {centre.facilityType} · Hours: {centre.openHours}
          </p>
        </div>

        <button
          onClick={handleToggleFacilityStatus}
          className="py-2 px-3.5 text-xs font-semibold text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors border border-neutral-200"
        >
          Toggle Status (Currently: {centre.status})
        </button>
      </div>

      {/* Facility KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Storage Capacity</span>
            <Factory className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {centre.currentCapacityKg.toLocaleString()}
            </span>
            <span className="text-xs text-neutral-500 font-medium">/ {centre.maxCapacityKg.toLocaleString()} kg</span>
          </div>
          <div className="w-full bg-neutral-100 rounded-full h-1.5 mt-2 overflow-hidden">
            <div
              className={`h-full rounded-full ${
                capacityPercent > 80 ? 'bg-amber-500' : 'bg-emerald-600'
              }`}
              style={{ width: `${capacityPercent}%` }}
            />
          </div>
          <span className="text-[10px] text-neutral-500 mt-1 block font-mono">{capacityPercent}% full</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Active Sorting Lines</span>
            <Layers className="w-4 h-4 text-blue-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">4 of 4</span>
            <span className="text-xs text-neutral-500 font-medium">lines</span>
          </div>
          <span className="text-[10px] text-blue-700 mt-1 block">Optical NIR & Air Density Sorters</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Material Recovery Rate</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-emerald-700">98.4%</span>
            <span className="text-xs text-neutral-500 font-medium">efficiency</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-1 block">&lt;1.6% residual contamination</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Monthly Processed</span>
            <Scale className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">42,850</span>
            <span className="text-xs text-neutral-500 font-medium">kg</span>
          </div>
          <span className="text-[10px] text-amber-700 mt-1 block">Baled & sent to smelters/mills</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-neutral-200 pb-2">
        <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg">
          <button
            onClick={() => setActiveTab('batches')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'batches'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Live Material Processing Batches ({batches.length})
          </button>
          <button
            onClick={() => setActiveTab('categories')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'categories'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Accepted Waste Streams & Capacities
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'stats'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            Material Yield Analytics
          </button>
        </div>
      </div>

      {/* TAB 1: BATCH PROCESSING PIPELINE */}
      {activeTab === 'batches' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-xs text-neutral-900">Active Material Pipeline & Processing Stages</h3>
              <p className="text-[11px] text-neutral-500">Track and advance bulk batches from truck intake through optical sorting to reprocessing</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-100">
                <tr>
                  <th className="py-2.5 px-4">Batch ID</th>
                  <th className="py-2.5 px-4">Material Category</th>
                  <th className="py-2.5 px-4">Batch Weight</th>
                  <th className="py-2.5 px-4">Received Time</th>
                  <th className="py-2.5 px-4">Purity Rate</th>
                  <th className="py-2.5 px-4">Current Processing Stage</th>
                  <th className="py-2.5 px-4 text-right">Advance Stage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {batches.map(batch => (
                  <tr key={batch.id} className="hover:bg-neutral-50/60">
                    <td className="py-3 px-4 font-mono font-semibold text-neutral-800">
                      #{batch.id}
                    </td>
                    <td className="py-3 px-4 font-medium text-neutral-800">{batch.category}</td>
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                      {batch.weightKg} kg
                    </td>
                    <td className="py-3 px-4 text-neutral-500 font-mono">{batch.receivedAt}</td>
                    <td className="py-3 px-4 font-mono text-emerald-700 font-semibold">
                      {batch.purityScore}%
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-block py-0.5 px-2.5 rounded-md text-[11px] font-semibold bg-neutral-100 text-neutral-800 border border-neutral-200">
                        {batch.stage}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      {batch.stage !== 'Reprocessed (Pellet/Pulp)' ? (
                        <button
                          onClick={() => handleAdvanceStage(batch.id)}
                          className="inline-flex items-center gap-1 py-1 px-2.5 text-[11px] font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
                        >
                          Advance Step <ArrowRight className="w-3 h-3" />
                        </button>
                      ) : (
                        <span className="text-[11px] font-semibold text-emerald-600 flex items-center justify-end gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Baled
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ACCEPTED CATEGORIES MANAGEMENT */}
      {activeTab === 'categories' && (
        <div className="bg-white rounded-2xl p-5 border border-neutral-200 shadow-xs space-y-4">
          <div>
            <h3 className="font-bold text-xs text-neutral-900">Facility Waste Acceptance Configuration</h3>
            <p className="text-[11px] text-neutral-500">
              Toggle which material streams this recycling facility currently accepts from municipal collectors
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {(
              [
                'Plastic',
                'Paper',
                'Glass',
                'Metal',
                'Organic',
                'Electronic Waste',
                'Hazardous Waste',
                'Mixed Waste',
              ] as WasteCategory[]
            ).map(cat => {
              const isAccepted = centre.acceptedCategories.includes(cat);
              return (
                <div
                  key={cat}
                  onClick={() => handleToggleCategory(cat)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    isAccepted
                      ? 'border-emerald-600 bg-emerald-50/70 ring-1 ring-emerald-600'
                      : 'border-neutral-200 bg-neutral-50 opacity-60 hover:opacity-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-neutral-900">{cat}</span>
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isAccepted ? 'bg-emerald-600' : 'bg-neutral-300'
                      }`}
                    />
                  </div>
                  <span className="text-[10px] text-neutral-500 block">
                    {isAccepted ? '✓ Currently Accepted' : '✗ Suspended'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: MONTHLY MATERIAL RECOVERY ANALYTICS */}
      {activeTab === 'stats' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-3">
            <h4 className="font-bold text-xs text-neutral-900">Output Stream Destinations</h4>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between p-2.5 bg-neutral-50 rounded-lg">
                <span className="text-neutral-700">R-PET Flakes & Pellets (Textile & Bottle-to-Bottle)</span>
                <span className="font-mono font-bold text-neutral-900">18,200 kg</span>
              </div>
              <div className="flex justify-between p-2.5 bg-neutral-50 rounded-lg">
                <span className="text-neutral-700">De-inked Kraft Fiber Pulp (Packaging Mills)</span>
                <span className="font-mono font-bold text-neutral-900">15,400 kg</span>
              </div>
              <div className="flex justify-between p-2.5 bg-neutral-50 rounded-lg">
                <span className="text-neutral-700">Crushed Cullet (Glass Container Works)</span>
                <span className="font-mono font-bold text-neutral-900">6,100 kg</span>
              </div>
              <div className="flex justify-between p-2.5 bg-neutral-50 rounded-lg">
                <span className="text-neutral-700">Baled Shredded Aluminum Scrap (Secondary Smelters)</span>
                <span className="font-mono font-bold text-neutral-900">3,150 kg</span>
              </div>
            </div>
          </div>

          <div className="bg-emerald-50/80 p-5 rounded-2xl border border-emerald-200 text-xs text-emerald-950 space-y-2">
            <h4 className="font-bold flex items-center gap-1.5 text-emerald-900">
              <Sparkles className="w-4 h-4 text-emerald-700" /> Circular Economy Certified Facility
            </h4>
            <p className="text-[11px] leading-relaxed text-emerald-800">
              This facility operates in direct integration with Bruhat Bengaluru Mahanagara Palike (BBMP)
              solid waste management rules. All verified shipments receive digital compliance certificates
              for municipal green audit reporting.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
