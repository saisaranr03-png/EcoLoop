/**
 * AI Waste Segregation Assistant & Encyclopedia
 * Feature 2: Interactive assistant chat interface with prompt suggestions,
 * detailed safety alerts, and a searchable matrix of common household materials.
 */

import React, { useState } from 'react';
import {
  ChatMessage,
  FREQUENT_QUESTIONS,
  answerSegregationQuestion,
} from '../services/aiAssistant';
import { WASTE_ENCYCLOPEDIA } from '../services/store';
import { WasteGuideItem, WasteCategory } from '../types';
import {
  Bot,
  Send,
  Search,
  Sparkles,
  ShieldAlert,
  HelpCircle,
  BookOpen,
  Filter,
} from 'lucide-react';

interface AiAssistantTabProps {
  onScheduleForCategory?: (cat: WasteCategory) => void;
}

export const AiAssistantTab: React.FC<AiAssistantTabProps> = ({ onScheduleForCategory }) => {
  const [activeSubTab, setActiveSubTab] = useState<'chat' | 'encyclopedia'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm1',
      sender: 'assistant',
      text: "Hello! I am your EcoLoop Segregation Assistant. Ask me how to segregate or recycle any household item—from batteries and pizza boxes to plastics and e-waste.",
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Encyclopedia state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('All');
  const [selectedGuideItem, setSelectedGuideItem] = useState<WasteGuideItem | null>(null);

  const handleSendMessage = (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInputText('');
    setIsTyping(true);

    setTimeout(() => {
      const response = answerSegregationQuestion(text);
      const botMsg: ChatMessage = {
        id: `msg_bot_${Date.now()}`,
        sender: 'assistant',
        text: response.answer,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        recommendedCategory: response.recommendedCategory,
        safetyAlert: response.safetyAlert,
        quickActions: response.quickActions,
      };
      setMessages(prev => [...prev, botMsg]);
      setIsTyping(false);
    }, 450);
  };

  const filteredEncyclopedia = WASTE_ENCYCLOPEDIA.filter(item => {
    const matchesSearch =
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.instructions.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat =
      selectedCategoryFilter === 'All' || item.category === selectedCategoryFilter;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-4">
      {/* Sub-navigation Segmented Control */}
      <div className="flex items-center justify-between border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-lg font-bold text-neutral-900">AI Segregation Assistant & Waste Guide</h2>
          <p className="text-xs text-neutral-500">Expert guidance on proper segregation, safety warnings, and municipal disposal rules</p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg">
          <button
            onClick={() => setActiveSubTab('chat')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubTab === 'chat'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Bot className="w-3.5 h-3.5" /> Interactive Chat
          </button>
          <button
            onClick={() => setActiveSubTab('encyclopedia')}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeSubTab === 'encyclopedia'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" /> 50+ Item Encyclopedia
          </button>
        </div>
      </div>

      {activeSubTab === 'chat' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Main Chat Box */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-neutral-200 shadow-xs flex flex-col h-[520px]">
            {/* Messages Area */}
            <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
              {messages.map(m => (
                <div
                  key={m.id}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl p-3.5 text-xs ${
                      m.sender === 'user'
                        ? 'bg-emerald-600 text-white rounded-tr-none'
                        : 'bg-neutral-50 border border-neutral-200 text-neutral-800 rounded-tl-none space-y-2'
                    }`}
                  >
                    <div className="whitespace-pre-line leading-relaxed">{m.text}</div>

                    {m.safetyAlert && (
                      <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-[11px] text-amber-900 flex items-start gap-1.5">
                        <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                        <span>{m.safetyAlert}</span>
                      </div>
                    )}

                    {m.recommendedCategory && (
                      <div className="pt-1.5 border-t border-neutral-200/70 flex items-center justify-between text-[11px]">
                        <span className="text-neutral-500">Classified Category:</span>
                        <span className="font-semibold text-emerald-700">
                          {m.recommendedCategory}
                        </span>
                      </div>
                    )}

                    <div
                      className={`text-[10px] mt-1 text-right ${
                        m.sender === 'user' ? 'text-emerald-100' : 'text-neutral-400'
                      }`}
                    >
                      {m.timestamp}
                    </div>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-neutral-50 border border-neutral-200 rounded-2xl rounded-tl-none p-3 text-xs text-neutral-500 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce" />
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.15s]" />
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-bounce [animation-delay:0.3s]" />
                    <span className="ml-1 text-[11px]">Checking environmental safety matrix...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Input Form */}
            <form
              onSubmit={e => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="p-3 border-t border-neutral-100 bg-neutral-50/50 rounded-b-2xl flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="Ask e.g. 'Can greasy pizza boxes be recycled?' or 'Where to drop batteries?'"
                className="flex-1 px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 bg-white"
              />
              <button
                type="submit"
                disabled={!inputText.trim()}
                className="p-2 text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 rounded-xl transition-colors shadow-xs"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>

          {/* Quick Prompt Suggester Sidebar */}
          <div className="space-y-3">
            <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
              <h3 className="text-xs font-bold text-neutral-800 flex items-center gap-1.5 mb-2.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" /> Frequently Asked Questions
              </h3>
              <div className="space-y-1.5">
                {FREQUENT_QUESTIONS.map((q, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSendMessage(q)}
                    className="w-full text-left p-2 rounded-xl text-xs text-neutral-700 bg-neutral-50 hover:bg-emerald-50/80 hover:text-emerald-900 border border-neutral-200/60 transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200 text-xs text-emerald-900 space-y-2">
              <div className="font-semibold flex items-center gap-1.5">
                <HelpCircle className="w-4 h-4 text-emerald-700" /> Pro-Tip: Zero Contamination Rule
              </div>
              <p className="text-[11px] text-emerald-800 leading-relaxed">
                Recycling mills reject entire bales if food residue exceeds 5%. Always rinse containers and keep dry recyclables away from rain.
              </p>
            </div>
          </div>
        </div>
      ) : (
        /* 50+ Item Encyclopedia View */
        <div className="space-y-3">
          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 bg-white p-3 rounded-2xl border border-neutral-200 shadow-xs">
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by material (e.g., milk jug, cardboard, lithium, CFL tube, cans)..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
              />
            </div>
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <Filter className="w-3.5 h-3.5 text-neutral-400 shrink-0" />
              <select
                value={selectedCategoryFilter}
                onChange={e => setSelectedCategoryFilter(e.target.value)}
                className="text-xs py-1.5 px-3 rounded-xl border border-neutral-200 bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              >
                <option value="All">All Categories</option>
                <option value="Plastic">Plastic</option>
                <option value="Paper">Paper</option>
                <option value="Glass">Glass</option>
                <option value="Metal">Metal</option>
                <option value="Organic">Organic</option>
                <option value="Electronic Waste">Electronic Waste</option>
                <option value="Hazardous Waste">Hazardous Waste</option>
                <option value="Mixed Waste">Mixed Waste</option>
              </select>
            </div>
          </div>

          {/* Grid of Encyclopedia Items */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {filteredEncyclopedia.map(item => (
              <div
                key={item.id}
                onClick={() => setSelectedGuideItem(item)}
                className="bg-white p-4 rounded-xl border border-neutral-200 hover:border-emerald-300 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <h4 className="font-semibold text-xs text-neutral-900 leading-snug">
                      {item.name}
                    </h4>
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0 mt-1"
                      style={{ backgroundColor: item.binColor }}
                    />
                  </div>
                  <div className="text-[11px] text-neutral-500 mb-2">
                    <span>{item.category}</span>
                    <span aria-hidden="true" className="mx-1">·</span>
                    <span className="font-medium text-emerald-700">{item.recyclability}</span>
                  </div>
                  <p className="text-[11px] text-neutral-600 line-clamp-2 leading-relaxed">
                    {item.instructions}
                  </p>
                </div>

                {item.safetyWarning && (
                  <div className="mt-2.5 pt-2 border-t border-neutral-100 flex items-center gap-1.5 text-[10px] text-amber-800">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0 text-amber-600" />
                    <span className="truncate">{item.safetyWarning}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {filteredEncyclopedia.length === 0 && (
            <div className="text-center py-12 bg-white rounded-2xl border border-neutral-200 p-6">
              <Search className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
              <p className="text-xs font-semibold text-neutral-800">No matching items found</p>
              <p className="text-[11px] text-neutral-500 mt-0.5">Try searching for terms like "bottle", "cardboard", or "batteries"</p>
            </div>
          )}

          {/* Detail Slideout/Modal */}
          {selectedGuideItem && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs">
              <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95">
                <div className="flex items-start justify-between pb-3 border-b border-neutral-100">
                  <div>
                    <h3 className="font-bold text-neutral-900 text-sm">{selectedGuideItem.name}</h3>
                    <div className="text-xs text-neutral-500 mt-0.5">
                      <span>{selectedGuideItem.category}</span>
                      <span aria-hidden="true" className="mx-1">·</span>
                      <span className="font-semibold text-emerald-700">{selectedGuideItem.recyclability}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => setSelectedGuideItem(null)}
                    className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100"
                  >
                    ✕
                  </button>
                </div>

                <div className="py-4 space-y-3 text-xs">
                  <div>
                    <span className="font-semibold text-neutral-800 block mb-1">Standard Disposal Procedure:</span>
                    <p className="text-neutral-600 leading-relaxed bg-neutral-50 p-2.5 rounded-lg border border-neutral-200/60">
                      {selectedGuideItem.instructions}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-2.5 bg-emerald-50/60 rounded-lg border border-emerald-100">
                      <span className="font-semibold text-emerald-900 block text-[11px] mb-1">✓ DOs</span>
                      <ul className="text-[10px] text-emerald-800 space-y-1 list-disc list-inside">
                        {selectedGuideItem.dos.map((d, i) => <li key={i}>{d}</li>)}
                      </ul>
                    </div>
                    <div className="p-2.5 bg-red-50/60 rounded-lg border border-red-100">
                      <span className="font-semibold text-red-900 block text-[11px] mb-1">✗ DONTs</span>
                      <ul className="text-[10px] text-red-800 space-y-1 list-disc list-inside">
                        {selectedGuideItem.donts.map((d, i) => <li key={i}>{d}</li>)}
                      </ul>
                    </div>
                  </div>

                  {selectedGuideItem.safetyWarning && (
                    <div className="p-2.5 bg-amber-50 rounded-lg border border-amber-200 text-amber-900 text-[11px] flex items-start gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <span>{selectedGuideItem.safetyWarning}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      onScheduleForCategory?.(selectedGuideItem.category);
                      setSelectedGuideItem(null);
                    }}
                    className="flex-1 py-2 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
                  >
                    Schedule Collection for {selectedGuideItem.category}
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedGuideItem(null)}
                    className="py-2 px-3 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
