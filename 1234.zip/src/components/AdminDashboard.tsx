/**
 * Municipal Administrator Dashboard
 * Executive command center for city operations:
 * system KPIs, request dispatch & worker assignment, category distribution analytics,
 * user & facility registry, and CSV audit reports.
 */

import React, { useState, useEffect } from 'react';
import { store, DEMO_USERS } from '../services/store';
import { CollectionRequest, WasteCategory } from '../types';
import {
  Shield,
  Users,
  Truck,
  Factory,
  CheckCircle2,
  Clock,
  Download,
  Search,
  Filter,
  UserCheck,
  TrendingUp,
  BarChart3,
  Gift,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [requests, setRequests] = useState<CollectionRequest[]>(store.getRequests());
  const [activeTab, setActiveTab] = useState<'requests' | 'users' | 'centres' | 'rewards' | 'analytics'>('requests');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollectorToAssign, setSelectedCollectorToAssign] = useState<Record<string, string>>({});

  useEffect(() => {
    const unsub = store.subscribe(() => {
      setRequests(store.getRequests());
    });
    return unsub;
  }, []);

  const kpis = store.getPlatformKPIs();

  // Filter requests
  const filteredRequests = requests.filter(req => {
    const matchesStatus = statusFilter === 'All' || req.status === statusFilter;
    const matchesCategory = categoryFilter === 'All' || req.wasteCategory === categoryFilter;
    const matchesSearch =
      req.trackingNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.citizenName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.address.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesCategory && matchesSearch;
  });

  const handleAssignCollector = (requestId: string) => {
    const collectorName = selectedCollectorToAssign[requestId] || 'Rajesh Kumar';
    store.assignCollector(requestId, 'user_col_01', collectorName);
  };

  const handleExportCSV = () => {
    const headers = [
      'Tracking Number',
      'Citizen Name',
      'Citizen Phone',
      'Waste Category',
      'Estimated KG',
      'Actual KG',
      'Status',
      'Assigned Collector',
      'Pickup Date',
      'EcoPoints',
      'Address',
    ];

    const rows = requests.map(r => [
      `"${r.trackingNumber}"`,
      `"${r.citizenName}"`,
      `"${r.citizenPhone}"`,
      `"${r.wasteCategory}"`,
      r.estimatedKg,
      r.actualKg || '',
      `"${r.status}"`,
      `"${r.collectorName || 'Unassigned'}"`,
      `"${r.preferredDate}"`,
      r.ecoPointsAwarded || 0,
      `"${r.address.replace(/"/g, '""')}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `EcoLoop-Municipal-Audit-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-neutral-900">Municipal Solid Waste Admin Console</h1>
            <span className="text-[11px] font-semibold text-purple-800 bg-purple-50 py-0.5 px-2.5 rounded-full border border-purple-200">
              Root Authority
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            Bangalore Central Directorate · System Health: 100% Operational · Real-time municipal sync
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-1.5 py-2 px-4 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors border border-neutral-200 shadow-xs"
        >
          <Download className="w-4 h-4 text-emerald-700" /> Export Audit Report (CSV)
        </button>
      </div>

      {/* Primary KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Registered Citizens</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">{kpis.totalCitizens}</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-0.5 block">+18 new this week</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Active Collectors</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-blue-700">{kpis.totalCollectors}</span>
          </div>
          <span className="text-[10px] text-blue-700 mt-0.5 block">Across 8 City Zones</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Recycling Facilities</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-purple-700">{kpis.totalCentres}</span>
          </div>
          <span className="text-[10px] text-neutral-400 mt-0.5 block">Authorized MRFs</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <span className="text-xs text-neutral-500 font-medium block">Total Diverted</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-emerald-700">
              {kpis.totalWasteRecycledKg.toLocaleString()}
            </span>
            <span className="text-xs text-neutral-500">kg</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-0.5 block">94% diversion rate</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs col-span-2 lg:col-span-1">
          <span className="text-xs text-neutral-500 font-medium block">Pending Requests</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-2xl font-bold font-mono text-amber-600">{kpis.pendingRequests}</span>
            <span className="text-xs text-neutral-500">requests</span>
          </div>
          <span className="text-[10px] text-amber-700 mt-0.5 block">Awaiting driver assignment</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-neutral-200 overflow-x-auto pb-1 text-xs font-medium">
        <button
          onClick={() => setActiveTab('requests')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'requests'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          Collection Dispatch & Assignment ({requests.length})
        </button>
        <button
          onClick={() => setActiveTab('analytics')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'analytics'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          <BarChart3 className="w-3.5 h-3.5" /> Waste Category Distribution
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'users'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" /> User & Staff Registry
        </button>
        <button
          onClick={() => setActiveTab('centres')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'centres'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          <Factory className="w-3.5 h-3.5" /> MRF Facilities ({kpis.totalCentres})
        </button>
        <button
          onClick={() => setActiveTab('rewards')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'rewards'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:bg-neutral-100'
          }`}
        >
          <Gift className="w-3.5 h-3.5" /> EcoPoints Vouchers Ledger
        </button>
      </div>

      {/* TAB 1: REQUESTS DISPATCH */}
      {activeTab === 'requests' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden space-y-3">
          {/* Filter Bar */}
          <div className="p-3.5 bg-neutral-50/60 border-b border-neutral-100 flex flex-col md:flex-row items-center gap-3 justify-between">
            <div className="relative w-full md:w-72">
              <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-neutral-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search tracking ID, citizen, address..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-neutral-200 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
              <select
                value={statusFilter}
                onChange={e => setStatusFilter(e.target.value)}
                className="text-xs py-1.5 px-3 rounded-xl border border-neutral-200 bg-white"
              >
                <option value="All">All Statuses</option>
                <option value="Pending">Pending</option>
                <option value="Assigned">Assigned</option>
                <option value="Accepted">Accepted</option>
                <option value="On the Way">On the Way</option>
                <option value="Verified">Verified</option>
              </select>

              <select
                value={categoryFilter}
                onChange={e => setCategoryFilter(e.target.value)}
                className="text-xs py-1.5 px-3 rounded-xl border border-neutral-200 bg-white"
              >
                <option value="All">All Categories</option>
                <option value="Plastic">Plastic</option>
                <option value="Paper">Paper</option>
                <option value="Glass">Glass</option>
                <option value="Metal">Metal</option>
                <option value="Organic">Organic</option>
                <option value="Electronic Waste">E-Waste</option>
                <option value="Hazardous Waste">Hazardous</option>
              </select>
            </div>
          </div>

          {/* Requests Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-100">
                <tr>
                  <th className="py-2.5 px-4">Tracking Code</th>
                  <th className="py-2.5 px-4">Citizen & Location</th>
                  <th className="py-2.5 px-4">Waste Stream</th>
                  <th className="py-2.5 px-4">Scheduled Window</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4">Assigned Worker</th>
                  <th className="py-2.5 px-4 text-right">Dispatch Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100">
                {filteredRequests.map(req => {
                  const isPending = req.status === 'Pending';
                  return (
                    <tr key={req.id} className="hover:bg-neutral-50/60 transition-colors">
                      <td className="py-3 px-4 font-mono font-semibold text-neutral-900">
                        #{req.trackingNumber}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-neutral-800 block">{req.citizenName}</span>
                        <span className="text-[11px] text-neutral-500 line-clamp-1">{req.address}</span>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-neutral-800 block">{req.wasteCategory}</span>
                        <span className="text-[11px] text-neutral-500 font-mono">
                          {req.actualKg ? `${req.actualKg} kg (Weighed)` : `${req.estimatedKg} kg (Est.)`}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-neutral-600 font-mono text-[11px]">
                        {req.preferredDate} ({req.timeSlot})
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`inline-block py-0.5 px-2 rounded-md text-[11px] font-semibold ${
                            req.status === 'Verified'
                              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                              : req.status === 'Pending'
                              ? 'bg-neutral-100 text-neutral-700 border border-neutral-200'
                              : 'bg-blue-50 text-blue-800 border border-blue-200'
                          }`}
                        >
                          {req.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-neutral-700">
                        {req.collectorName || <span className="text-neutral-400 italic">None assigned</span>}
                      </td>
                      <td className="py-3 px-4 text-right">
                        {isPending ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <select
                              value={selectedCollectorToAssign[req.id] || 'Rajesh Kumar'}
                              onChange={e =>
                                setSelectedCollectorToAssign({
                                  ...selectedCollectorToAssign,
                                  [req.id]: e.target.value,
                                })
                              }
                              className="text-[11px] py-1 px-2 rounded-lg border border-neutral-300 bg-white"
                            >
                              <option value="Rajesh Kumar">Rajesh Kumar (Depot 3)</option>
                              <option value="Suresh Patil">Suresh Patil (Depot 4)</option>
                              <option value="Manoj Verma">Manoj Verma (Depot 1)</option>
                            </select>
                            <button
                              onClick={() => handleAssignCollector(req.id)}
                              className="py-1 px-2.5 text-[11px] font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
                            >
                              Assign
                            </button>
                          </div>
                        ) : (
                          <span className="text-[11px] text-neutral-400">Assigned</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: ANALYTICS & CATEGORY DISTRIBUTION */}
      {activeTab === 'analytics' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-3">
            <h3 className="font-bold text-xs text-neutral-900">Waste Streams Recovered (kg)</h3>
            <div className="space-y-2.5 pt-2 text-xs">
              {Object.entries(kpis.categoryBreakdown).map(([cat, kg]) => (
                <div key={cat} className="space-y-1">
                  <div className="flex justify-between">
                    <span className="font-medium text-neutral-700">{cat}</span>
                    <span className="font-mono font-bold text-neutral-900">{kg.toFixed(1)} kg</span>
                  </div>
                  <div className="w-full bg-neutral-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-full rounded-full"
                      style={{
                        width: `${Math.min(100, Math.round((kg / (kpis.totalWasteCollectedKg || 1)) * 100))}%`,
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-3">
            <h3 className="font-bold text-xs text-neutral-900">City Environmental Net Savings</h3>
            <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                <span className="text-neutral-500 text-[11px] block">Landfill Volume Saved</span>
                <span className="text-base font-bold font-mono text-neutral-900">
                  {kpis.impact.landfillAvoidedM3} m³
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                <span className="text-neutral-500 text-[11px] block">CO₂ Emissions Avoided</span>
                <span className="text-base font-bold font-mono text-neutral-900">
                  {kpis.impact.co2AvoidedKg} kg
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                <span className="text-neutral-500 text-[11px] block">Water Saved</span>
                <span className="text-base font-bold font-mono text-neutral-900">
                  {kpis.impact.waterSavedLiters.toLocaleString()} L
                </span>
              </div>
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200/60">
                <span className="text-neutral-500 text-[11px] block">Mature Trees Saved</span>
                <span className="text-base font-bold font-mono text-neutral-900">
                  {kpis.impact.treesSaved} trees
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: USER REGISTRY */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100">
            <h3 className="font-bold text-xs text-neutral-900">Registered System Stakeholders</h3>
            <p className="text-[11px] text-neutral-500">Citizens, Route Workers, Facility Managers, and Municipal Staff</p>
          </div>
          <div className="divide-y divide-neutral-100 text-xs">
            {Object.values(DEMO_USERS).map(u => (
              <div key={u.id} className="p-3.5 flex items-center justify-between hover:bg-neutral-50">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-neutral-900">{u.name}</span>
                    <span className="text-[10px] font-semibold py-0.5 px-2 rounded-full uppercase bg-neutral-100 text-neutral-700 border border-neutral-200">
                      {u.role}
                    </span>
                  </div>
                  <span className="text-[11px] text-neutral-500">{u.email} · {u.phone}</span>
                </div>
                <div className="text-right text-[11px] text-neutral-500">
                  {u.address}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: RECYCLING CENTRES */}
      {activeTab === 'centres' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {store.getCentres().map(c => (
            <div key={c.id} className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-neutral-900 text-sm">{c.name}</h4>
                <span className="font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  {c.status}
                </span>
              </div>
              <p className="text-neutral-500 text-[11px]">{c.address}</p>
              <div className="pt-2 text-[11px] text-neutral-600 space-y-1">
                <div><strong>Hours:</strong> {c.openHours}</div>
                <div><strong>Contact:</strong> {c.phone} · {c.email}</div>
                <div className="font-mono"><strong>Capacity:</strong> {c.currentCapacityKg.toLocaleString()} / {c.maxCapacityKg.toLocaleString()} kg</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 5: REWARDS REDEMPTION AUDIT */}
      {activeTab === 'rewards' && (
        <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-4 border-b border-neutral-100">
            <h3 className="font-bold text-xs text-neutral-900">EcoPoints Redemption Voucher Audit Log</h3>
            <p className="text-[11px] text-neutral-500">Validating merchant redemption codes and anti-fraud balances</p>
          </div>
          <div className="divide-y divide-neutral-100 text-xs">
            {store.getRedemptions().map(red => (
              <div key={red.id} className="p-3.5 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-neutral-800">{red.rewardTitle}</span>
                  <span className="text-[11px] text-neutral-500 block font-mono">
                    Code: {red.voucherCode} · Redeemed by {red.userName}
                  </span>
                </div>
                <div className="text-right">
                  <span className="font-mono font-bold text-amber-700">-{red.pointsSpent} pts</span>
                  <span className="text-[10px] text-neutral-400 block">{new Date(red.redeemedAt).toLocaleDateString()}</span>
                </div>
              </div>
            ))}
            {store.getRedemptions().length === 0 && (
              <div className="p-6 text-center text-xs text-neutral-500">
                No redemptions logged yet. Points can be redeemed in the Citizen dashboard rewards store.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
