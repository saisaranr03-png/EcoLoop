/**
 * QR Code Verification Scanner for Collectors
 * Allows camera feed simulation or direct QR token entry, scales weighing confirmation,
 * and fraud-prevention duplicate checks.
 */

import React, { useState } from 'react';
import { CollectionRequest } from '../types';
import { store } from '../services/store';
import { X, QrCode, Scale, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface QrScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  preSelectedRequest?: CollectionRequest | null;
  onVerifiedSuccess?: (req: CollectionRequest) => void;
}

export const QrScannerModal: React.FC<QrScannerModalProps> = ({
  isOpen,
  onClose,
  preSelectedRequest,
  onVerifiedSuccess,
}) => {
  const [tokenInput, setTokenInput] = useState(preSelectedRequest?.qrCodeToken || '');
  const [actualWeight, setActualWeight] = useState(
    preSelectedRequest?.estimatedKg?.toString() || '5.0'
  );
  const [collectorNotes, setCollectorNotes] = useState('Weighed on digital field scale. Clean segregation verified.');
  const [statusMessage, setStatusMessage] = useState<{
    type: 'success' | 'error' | null;
    text: string;
  }>({ type: null, text: '' });
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  // Active requests that can be quickly picked for simulation
  const pendingOrAccepted = store.getRequests().filter(
    r => r.status === 'Accepted' || r.status === 'On the Way' || r.status === 'Assigned'
  );

  const handleSimulateSelect = (req: CollectionRequest) => {
    setTokenInput(req.qrCodeToken);
    setActualWeight(req.estimatedKg.toString());
    setStatusMessage({ type: null, text: '' });
  };

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tokenInput.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter or scan a valid QR Code token.' });
      return;
    }

    const weightNum = parseFloat(actualWeight);
    if (isNaN(weightNum) || weightNum <= 0) {
      setStatusMessage({ type: 'error', text: 'Please enter a valid verified weight in kg.' });
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      const res = store.verifyQrCollection(tokenInput, weightNum, collectorNotes);
      setIsProcessing(false);

      if (res.success && res.request) {
        setStatusMessage({ type: 'success', text: res.message });
        try {
          confetti({
            particleCount: 60,
            spread: 55,
            origin: { y: 0.6 },
            colors: ['#059669', '#10B981', '#34D399'],
          });
        } catch {
          // ignore if canvas-confetti is not loaded
        }
        onVerifiedSuccess?.(res.request);
        setTimeout(() => {
          onClose();
        }, 1800);
      } else {
        setStatusMessage({ type: 'error', text: res.message });
      }
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <QrCode className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 text-sm">Collection QR Verification</h3>
              <p className="text-xs text-neutral-500">Scan citizen QR code and confirm weight</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Simulator Picker */}
        {pendingOrAccepted.length > 0 && (
          <div className="mt-3 p-2.5 bg-neutral-50 rounded-xl border border-neutral-200/60 text-xs">
            <span className="font-medium text-neutral-600 block mb-1.5">
              Simulate Doorstep QR Scan (Available Scheduled Pickups):
            </span>
            <div className="flex flex-wrap gap-1.5">
              {pendingOrAccepted.slice(0, 3).map(req => (
                <button
                  key={req.id}
                  type="button"
                  onClick={() => handleSimulateSelect(req)}
                  className={`py-1 px-2.5 rounded-lg border text-[11px] transition-colors ${
                    tokenInput === req.qrCodeToken
                      ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-semibold'
                      : 'bg-white border-neutral-200 text-neutral-700 hover:bg-neutral-100'
                  }`}
                >
                  #{req.trackingNumber} ({req.wasteCategory})
                </button>
              ))}
            </div>
          </div>
        )}

        <form onSubmit={handleVerify} className="mt-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              QR Code Token / Tracking Code
            </label>
            <div className="relative">
              <input
                type="text"
                value={tokenInput}
                onChange={e => setTokenInput(e.target.value)}
                placeholder="e.g. ECOLOOP-ECL-2026-8912-XXXX"
                className="w-full px-3 py-2 text-xs font-mono rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 uppercase"
                required
              />
              <span className="absolute right-2.5 top-2.5 text-neutral-400">
                <QrCode className="w-4 h-4" />
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1 flex items-center justify-between">
              <span>Actual Verified Weight (KG)</span>
              <span className="text-[11px] font-normal text-emerald-600 flex items-center gap-1">
                <Scale className="w-3.5 h-3.5" /> Digital Field Scales
              </span>
            </label>
            <input
              type="number"
              step="0.1"
              min="0.1"
              value={actualWeight}
              onChange={e => setActualWeight(e.target.value)}
              placeholder="Enter measured weight in kg"
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600 font-mono"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Field Notes / Quality Check
            </label>
            <input
              type="text"
              value={collectorNotes}
              onChange={e => setCollectorNotes(e.target.value)}
              placeholder="e.g. Clean dry paper, no grease, weighed on truck scale"
              className="w-full px-3 py-2 text-xs rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-600"
            />
          </div>

          {statusMessage.text && (
            <div
              className={`p-3 rounded-lg text-xs flex items-start gap-2 ${
                statusMessage.type === 'success'
                  ? 'bg-emerald-50 border border-emerald-200 text-emerald-800'
                  : 'bg-red-50 border border-red-200 text-red-800'
              }`}
            >
              {statusMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0 text-red-600 mt-0.5" />
              )}
              <span>{statusMessage.text}</span>
            </div>
          )}

          <div className="flex gap-2.5 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2 px-3 text-xs font-medium text-neutral-700 bg-neutral-100 hover:bg-neutral-200 rounded-lg transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 rounded-lg transition-colors shadow-xs"
            >
              {isProcessing ? (
                'Verifying...'
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" /> Confirm Collection
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
