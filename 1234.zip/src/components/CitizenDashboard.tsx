/**
 * Citizen Dashboard
 * Complete self-service environmental portal for residents:
 * pickup scheduling, request tracking, QR code access, recycling centre finder,
 * EcoPoints wallet, AI assistant, and environmental footprint.
 */

import React, { useState, useEffect } from 'react';
import { store } from '../services/store';
import { CollectionRequest, WasteCategory } from '../types';
import { LeafletMap } from './LeafletMap';
import { QrCodeModal } from './QrCodeModal';
import { SchedulePickupModal } from './SchedulePickupModal';
import { SmartWasteIdentifierModal } from './SmartWasteIdentifierModal';
import { AiAssistantTab } from './AiAssistantTab';
import { EcoPointsRewardsTab } from './EcoPointsRewardsTab';
import { EnvironmentalImpactTab } from './EnvironmentalImpactTab';
import { CommunityChallengesTab } from './CommunityChallengesTab';
import {
  Calendar,
  Clock,
  QrCode,
  Plus,
  Coins,
  Package,
  CheckCircle2,
  MapPin,
  TrendingUp,
  Camera,
  Bot,
  Gift,
  Leaf,
  Users,
  Compass,
  ArrowUpRight,
} from 'lucide-react';

export const CitizenDashboard: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const [requests, setRequests] = useState<CollectionRequest[]>(
    store.getCitizenRequests(currentUser.id)
  );
  const [activeTab, setActiveTab] = useState<
    'overview' | 'tracker' | 'map' | 'assistant' | 'rewards' | 'impact' | 'challenges'
  >('overview');

  // Modals
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [isVisionOpen, setIsVisionOpen] = useState(false);
  const [selectedQrRequest, setSelectedQrRequest] = useState<CollectionRequest | null>(null);
  const [mapCategoryFilter, setMapCategoryFilter] = useState('All');

  useEffect(() => {
    const unsub = store.subscribe(() => {
      setRequests(store.getCitizenRequests(currentUser.id));
    });
    return unsub;
  }, [currentUser.id]);

  const verifiedRequests = requests.filter(r => r.status === 'Verified');
  const activeRequests = requests.filter(r => r.status !== 'Verified' && r.status !== 'Cancelled');
  const totalRecycledKg = verifiedRequests.reduce(
    (sum, r) => sum + (r.actualKg || r.estimatedKg),
    0
  );

  const getStatusBadge = (status: CollectionRequest['status']) => {
    switch (status) {
      case 'Verified':
        return 'text-emerald-700 bg-emerald-50 border-emerald-200';
      case 'On the Way':
        return 'text-amber-800 bg-amber-50 border-amber-200';
      case 'Accepted':
      case 'Assigned':
        return 'text-blue-800 bg-blue-50 border-blue-200';
      case 'Pending':
        return 'text-neutral-700 bg-neutral-100 border-neutral-200';
      default:
        return 'text-neutral-600 bg-neutral-100 border-neutral-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-white rounded-2xl p-6 border border-neutral-200 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-neutral-900">
              Welcome back, {currentUser.name}
            </h1>
            <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 py-0.5 px-2.5 rounded-full border border-emerald-200">
              Citizen / Resident
            </span>
          </div>
          <p className="text-xs text-neutral-500 mt-1">
            {currentUser.address} · Sector 4 Municipal Waste Service Zone
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <button
            onClick={() => setIsVisionOpen(true)}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 py-2 px-3.5 text-xs font-semibold text-neutral-800 bg-neutral-100 hover:bg-neutral-200 rounded-xl transition-colors"
          >
            <Camera className="w-4 h-4 text-emerald-700" /> Smart Identify Waste
          </button>
          <button
            onClick={() => setIsScheduleOpen(true)}
            className="flex-1 md:flex-initial flex items-center justify-center gap-1.5 py-2 px-4 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" /> Schedule Pickup
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Total Recycled</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {totalRecycledKg.toFixed(1)}
            </span>
            <span className="text-xs text-neutral-500 font-medium">kg</span>
          </div>
          <span className="text-[10px] text-emerald-700 mt-0.5 block">100% diverted from landfill</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>Completed Pickups</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {verifiedRequests.length}
            </span>
            <span className="text-xs text-neutral-500 font-medium">collections</span>
          </div>
          <span className="text-[10px] text-neutral-400 mt-0.5 block">Verified by depot scales</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>EcoPoints Balance</span>
            <Coins className="w-4 h-4 text-amber-500" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-emerald-700">
              {currentUser.ecoPoints || 0}
            </span>
            <span className="text-xs text-neutral-500 font-medium">pts</span>
          </div>
          <span className="text-[10px] text-amber-700 mt-0.5 block">Ready for voucher redemption</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs">
          <div className="flex items-center justify-between text-neutral-500 text-xs mb-1">
            <span>CO₂ Prevented</span>
            <Leaf className="w-4 h-4 text-teal-600" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold font-mono text-neutral-900">
              {(totalRecycledKg * 1.48).toFixed(1)}
            </span>
            <span className="text-xs text-neutral-500 font-medium">kg CO₂e</span>
          </div>
          <span className="text-[10px] text-teal-700 mt-0.5 block">Certified LCA equivalent</span>
        </div>
      </div>

      {/* Main Tabbed Interface */}
      <div className="flex items-center gap-1 border-b border-neutral-200 overflow-x-auto no-scrollbar pb-1 text-xs font-medium">
        <button
          onClick={() => setActiveTab('overview')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'overview'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          My Pickups & Tracking ({requests.length})
        </button>
        <button
          onClick={() => setActiveTab('map')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'map'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Compass className="w-3.5 h-3.5" /> Nearby Recycling Centres
        </button>
        <button
          onClick={() => setActiveTab('assistant')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'assistant'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Bot className="w-3.5 h-3.5" /> AI Segregation Bot
        </button>
        <button
          onClick={() => setActiveTab('rewards')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'rewards'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Gift className="w-3.5 h-3.5" /> EcoPoints Wallet & Rewards
        </button>
        <button
          onClick={() => setActiveTab('impact')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'impact'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Leaf className="w-3.5 h-3.5" /> Environmental Impact
        </button>
        <button
          onClick={() => setActiveTab('challenges')}
          className={`py-2 px-3.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
            activeTab === 'challenges'
              ? 'bg-emerald-600 text-white font-semibold shadow-xs'
              : 'text-neutral-600 hover:text-neutral-900 hover:bg-neutral-100'
          }`}
        >
          <Users className="w-3.5 h-3.5" /> Community Challenges
        </button>
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Active / Upcoming Collections */}
          {activeRequests.length > 0 && (
            <div className="bg-white rounded-2xl p-5 border border-neutral-200 shadow-xs space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-neutral-900">Active Upcoming Collections</h3>
                  <p className="text-[11px] text-neutral-500">
                    Show your pickup QR code to the collector at arrival for instant weight verification
                  </p>
                </div>
                <span className="text-xs font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                  {activeRequests.length} Scheduled
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
                {activeRequests.map(req => (
                  <div
                    key={req.id}
                    className="p-4 rounded-xl border border-neutral-200 bg-neutral-50/70 flex flex-col justify-between space-y-3 hover:border-emerald-300 transition-colors"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-mono font-bold text-neutral-900">
                          #{req.trackingNumber}
                        </span>
                        <span
                          className={`text-[11px] font-semibold py-0.5 px-2 rounded-md border ${getStatusBadge(
                            req.status
                          )}`}
                        >
                          {req.status}
                        </span>
                      </div>

                      <div className="space-y-1 text-xs">
                        <div className="flex justify-between">
                          <span className="text-neutral-500">Material Category:</span>
                          <span className="font-semibold text-neutral-800">{req.wasteCategory}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-500">Estimated Weight:</span>
                          <span className="font-mono text-neutral-800">{req.estimatedKg} kg</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-neutral-500">Pickup Window:</span>
                          <span className="text-neutral-800">{req.preferredDate} ({req.timeSlot})</span>
                        </div>
                        {req.collectorName && (
                          <div className="flex justify-between text-blue-800">
                            <span>Assigned Worker:</span>
                            <span className="font-medium">{req.collectorName}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="pt-2 border-t border-neutral-200/60 flex items-center justify-between">
                      <span className="text-[11px] text-neutral-400">
                        Created {new Date(req.createdAt).toLocaleDateString()}
                      </span>
                      <button
                        onClick={() => setSelectedQrRequest(req)}
                        className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-emerald-800 bg-white border border-emerald-300 rounded-lg hover:bg-emerald-50 transition-colors"
                      >
                        <QrCode className="w-3.5 h-3.5" /> View Pickup QR
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Past Verified History Table */}
          <div className="bg-white rounded-2xl border border-neutral-200 shadow-xs overflow-hidden">
            <div className="p-4 border-b border-neutral-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-xs text-neutral-900">Verified Recycling History</h3>
                <p className="text-[11px] text-neutral-500">
                  All past pickups verified with actual recorded weight and rewarded EcoPoints
                </p>
              </div>
              <button
                onClick={() => setIsScheduleOpen(true)}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
              >
                + New Pickup
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-neutral-50 text-neutral-500 font-semibold border-b border-neutral-100">
                  <tr>
                    <th className="py-2.5 px-4">Tracking ID</th>
                    <th className="py-2.5 px-4">Category</th>
                    <th className="py-2.5 px-4">Weighed Quantity</th>
                    <th className="py-2.5 px-4">Verified Date</th>
                    <th className="py-2.5 px-4">Collector</th>
                    <th className="py-2.5 px-4">EcoPoints</th>
                    <th className="py-2.5 px-4 text-right">QR Record</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-100">
                  {verifiedRequests.map(req => (
                    <tr key={req.id} className="hover:bg-neutral-50/60 transition-colors">
                      <td className="py-3 px-4 font-mono font-semibold text-neutral-800">
                        #{req.trackingNumber}
                      </td>
                      <td className="py-3 px-4 font-medium text-neutral-800">{req.wasteCategory}</td>
                      <td className="py-3 px-4 font-mono font-bold text-neutral-900">
                        {req.actualKg || req.estimatedKg} kg
                      </td>
                      <td className="py-3 px-4 text-neutral-500 font-mono">
                        {req.verifiedAt ? new Date(req.verifiedAt).toLocaleDateString() : req.preferredDate}
                      </td>
                      <td className="py-3 px-4 text-neutral-600">{req.collectorName || 'EcoLoop Depot'}</td>
                      <td className="py-3 px-4 font-mono font-bold text-emerald-700">
                        +{req.ecoPointsAwarded || 0} pts
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          onClick={() => setSelectedQrRequest(req)}
                          className="p-1 text-neutral-400 hover:text-emerald-700 rounded-md transition-colors"
                          title="View Verified QR"
                        >
                          <QrCode className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {verifiedRequests.length === 0 && (
              <div className="p-8 text-center text-xs text-neutral-500">
                <Package className="w-8 h-8 text-neutral-300 mx-auto mb-2" />
                <p className="font-semibold text-neutral-700">No completed collections yet</p>
                <p className="mt-0.5">Schedule your first pickup above to earn EcoPoints!</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RECYCLING CENTRES MAP TAB */}
      {activeTab === 'map' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-3.5 rounded-2xl border border-neutral-200">
            <div>
              <h3 className="font-bold text-xs text-neutral-900">Municipal Recycling Centres & Material Recovery Facilities</h3>
              <p className="text-[11px] text-neutral-500">Locate authorized municipal drop-off hubs with accepted waste streams</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-neutral-500">Filter Category:</span>
              <select
                value={mapCategoryFilter}
                onChange={e => setMapCategoryFilter(e.target.value)}
                className="text-xs py-1.5 px-3 rounded-lg border border-neutral-200 bg-neutral-50 font-medium"
              >
                <option value="All">All Waste Streams</option>
                <option value="Plastic">Plastic</option>
                <option value="Paper">Paper</option>
                <option value="Glass">Glass</option>
                <option value="Metal">Metal</option>
                <option value="Organic">Organic</option>
                <option value="Electronic Waste">E-Waste</option>
                <option value="Hazardous Waste">Hazardous</option>
              </select>
            </div>
          </div>

          <LeafletMap
            centres={store.getCentres()}
            selectedCategory={mapCategoryFilter}
            height="480px"
          />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
            {store.getCentres().map(c => (
              <div key={c.id} className="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs text-xs space-y-1.5">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-neutral-900 truncate">{c.name}</h4>
                  <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                    {c.status}
                  </span>
                </div>
                <p className="text-neutral-500 text-[11px] leading-snug">{c.address}</p>
                <div className="text-[11px] text-neutral-600">
                  <strong>Hours:</strong> {c.openHours}
                </div>
                <div className="pt-1 text-[11px] text-neutral-500 font-mono">
                  Capacity: {c.currentCapacityKg.toLocaleString()} / {c.maxCapacityKg.toLocaleString()} kg
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI ASSISTANT TAB */}
      {activeTab === 'assistant' && (
        <AiAssistantTab
          onScheduleForCategory={cat => {
            setIsScheduleOpen(true);
          }}
        />
      )}

      {/* REWARDS TAB */}
      {activeTab === 'rewards' && <EcoPointsRewardsTab />}

      {/* ENVIRONMENTAL IMPACT TAB */}
      {activeTab === 'impact' && <EnvironmentalImpactTab />}

      {/* COMMUNITY CHALLENGES TAB */}
      {activeTab === 'challenges' && (
        <CommunityChallengesTab
          onScheduleForCategory={() => setIsScheduleOpen(true)}
        />
      )}

      {/* Modals */}
      <SchedulePickupModal
        isOpen={isScheduleOpen}
        onClose={() => setIsScheduleOpen(false)}
        onSuccess={() => setRequests(store.getCitizenRequests(currentUser.id))}
      />

      <SmartWasteIdentifierModal
        isOpen={isVisionOpen}
        onClose={() => setIsVisionOpen(false)}
        onScheduleForCategory={cat => {
          setIsScheduleOpen(true);
        }}
      />

      <QrCodeModal
        request={selectedQrRequest}
        onClose={() => setSelectedQrRequest(null)}
      />
    </div>
  );
};
