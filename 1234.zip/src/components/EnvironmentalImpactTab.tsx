/**
 * Environmental Impact Calculator
 * Implements Feature 4: Interactive calculation of landfill diversion,
 * carbon emissions avoided, clean water saved, and trees preserved with documented formulas.
 */

import React, { useState } from 'react';
import { store, calculateEnvironmentalImpact, IMPACT_FACTORS } from '../services/store';
import { Leaf, Droplets, Wind, Trees, Zap, Calculator, Info, Sliders } from 'lucide-react';

export const EnvironmentalImpactTab: React.FC = () => {
  const currentUser = store.getCurrentUser();
  const citizenRequests = store.getCitizenRequests(currentUser.id).filter(r => r.status === 'Verified');
  const personalTotalKg = citizenRequests.reduce((sum, r) => sum + (r.actualKg || r.estimatedKg), 0);

  const [activeMode, setActiveMode] = useState<'actual' | 'simulator'>('actual');
  const [sliderKg, setSliderKg] = useState<number>(35);

  const kpis = store.getPlatformKPIs();

  // Impact calculations
  const effectiveKg = activeMode === 'actual' ? (personalTotalKg || 14.0) : sliderKg;
  const impact = calculateEnvironmentalImpact(effectiveKg);

  return (
    <div className="space-y-5">
      {/* Header and Mode Selector */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-neutral-200 pb-3">
        <div>
          <h2 className="text-lg font-bold text-neutral-900">Environmental Impact Metrics & Calculator</h2>
          <p className="text-xs text-neutral-500">
            Real-time conversion factors modeling greenhouse gas reduction and resource conservation
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-neutral-100 rounded-lg">
          <button
            onClick={() => setActiveMode('actual')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeMode === 'actual'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            My Verified Footprint ({personalTotalKg.toFixed(1)} kg)
          </button>
          <button
            onClick={() => setActiveMode('simulator')}
            className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
              activeMode === 'simulator'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            <Sliders className="w-3.5 h-3.5" /> Interactive Simulator
          </button>
        </div>
      </div>

      {/* Simulator Interactive Slider if active */}
      {activeMode === 'simulator' && (
        <div className="bg-emerald-50/80 p-4 rounded-2xl border border-emerald-200 space-y-3">
          <div className="flex items-center justify-between text-xs font-semibold text-emerald-950">
            <span className="flex items-center gap-1.5">
              <Calculator className="w-4 h-4 text-emerald-700" /> Simulate Household Waste Diversion:
            </span>
            <span className="font-mono text-base font-bold text-emerald-800">{sliderKg} kg / month</span>
          </div>
          <input
            type="range"
            min="5"
            max="250"
            step="5"
            value={sliderKg}
            onChange={e => setSliderKg(parseInt(e.target.value))}
            className="w-full h-2 bg-emerald-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
          />
          <div className="flex justify-between text-[11px] text-emerald-800 font-mono">
            <span>5 kg (Small Studio)</span>
            <span>50 kg (Family of 4)</span>
            <span>250 kg (Apartment Wing)</span>
          </div>
        </div>
      )}

      {/* Primary Impact Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <Wind className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-neutral-500 font-medium">CO₂ Emissions Prevented</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono text-neutral-900">{impact.co2AvoidedKg}</span>
              <span className="text-xs text-neutral-500 font-medium">kg CO₂e</span>
            </div>
            <span className="text-[10px] text-emerald-700">~{IMPACT_FACTORS.co2KgPerKg} kg CO₂ / kg</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
            <Droplets className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-neutral-500 font-medium">Clean Water Conserved</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono text-neutral-900">{impact.waterSavedLiters}</span>
              <span className="text-xs text-neutral-500 font-medium">Liters</span>
            </div>
            <span className="text-[10px] text-blue-700">Industrial process savings</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
            <Leaf className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-neutral-500 font-medium">Landfill Volume Saved</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono text-neutral-900">{impact.landfillAvoidedM3}</span>
              <span className="text-xs text-neutral-500 font-medium">m³ volume</span>
            </div>
            <span className="text-[10px] text-amber-700">Compressed space</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-neutral-200 shadow-xs flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center shrink-0">
            <Zap className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-neutral-500 font-medium">Electricity Conserved</span>
            <div className="flex items-baseline gap-1 mt-0.5">
              <span className="text-xl font-bold font-mono text-neutral-900">{impact.kwhEnergySaved}</span>
              <span className="text-xs text-neutral-500 font-medium">kWh</span>
            </div>
            <span className="text-[10px] text-teal-700">Recycled vs virgin smelting</span>
          </div>
        </div>
      </div>

      {/* Visual Progress Breakdown Bar Chart */}
      <div className="bg-white p-5 rounded-2xl border border-neutral-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-xs text-neutral-900">City Municipal Solid Waste Recovery Impact</h3>
            <p className="text-[11px] text-neutral-500">Aggregate impact of {kpis.totalCitizens} participating citizens across Bangalore</p>
          </div>
          <span className="font-mono text-xs font-semibold text-emerald-800 bg-emerald-50 py-1 px-2.5 rounded-lg border border-emerald-200">
            {kpis.totalWasteRecycledKg.toLocaleString()} kg Diverted to Date
          </span>
        </div>

        {/* Visual Progress bars */}
        <div className="space-y-3 pt-2">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-neutral-700">Plastic Diversion (PET / HDPE)</span>
              <span className="font-mono text-neutral-500">
                {kpis.categoryBreakdown['Plastic'] || 5.8} kg (~{Math.round(((kpis.categoryBreakdown['Plastic'] || 5.8) / (kpis.totalWasteCollectedKg || 1)) * 100)}%)
              </span>
            </div>
            <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
              <div className="bg-blue-600 h-full rounded-full" style={{ width: '38%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-neutral-700">Corrugated Cardboard & Paper Pulp</span>
              <span className="font-mono text-neutral-500">
                {kpis.categoryBreakdown['Paper'] || 8.2} kg (~{Math.round(((kpis.categoryBreakdown['Paper'] || 8.2) / (kpis.totalWasteCollectedKg || 1)) * 100)}%)
              </span>
            </div>
            <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
              <div className="bg-emerald-600 h-full rounded-full" style={{ width: '45%' }} />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="font-medium text-neutral-700">Non-Ferrous Metals (Aluminum Cans / Copper)</span>
              <span className="font-mono text-neutral-500">
                {kpis.categoryBreakdown['Metal'] || 3.5} kg (~12%)
              </span>
            </div>
            <div className="w-full bg-neutral-100 rounded-full h-2.5 overflow-hidden">
              <div className="bg-amber-500 h-full rounded-full" style={{ width: '12%' }} />
            </div>
          </div>
        </div>
      </div>

      {/* Transparent Methodology & Illustrative Formulas */}
      <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200/80 text-xs text-neutral-600 space-y-2">
        <div className="font-semibold text-neutral-900 flex items-center gap-1.5">
          <Info className="w-4 h-4 text-emerald-700" /> Transparent Environmental Methodology Notice
        </div>
        <p className="text-[11px] leading-relaxed text-neutral-500">
          The values presented in this dashboard are computed using documented environmental life-cycle assessment (LCA) conversion factors:
          <span className="font-mono text-neutral-700"> ~1.48 kg CO₂e / kg recycled</span> (US EPA WARM model baseline),
          <span className="font-mono text-neutral-700"> 0.0018 m³ landfill volume / kg</span>, and
          <span className="font-mono text-neutral-700"> 16.5 liters water / kg</span>.
          Actual laboratory yields vary slightly by municipal processing facility efficiency.
        </p>
      </div>
    </div>
  );
};
