/**
 * Interactive Leaflet & OpenStreetMap Component
 * Renders verified recycling depots, collection pickup stops, and routing overlays.
 */

import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { RecyclingCentre, CollectionRequest } from '../types';

interface LeafletMapProps {
  centres?: RecyclingCentre[];
  requests?: CollectionRequest[];
  selectedCategory?: string;
  center?: [number, number];
  zoom?: number;
  height?: string;
  onSelectCentre?: (centre: RecyclingCentre) => void;
  onSelectRequest?: (req: CollectionRequest) => void;
}

// Custom crisp SVG pins
const createCustomIcon = (color: string, label: string) => {
  return L.divIcon({
    className: 'custom-leaflet-marker',
    html: `
      <div style="
        background-color: ${color};
        color: white;
        width: 32px;
        height: 32px;
        border-radius: 50% 50% 50% 0;
        transform: rotate(-45deg);
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.25);
        border: 2px solid white;
      ">
        <span style="
          transform: rotate(45deg);
          font-size: 13px;
          font-weight: 700;
          font-family: 'Plus Jakarta Sans', sans-serif;
        ">${label}</span>
      </div>
    `,
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
  });
};

export const LeafletMap: React.FC<LeafletMapProps> = ({
  centres = [],
  requests = [],
  selectedCategory = 'All',
  center = [12.9716, 77.5946], // Bangalore central
  zoom = 12,
  height = '420px',
  onSelectCentre,
  onSelectRequest,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersLayerRef = useRef<L.LayerGroup | null>(null);

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center,
      zoom,
      zoomControl: true,
      scrollWheelZoom: false,
    });

    // Clean OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom: 19,
    }).addTo(map);

    markersLayerRef.current = L.layerGroup().addTo(map);
    mapInstanceRef.current = map;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update Markers when data or filters change
  useEffect(() => {
    const map = mapInstanceRef.current;
    const layer = markersLayerRef.current;
    if (!map || !layer) return;

    layer.clearLayers();
    const bounds = L.latLngBounds([]);

    // 1. Render Recycling Centres
    const filteredCentres = selectedCategory === 'All'
      ? centres
      : centres.filter(c => c.acceptedCategories.includes(selectedCategory as any));

    filteredCentres.forEach(centre => {
      const marker = L.marker([centre.latitude, centre.longitude], {
        icon: createCustomIcon('#059669', '♻'),
      });

      const popupContent = document.createElement('div');
      popupContent.className = 'p-1';
      popupContent.innerHTML = `
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; min-width: 220px;">
          <div style="display: flex; align-items: center; justify-content: space-between; gap: 8px;">
            <strong style="font-size: 14px; color: #0f172a;">${centre.name}</strong>
            <span style="font-size: 11px; font-weight: 600; color: #059669;">${centre.status}</span>
          </div>
          <p style="font-size: 12px; color: #475569; margin: 4px 0;">${centre.address}</p>
          <div style="font-size: 11px; color: #64748b; margin: 6px 0;">
            <strong>Hours:</strong> ${centre.openHours}
          </div>
          <div style="font-size: 11px; color: #64748b; margin-bottom: 8px;">
            <strong>Capacity:</strong> ${centre.currentCapacityKg.toLocaleString()} / ${centre.maxCapacityKg.toLocaleString()} kg
          </div>
          <div style="font-size: 11px; margin-bottom: 8px;">
            <span style="color: #059669; font-weight: 600;">Accepted:</span>
            ${centre.acceptedCategories.map(cat => `<span style="display: inline-block; background: #ecfdf5; color: #047857; font-size: 10px; padding: 1px 6px; border-radius: 4px; margin: 2px;">${cat}</span>`).join('')}
          </div>
          <div style="font-size: 11px; color: #334155;">
            📞 ${centre.phone}
          </div>
        </div>
      `;

      marker.bindPopup(popupContent);
      marker.on('click', () => onSelectCentre?.(centre));
      layer.addLayer(marker);
      bounds.extend([centre.latitude, centre.longitude]);
    });

    // 2. Render Collection Requests (if provided)
    requests.forEach(req => {
      const isVerified = req.status === 'Verified';
      const color = isVerified ? '#10B981' : req.status === 'On the Way' ? '#F59E0B' : '#3B82F6';
      const marker = L.marker([req.latitude, req.longitude], {
        icon: createCustomIcon(color, '📦'),
      });

      marker.bindPopup(`
        <div style="font-family: 'Plus Jakarta Sans', sans-serif; min-width: 200px;">
          <div style="font-weight: 700; font-size: 13px; color: #0f172a;">#${req.trackingNumber}</div>
          <div style="font-size: 12px; color: #475569; margin: 2px 0;"><strong>Citizen:</strong> ${req.citizenName}</div>
          <div style="font-size: 12px; color: #475569;"><strong>Waste:</strong> ${req.estimatedKg} kg ${req.wasteCategory}</div>
          <div style="font-size: 11px; color: #64748b; margin: 4px 0;">📍 ${req.address}</div>
          <div style="font-size: 11px; font-weight: 600; color: ${color};">Status: ${req.status}</div>
        </div>
      `);
      marker.on('click', () => onSelectRequest?.(req));
      layer.addLayer(marker);
      bounds.extend([req.latitude, req.longitude]);
    });

    // 3. Connect active collector stops with polyline route if multiple requests
    if (requests.length > 1) {
      const coords: [number, number][] = requests.map(r => [r.latitude, r.longitude]);
      const routeLine = L.polyline(coords, {
        color: '#059669',
        weight: 3,
        opacity: 0.7,
        dashArray: '6, 8',
      });
      layer.addLayer(routeLine);
    }

    if (bounds.isValid() && (filteredCentres.length > 0 || requests.length > 0)) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14 });
    }
  }, [centres, requests, selectedCategory, onSelectCentre, onSelectRequest]);

  return (
    <div className="relative w-full rounded-xl overflow-hidden border border-neutral-200 shadow-sm" style={{ height }}>
      <div ref={mapContainerRef} className="w-full h-full" />
      <div className="absolute bottom-2 left-2 z-[400] bg-white/90 backdrop-blur-sm px-2.5 py-1 rounded-md text-[11px] font-medium text-neutral-600 border border-neutral-200 shadow-xs flex items-center gap-3">
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" /> Recycling Centre</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-600 inline-block" /> Pickup Stop</span>
        <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block" /> En Route</span>
      </div>
    </div>
  );
};
