/**
 * Smart Waste Identification Component
 * Implements Feature 1: Optical analysis of waste materials with instant category classification,
 * recyclability breakdown, recommended disposal bin, safety instructions, and live testing samples.
 */

import React, { useState } from 'react';
import { SAMPLE_WASTE_ITEMS, analyzeWasteImage } from '../services/aiVision';
import { WasteAnalysisResult } from '../types';
import { X, Upload, Camera, Sparkles, CheckCircle2, ShieldAlert, ArrowRight } from 'lucide-react';

interface SmartWasteIdentifierModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScheduleForCategory?: (category: string) => void;
}

export const SmartWasteIdentifierModal: React.FC<SmartWasteIdentifierModalProps> = ({
  isOpen,
  onClose,
  onScheduleForCategory,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedName, setSelectedName] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<WasteAnalysisResult | null>(null);

  if (!isOpen) return null;

  const handleSelectSample = async (sample: typeof SAMPLE_WASTE_ITEMS[0]) => {
    setSelectedName(sample.label);
    setSelectedImage(null);
    setIsAnalyzing(true);
    setResult(null);

    // Simulate analysis
    setTimeout(() => {
      setResult(sample.expectedResult);
      setIsAnalyzing(false);
    }, 500);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedName(file.name);
    const reader = new FileReader();
    reader.onload = async () => {
      const dataUri = reader.result as string;
      setSelectedImage(dataUri);
      setIsAnalyzing(true);
      setResult(null);

      const analysis = await analyzeWasteImage(dataUri, file.name);
      setResult(analysis);
      setIsAnalyzing(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full p-6 shadow-xl border border-neutral-200 animate-in fade-in zoom-in-95 duration-150 my-6">
        <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-neutral-900 text-sm">Smart Waste Identification</h3>
              <p className="text-xs text-neutral-500">
                Optical material analysis & segregation guide
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-neutral-700 rounded-lg hover:bg-neutral-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Transparent System Notice */}
        <div className="mt-3 py-1.5 px-3 bg-amber-50 rounded-lg border border-amber-200/80 text-[11px] text-amber-900 flex items-center justify-between">
          <span>Demonstration Vision Mode: Rule-based computer vision heuristic classification.</span>
          <span className="font-medium text-amber-800 underline cursor-pointer" onClick={() => setSelectedName('PET Bottle')}>
            Active
          </span>
        </div>

        {/* 1-Click Sample Testing Bar */}
        <div className="mt-4">
          <span className="text-xs font-semibold text-neutral-700 block mb-1.5">
            1-Click Sample Test Items:
          </span>
          <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
            {SAMPLE_WASTE_ITEMS.map(item => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectSample(item)}
                className={`p-2 rounded-xl border text-center transition-all ${
                  selectedName === item.label
                    ? 'border-emerald-600 bg-emerald-50/80 ring-1 ring-emerald-600'
                    : 'border-neutral-200 bg-neutral-50 hover:bg-white'
                }`}
              >
                <div className="text-2xl mb-1">{item.thumbnail}</div>
                <div className="text-[11px] font-medium text-neutral-800 truncate">{item.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Upload Custom Image Area */}
        <div className="mt-4">
          <label className="border-2 border-dashed border-neutral-300 hover:border-emerald-500 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition-colors bg-neutral-50/50 hover:bg-emerald-50/20">
            <Upload className="w-6 h-6 text-neutral-400 mb-1" />
            <span className="text-xs font-semibold text-neutral-700">
              Or Upload Waste Photo
            </span>
            <span className="text-[11px] text-neutral-500 mt-0.5">
              PNG, JPG up to 10MB (camera snaps supported)
            </span>
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleFileUpload}
            />
          </label>
        </div>

        {/* Uploaded Preview */}
        {selectedImage && (
          <div className="mt-3 flex items-center gap-3 p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
            <img
              src={selectedImage}
              alt="Uploaded waste preview"
              className="w-14 h-14 object-cover rounded-lg border border-neutral-300"
            />
            <div className="text-xs">
              <p className="font-semibold text-neutral-800 truncate max-w-xs">{selectedName}</p>
              <p className="text-neutral-500 text-[11px]">Image loaded · Ready for inspection</p>
            </div>
          </div>
        )}

        {/* Analyzing Spinner */}
        {isAnalyzing && (
          <div className="py-8 text-center space-y-2">
            <div className="w-8 h-8 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-xs text-neutral-600 font-medium">Analyzing polymer/material optical features...</p>
          </div>
        )}

        {/* Classification Result Card */}
        {result && !isAnalyzing && (
          <div className="mt-4 p-4 rounded-xl border border-neutral-200 bg-neutral-50/80 space-y-3 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-200/80">
              <div className="flex items-center gap-2">
                <span
                  className="w-3.5 h-3.5 rounded-full shrink-0"
                  style={{ backgroundColor: result.binHex }}
                />
                <div>
                  <h4 className="font-bold text-neutral-900 text-sm">{result.category}</h4>
                  <p className="text-[11px] text-neutral-500">{result.materialDetected}</p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-mono font-bold text-emerald-700">
                  {result.confidence}% Match
                </span>
                <span className="block text-[10px] text-neutral-400">Optical Confidence</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200/80">
                <span className="text-[10px] text-neutral-500 font-medium block">Assigned Bin</span>
                <span className="font-semibold text-neutral-800">{result.disposalBin}</span>
              </div>
              <div className="p-2.5 bg-white rounded-lg border border-neutral-200/80">
                <span className="text-[10px] text-neutral-500 font-medium block">Recyclability</span>
                <span className="font-semibold text-emerald-700">{result.recyclabilityRate}</span>
              </div>
            </div>

            <div className="text-xs space-y-1">
              <span className="font-semibold text-neutral-700 block">Recommended Segregation Step:</span>
              <p className="text-neutral-600 leading-relaxed bg-white p-2.5 rounded-lg border border-neutral-200/80">
                {result.recommendedAction}
              </p>
            </div>

            {result.safetyGuidelines.length > 0 && (
              <div className="text-xs space-y-1">
                <span className="font-semibold text-neutral-700 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-600" /> Safety & Contamination Notice:
                </span>
                <ul className="text-neutral-600 list-disc list-inside space-y-0.5 text-[11px] pl-1">
                  {result.safetyGuidelines.map((g, i) => (
                    <li key={i}>{g}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="pt-2 flex items-center justify-between border-t border-neutral-200">
              <div className="text-xs text-neutral-600">
                Estimated reward: <span className="font-mono font-bold text-emerald-700">+{result.ecoPointsEstimated} pts/kg</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onScheduleForCategory?.(result.category);
                  onClose();
                }}
                className="flex items-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors"
              >
                Schedule Pickup <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        <div className="mt-4 pt-3 border-t border-neutral-100 flex justify-end">
          <button
            onClick={onClose}
            className="py-1.5 px-4 text-xs font-medium text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
