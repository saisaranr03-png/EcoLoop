/**
 * EcoLoop State Management & Business Logic Store
 * Features persistent LocalStorage synchronization, pre-seeded realistic data,
 * role authorization, and complete transaction flows.
 */

import {
  UserProfile,
  CollectionRequest,
  EcoPointsTransaction,
  RewardItem,
  RewardRedemption,
  RecyclingCentre,
  CommunityChallenge,
  WasteCategory,
  WasteGuideItem,
  WasteAnalysisResult
} from '../types';

const STORAGE_KEYS = {
  CURRENT_USER: 'ecoloop_current_user',
  REQUESTS: 'ecoloop_requests',
  TRANSACTIONS: 'ecoloop_transactions',
  REWARDS: 'ecoloop_rewards',
  REDEMPTIONS: 'ecoloop_redemptions',
  CENTRES: 'ecoloop_centres',
  CHALLENGES: 'ecoloop_challenges',
  ALL_USERS: 'ecoloop_all_users',
};

// Standard EcoPoints per KG by category
export const CATEGORY_POINTS_PER_KG: Record<WasteCategory, number> = {
  'Plastic': 15,
  'Paper': 10,
  'Glass': 12,
  'Metal': 25,
  'Organic': 8,
  'Electronic Waste': 40,
  'Hazardous Waste': 20,
  'Mixed Waste': 5,
};

// Illustrative Environmental Multipliers (per KG recycled)
export const IMPACT_FACTORS = {
  co2KgPerKg: 1.48,        // 1.48 kg CO2 avoided per kg general recyclables
  landfillM3PerKg: 0.0018, // 0.0018 m³ landfill volume saved per kg
  waterLitersPerKg: 16.5,  // 16.5 liters water preserved
  treesPerKgPaper: 0.017,  // trees saved per kg of paper
};

// Seed Users for 4 Roles
export const DEMO_USERS: Record<string, UserProfile> = {
  citizen: {
    id: 'user_cit_01',
    name: 'Aravind Sharma',
    email: 'aravind.citizen@ecoloop.org',
    role: 'citizen',
    phone: '+91 98450 23411',
    address: '42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore',
    ecoPoints: 485,
    assignedZone: 'East Zone - Sector 4',
  },
  collector: {
    id: 'user_col_01',
    name: 'Rajesh Kumar',
    email: 'rajesh.collector@ecoloop.org',
    role: 'collector',
    phone: '+91 97312 88720',
    address: 'EcoLoop Municipal Hub Depot 3, Bangalore',
    rating: 4.9,
    assignedZone: 'East Zone - Sector 4 & 5',
  },
  recycler: {
    id: 'user_rec_01',
    name: 'EcoVision Recovery Hub',
    email: 'ecovision.recycler@ecoloop.org',
    role: 'recycler',
    phone: '+91 80 4122 9000',
    address: 'Plot 18B, Peenya Industrial Area Phase 2, Bangalore',
    facilityName: 'EcoVision Recovery Hub - Central MRF',
    assignedZone: 'Bangalore Metropolitan Industrial Zone',
  },
  admin: {
    id: 'user_adm_01',
    name: 'Dr. Sarah Chen',
    email: 'admin@ecoloop.org',
    role: 'admin',
    phone: '+91 80 2297 5000',
    address: 'Directorate of Municipal Waste Operations, City Hall',
    assignedZone: 'All City Sectors',
  },
};

// Seed Recycling Centres in Bangalore with real coordinates
export const INITIAL_CENTRES: RecyclingCentre[] = [
  {
    id: 'rec_01',
    name: 'EcoVision Central MRF',
    address: 'Plot 18B, Peenya Industrial Area Phase 2, Bangalore',
    latitude: 13.0285,
    longitude: 77.5186,
    phone: '+91 80 4122 9000',
    email: 'central@ecovisionmrf.org',
    openHours: 'Mon - Sat: 08:00 AM - 07:00 PM',
    acceptedCategories: ['Plastic', 'Paper', 'Glass', 'Metal', 'Electronic Waste'],
    currentCapacityKg: 8400,
    maxCapacityKg: 15000,
    status: 'Open',
    efficiencyRating: 98.4,
    facilityType: 'MRF (Material Recovery Facility)',
  },
  {
    id: 'rec_02',
    name: 'GreenLeaf Urban Compost & Bio-Gas Center',
    address: 'Survey 44, Bellandur Lake Road, Bangalore',
    latitude: 12.9352,
    longitude: 77.6744,
    phone: '+91 80 2843 1120',
    email: 'operations@greenleafcompost.in',
    openHours: 'Mon - Sun: 06:00 AM - 06:00 PM',
    acceptedCategories: ['Organic'],
    currentCapacityKg: 5200,
    maxCapacityKg: 8000,
    status: 'Open',
    efficiencyRating: 95.8,
    facilityType: 'Compost Center',
  },
  {
    id: 'rec_03',
    name: 'CircuitCycle Certified E-Waste Facility',
    address: 'Electronics City Phase 1, Hosur Road, Bangalore',
    latitude: 12.8452,
    longitude: 77.6602,
    phone: '+91 80 3982 4400',
    email: 'recycle@circuitcycle.com',
    openHours: 'Mon - Fri: 09:00 AM - 06:00 PM',
    acceptedCategories: ['Electronic Waste', 'Hazardous Waste'],
    currentCapacityKg: 3100,
    maxCapacityKg: 6000,
    status: 'Operating',
    efficiencyRating: 99.1,
    facilityType: 'E-Waste Recycler',
  },
  {
    id: 'rec_04',
    name: 'ClearGlass Circular Reclaim Works',
    address: 'Whitefield Industrial Export Zone, Bangalore',
    latitude: 12.9815,
    longitude: 77.7291,
    phone: '+91 80 4910 8822',
    email: 'info@clearglassworks.in',
    openHours: 'Mon - Sat: 08:30 AM - 05:30 PM',
    acceptedCategories: ['Glass', 'Metal'],
    currentCapacityKg: 4200,
    maxCapacityKg: 10000,
    status: 'Open',
    efficiencyRating: 96.7,
    facilityType: 'Glass Works',
  },
];

// Seed Collection Requests
export const INITIAL_REQUESTS: CollectionRequest[] = [
  {
    id: 'req_001',
    trackingNumber: 'ECL-2026-8912',
    citizenId: 'user_cit_01',
    citizenName: 'Aravind Sharma',
    citizenPhone: '+91 98450 23411',
    address: '42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore',
    latitude: 12.9298,
    longitude: 77.6712,
    wasteCategory: 'Plastic',
    estimatedKg: 5.5,
    actualKg: 5.8,
    preferredDate: '2026-11-04',
    timeSlot: '09:00 AM - 11:00 AM',
    specialInstructions: 'Clean washed PET bottles and HDPE containers in twin bags.',
    status: 'Verified',
    collectorId: 'user_col_01',
    collectorName: 'Rajesh Kumar',
    recyclerId: 'rec_01',
    recyclerName: 'EcoVision Central MRF',
    createdAt: '2026-11-03T10:15:00Z',
    updatedAt: '2026-11-04T10:45:00Z',
    verifiedAt: '2026-11-04T10:45:00Z',
    qrCodeToken: 'ECOLOOP-REQ001-SEC998',
    ecoPointsAwarded: 87,
  },
  {
    id: 'req_002',
    trackingNumber: 'ECL-2026-9041',
    citizenId: 'user_cit_01',
    citizenName: 'Aravind Sharma',
    citizenPhone: '+91 98450 23411',
    address: '42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore',
    latitude: 12.9298,
    longitude: 77.6712,
    wasteCategory: 'Paper',
    estimatedKg: 8.0,
    actualKg: 8.2,
    preferredDate: '2026-11-01',
    timeSlot: '02:00 PM - 04:00 PM',
    specialInstructions: 'Old newspapers and corrugated shipping boxes tied with jute twine.',
    status: 'Verified',
    collectorId: 'user_col_01',
    collectorName: 'Rajesh Kumar',
    recyclerId: 'rec_01',
    recyclerName: 'EcoVision Central MRF',
    createdAt: '2026-10-31T14:20:00Z',
    updatedAt: '2026-11-01T15:30:00Z',
    verifiedAt: '2026-11-01T15:30:00Z',
    qrCodeToken: 'ECOLOOP-REQ002-SEC441',
    ecoPointsAwarded: 82,
  },
  {
    id: 'req_003',
    trackingNumber: 'ECL-2026-9188',
    citizenId: 'user_cit_01',
    citizenName: 'Aravind Sharma',
    citizenPhone: '+91 98450 23411',
    address: '42 Orchid Heights, 4th Cross, Green Glen Layout, Bangalore',
    latitude: 12.9298,
    longitude: 77.6712,
    wasteCategory: 'Electronic Waste',
    estimatedKg: 3.5,
    preferredDate: '2026-11-06',
    timeSlot: '11:00 AM - 01:00 PM',
    specialInstructions: '2 obsolete PC power supplies, broken tablet, and tangled charging cables.',
    status: 'Accepted',
    collectorId: 'user_col_01',
    collectorName: 'Rajesh Kumar',
    createdAt: '2026-11-04T16:00:00Z',
    updatedAt: '2026-11-05T08:00:00Z',
    qrCodeToken: 'ECOLOOP-REQ003-SEC712',
  },
  {
    id: 'req_004',
    trackingNumber: 'ECL-2026-9205',
    citizenId: 'user_cit_02',
    citizenName: 'Priya Sundaram',
    citizenPhone: '+91 94480 55123',
    address: 'Villa 14, Palm Meadows, Whitefield, Bangalore',
    latitude: 12.9692,
    longitude: 77.7499,
    wasteCategory: 'Glass',
    estimatedKg: 6.0,
    preferredDate: '2026-11-05',
    timeSlot: '04:00 PM - 06:00 PM',
    specialInstructions: 'Assorted glass beverage bottles, no broken pieces.',
    status: 'On the Way',
    collectorId: 'user_col_01',
    collectorName: 'Rajesh Kumar',
    createdAt: '2026-11-04T09:30:00Z',
    updatedAt: '2026-11-05T09:15:00Z',
    qrCodeToken: 'ECOLOOP-REQ004-SEC801',
  },
  {
    id: 'req_005',
    trackingNumber: 'ECL-2026-9230',
    citizenId: 'user_cit_03',
    citizenName: 'Marcus D Souza',
    citizenPhone: '+91 99001 77234',
    address: 'Flat 302, Sunrise Residency, Koramangala 4th Block, Bangalore',
    latitude: 12.9345,
    longitude: 77.6256,
    wasteCategory: 'Metal',
    estimatedKg: 4.0,
    preferredDate: '2026-11-07',
    timeSlot: '09:00 AM - 11:00 AM',
    specialInstructions: 'Crushed aluminum beverage cans and steel food tins.',
    status: 'Pending',
    createdAt: '2026-11-05T06:15:00Z',
    updatedAt: '2026-11-05T06:15:00Z',
    qrCodeToken: 'ECOLOOP-REQ005-SEC332',
  },
  {
    id: 'req_006',
    trackingNumber: 'ECL-2026-9244',
    citizenId: 'user_cit_04',
    citizenName: 'Dr. Anita Desai',
    citizenPhone: '+91 98860 11928',
    address: 'House 88, 12th Main, Indiranagar, Bangalore',
    latitude: 12.9784,
    longitude: 77.6408,
    wasteCategory: 'Organic',
    estimatedKg: 12.0,
    preferredDate: '2026-11-06',
    timeSlot: '07:00 AM - 09:00 AM',
    specialInstructions: 'Segregated garden trimmings and dry kitchen peels in breathable bag.',
    status: 'Pending',
    createdAt: '2026-11-05T07:20:00Z',
    updatedAt: '2026-11-05T07:20:00Z',
    qrCodeToken: 'ECOLOOP-REQ006-SEC195',
  },
];

// Seed Rewards
export const INITIAL_REWARDS: RewardItem[] = [
  {
    id: 'rew_01',
    title: '₹250 Organic Grocery Voucher',
    category: 'Discount Voucher',
    pointsCost: 200,
    partnerName: 'Nature Fresh Organic Markets',
    description: 'Valid across all fresh produce and sustainable kitchen essentials.',
    remainingStock: 45,
    codePrefix: 'NF-ECO250',
  },
  {
    id: 'rew_02',
    title: 'EcoLoop Heavy-Duty Jute Carry Bag Set',
    category: 'Eco Merchandise',
    pointsCost: 150,
    partnerName: 'EcoLoop Sustainability Labs',
    description: 'Set of 3 washable organic jute shopping totes with reinforced handles.',
    remainingStock: 30,
    codePrefix: 'JUTE-TRIO',
  },
  {
    id: 'rew_03',
    title: 'Plant a Native Sapling in Your Name',
    category: 'Tree Planting',
    pointsCost: 300,
    partnerName: 'Bangalore Urban Afforestation Mission',
    description: 'We plant a certified geo-tagged Neem or Peepal tree in the urban buffer belt.',
    remainingStock: 120,
    codePrefix: 'TREE-GEO',
  },
  {
    id: 'rew_04',
    title: '₹500 Municipal Waste Management Rebate',
    category: 'Utility Rebate',
    pointsCost: 450,
    partnerName: 'Bruhat Bengaluru Mahanagara Palike (BBMP)',
    description: 'Direct adjustment credit against municipal property maintenance assessment.',
    remainingStock: 15,
    codePrefix: 'BBMP-REB500',
  },
  {
    id: 'rew_05',
    title: 'Stainless Steel Insulated Thermal Flask (750ml)',
    category: 'Eco Merchandise',
    pointsCost: 380,
    partnerName: 'ZeroWaste Gear Co.',
    description: 'Durable food-grade 304 steel bottle keeping liquids cold 24h / hot 12h.',
    remainingStock: 22,
    codePrefix: 'FLASK-STEEL',
  },
];

// Seed Challenges
export const INITIAL_CHALLENGES: CommunityChallenge[] = [
  {
    id: 'chal_01',
    title: 'Zero Plastic Month Challenge',
    category: 'Plastic',
    targetKg: 500,
    currentKg: 384,
    participantsCount: 142,
    rewardPoints: 120,
    deadline: '2026-11-30',
    badgeName: 'Plastic Purifier',
    description: 'Collect and divert at least 5kg of clean PET/HDPE bottles to unlock 120 bonus points.',
    isJoined: true,
  },
  {
    id: 'chal_02',
    title: 'Cardboard & Paper Recovery Sprint',
    category: 'Paper',
    targetKg: 1000,
    currentKg: 780,
    participantsCount: 210,
    rewardPoints: 100,
    deadline: '2026-11-20',
    badgeName: 'Paper Trailblazer',
    description: 'Divert packaging boxes from online orders and recover 8kg of paper fiber.',
    isJoined: true,
  },
  {
    id: 'chal_03',
    title: 'Responsible E-Waste Roundup',
    category: 'Electronic Waste',
    targetKg: 250,
    currentKg: 165,
    participantsCount: 88,
    rewardPoints: 200,
    deadline: '2026-12-15',
    badgeName: 'Silicon Steward',
    description: 'Bring obsolete electronic devices out of storage for non-hazardous certified recovery.',
    isJoined: false,
  },
  {
    id: 'chal_04',
    title: 'Urban Organic Compost Drive',
    category: 'Organic',
    targetKg: 2000,
    currentKg: 1420,
    participantsCount: 315,
    rewardPoints: 90,
    deadline: '2026-11-25',
    badgeName: 'Soil Regenerator',
    description: 'Segregate 100% of wet domestic waste for municipal aerobic composting.',
    isJoined: false,
  },
];

// Seed Waste Segregation Encyclopedia (50+ Household Items)
export const WASTE_ENCYCLOPEDIA: WasteGuideItem[] = [
  {
    id: 'wg_01',
    name: 'Plastic Water / Soda Bottles (PET #1)',
    category: 'Plastic',
    binColor: '#2563EB',
    recyclability: '100% Recyclable',
    instructions: 'Empty liquid completely, rinse lightly, crush bottle flat to save volume, replace cap on bottle.',
    dos: ['Rinse out residual beverage', 'Flatten to optimize transport volume', 'Leave cap fastened on'],
    donts: ['Do not throw with liquid inside', 'Do not burn or melt'],
    safetyWarning: 'Never incinerate plastics; release toxic dioxins into air.',
  },
  {
    id: 'wg_02',
    name: 'Milk & Shampoo Jugs (HDPE #2)',
    category: 'Plastic',
    binColor: '#2563EB',
    recyclability: '100% Recyclable',
    instructions: 'Rinse thoroughly with cold water to avoid sour odor. High-density polyethylene is widely reprocessed into piping.',
    dos: ['Triple rinse milk residue', 'Remove foil seals on mouth'],
    donts: ['Do not send containers with engine oil or toxic lubricants'],
  },
  {
    id: 'wg_03',
    name: 'Corrugated Cardboard Boxes',
    category: 'Paper',
    binColor: '#16A34A',
    recyclability: '100% Recyclable',
    instructions: 'Flatten all boxes completely. Remove plastic packing tape if possible. Keep dry.',
    dos: ['Flatten flat for pickup', 'Keep completely dry'],
    donts: ['Do not recycle greasy pizza boxes stained with cheese/oil (compost them instead)'],
  },
  {
    id: 'wg_04',
    name: 'Newspapers, Books & Office Paper',
    category: 'Paper',
    binColor: '#16A34A',
    recyclability: '100% Recyclable',
    instructions: 'Stack neatly and tie with string or pack into paper grocery bag. Keep away from moisture.',
    dos: ['Separate shredded paper into paper envelope', 'Keep paper dry'],
    donts: ['Do not mix carbon paper or foil-coated gift wraps'],
  },
  {
    id: 'wg_05',
    name: 'Glass Beverage Bottles & Jars',
    category: 'Glass',
    binColor: '#0D9488',
    recyclability: '100% Recyclable',
    instructions: 'Rinse food residue. Remove metal lids (recycle lids in metal bin). Glass can be recycled endlessly without quality degradation.',
    dos: ['Rinse clear of sauces', 'Separate metal/plastic lids'],
    donts: ['Do not include broken window panes, light bulbs, or pyrex bakeware (different melting points)'],
    safetyWarning: 'Wrap cracked glass securely to prevent cuts to collection staff.',
  },
  {
    id: 'wg_06',
    name: 'Aluminum Soda Cans',
    category: 'Metal',
    binColor: '#EAB308',
    recyclability: '100% Recyclable',
    instructions: 'Empty contents, rinse lightly, crush if desired. Recycling aluminum saves 95% of energy needed to smelt new bauxite ore.',
    dos: ['Crush can flat', 'Keep tabs attached'],
    donts: ['Do not mix with pressurized paint spray cans'],
  },
  {
    id: 'wg_07',
    name: 'Steel & Tin Food Cans',
    category: 'Metal',
    binColor: '#EAB308',
    recyclability: '100% Recyclable',
    instructions: 'Rinse food sauces clean. Tuck the cut lid inside the can and squeeze slightly.',
    dos: ['Rinse tomato and tuna oil completely', 'Tuck lid safely inside'],
    donts: ['Do not leave sharp edges exposed'],
  },
  {
    id: 'wg_08',
    name: 'Fruit Peels & Vegetable Scraps',
    category: 'Organic',
    binColor: '#65A30D',
    recyclability: 'Compostable',
    instructions: 'Place into green compost bin. Aerobic breakdown turns this into nutrient-dense compost for urban gardens.',
    dos: ['Collect raw kitchen scraps', 'Include coffee grounds and tea leaves'],
    donts: ['Do not include plastic produce stickers or rubber bands'],
  },
  {
    id: 'wg_09',
    name: 'Lithium-Ion & Alkaline Batteries',
    category: 'Hazardous Waste',
    binColor: '#DC2626',
    recyclability: 'Special Handling',
    instructions: 'Tape terminals with clear scotch tape to prevent short circuits. Store in dry non-metallic box. Schedule special hazardous pickup.',
    dos: ['Cover battery terminals with electrical tape', 'Store away from heat sources'],
    donts: ['NEVER throw in general household garbage', 'Never puncture or crush'],
    safetyWarning: 'Crushed lithium batteries cause devastating municipal truck and landfill fires.',
  },
  {
    id: 'wg_10',
    name: 'Broken Smartphones, Tablets & Laptops',
    category: 'Electronic Waste',
    binColor: '#7C3AED',
    recyclability: 'Special Handling',
    instructions: 'Perform factory reset if device still powers on. certified recyclers extract gold, copper, palladium and prevent lead contamination.',
    dos: ['Back up and wipe private data', 'Keep cables bundled together'],
    donts: ['Do not break display glass or dismantle battery cells'],
  },
  {
    id: 'wg_11',
    name: 'Cables, Adapters & Power Bricks',
    category: 'Electronic Waste',
    binColor: '#7C3AED',
    recyclability: '100% Recyclable',
    instructions: 'Tie cord into a loop. Copper wire inside is stripped and 100% recycled into new cabling.',
    dos: ['Bundle cords together neatly'],
    donts: ['Do not throw in general plastic bin'],
  },
  {
    id: 'wg_12',
    name: 'Fluorescent Bulbs & CFL Tubes',
    category: 'Hazardous Waste',
    binColor: '#DC2626',
    recyclability: 'Hazardous Drop-off',
    instructions: 'Contains vaporized mercury. Wrap in cardboard to prevent shattering. Hand directly to authorized hazardous waste worker.',
    dos: ['Keep in protective sleeve or box', 'Handle with care'],
    donts: ['Do not crush or throw in glass bin'],
    safetyWarning: 'Mercury vapor is neurotoxic if breathed in when tube breaks.',
  },
  {
    id: 'wg_13',
    name: 'Styrofoam / Thermocol Packaging (EPS #6)',
    category: 'Mixed Waste',
    binColor: '#64748B',
    recyclability: 'Special Handling',
    instructions: 'Keep clean and dry. Most curbside pickups cannot reprocess lightweight foam; take to designated industrial drop-off.',
    dos: ['Keep large blocks clean for drop-off', 'Re-use for domestic shipping'],
    donts: ['Do not break into tiny beads', 'Do not place in organic compost'],
  },
  {
    id: 'wg_14',
    name: 'Medicine Blister Packs & Expired Drugs',
    category: 'Hazardous Waste',
    binColor: '#DC2626',
    recyclability: 'Special Handling',
    instructions: 'Return to municipal medicine take-back bin or certified pharmacy disposal unit. Aluminum/plastic laminate cannot be separated in standard paper bins.',
    dos: ['Drop off at authorized pharmacy kiosks'],
    donts: ['Do not flush down toilet (contaminates water table)', 'Do not throw in plastic bin'],
  },
];

// Helper to calculate total environmental impacts
export function calculateEnvironmentalImpact(totalKg: number, categoryBreakdown?: Record<string, number>) {
  const co2AvoidedKg = totalKg * IMPACT_FACTORS.co2KgPerKg;
  const landfillAvoidedM3 = totalKg * IMPACT_FACTORS.landfillM3PerKg;
  const waterSavedLiters = totalKg * IMPACT_FACTORS.waterLitersPerKg;
  const paperKg = categoryBreakdown?.['Paper'] || totalKg * 0.35;
  const treesSaved = paperKg * IMPACT_FACTORS.treesPerKgPaper;
  const kwhEnergySaved = totalKg * 2.15; // ~2.15 kWh saved per kg recycled

  return {
    totalKg: Number(totalKg.toFixed(1)),
    co2AvoidedKg: Number(co2AvoidedKg.toFixed(1)),
    landfillAvoidedM3: Number(landfillAvoidedM3.toFixed(3)),
    waterSavedLiters: Math.round(waterSavedLiters),
    treesSaved: Number(treesSaved.toFixed(2)),
    kwhEnergySaved: Math.round(kwhEnergySaved),
  };
}

class EcoLoopStore {
  private currentUser: UserProfile;
  private requests: CollectionRequest[] = [];
  private transactions: EcoPointsTransaction[] = [];
  private rewards: RewardItem[] = [];
  private redemptions: RewardRedemption[] = [];
  private centres: RecyclingCentre[] = [];
  private challenges: CommunityChallenge[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    this.currentUser = this.load(STORAGE_KEYS.CURRENT_USER, DEMO_USERS.citizen);
    this.requests = this.load(STORAGE_KEYS.REQUESTS, INITIAL_REQUESTS);
    this.rewards = this.load(STORAGE_KEYS.REWARDS, INITIAL_REWARDS);
    this.centres = this.load(STORAGE_KEYS.CENTRES, INITIAL_CENTRES);
    this.challenges = this.load(STORAGE_KEYS.CHALLENGES, INITIAL_CHALLENGES);
    this.transactions = this.load(STORAGE_KEYS.TRANSACTIONS, [
      {
        id: 'tx_01',
        userId: 'user_cit_01',
        type: 'earned',
        points: 87,
        description: 'Verified 5.8 kg Plastic Collection (#ECL-2026-8912)',
        timestamp: '2026-11-04T10:45:00Z',
        requestId: 'req_001',
      },
      {
        id: 'tx_02',
        userId: 'user_cit_01',
        type: 'earned',
        points: 82,
        description: 'Verified 8.2 kg Paper Collection (#ECL-2026-9041)',
        timestamp: '2026-11-01T15:30:00Z',
        requestId: 'req_002',
      },
    ]);
    this.redemptions = this.load(STORAGE_KEYS.REDEMPTIONS, []);
  }

  private load<T>(key: string, fallback: T): T {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : fallback;
    } catch {
      return fallback;
    }
  }

  private save(key: string, data: any) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.warn('Failed to save to localStorage:', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(fn => fn());
  }

  // User & Role Management
  public getCurrentUser(): UserProfile {
    return this.currentUser;
  }

  public switchRole(role: 'citizen' | 'collector' | 'recycler' | 'admin'): UserProfile {
    this.currentUser = DEMO_USERS[role];
    this.save(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    this.notify();
    return this.currentUser;
  }

  public loginUser(email: string, role: 'citizen' | 'collector' | 'recycler' | 'admin'): UserProfile {
    const existing = Object.values(DEMO_USERS).find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      this.currentUser = existing;
    } else {
      this.currentUser = {
        id: `user_${Date.now()}`,
        name: email.split('@')[0].replace('.', ' ').toUpperCase(),
        email,
        role,
        phone: '+91 99000 00000',
        address: 'Sector 5, Green City, Bangalore',
        ecoPoints: role === 'citizen' ? 50 : 0,
        rating: 5.0,
      };
    }
    this.save(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    this.notify();
    return this.currentUser;
  }

  public updateUserProfile(updates: Partial<UserProfile>) {
    this.currentUser = { ...this.currentUser, ...updates };
    this.save(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    this.notify();
  }

  // Collection Requests
  public getRequests(): CollectionRequest[] {
    return [...this.requests];
  }

  public getCitizenRequests(citizenId: string): CollectionRequest[] {
    return this.requests.filter(r => r.citizenId === citizenId);
  }

  public getCollectorRequests(collectorId: string): CollectionRequest[] {
    return this.requests.filter(r => r.collectorId === collectorId);
  }

  public createRequest(data: {
    wasteCategory: WasteCategory;
    estimatedKg: number;
    address: string;
    preferredDate: string;
    timeSlot: string;
    specialInstructions?: string;
    photoUrl?: string;
    latitude?: number;
    longitude?: number;
  }): CollectionRequest {
    const trackingNumber = `ECL-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const qrCodeToken = `ECOLOOP-${trackingNumber}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    const newReq: CollectionRequest = {
      id: `req_${Date.now()}`,
      trackingNumber,
      citizenId: this.currentUser.id,
      citizenName: this.currentUser.name,
      citizenPhone: this.currentUser.phone,
      address: data.address || this.currentUser.address,
      latitude: data.latitude || 12.9716 + (Math.random() - 0.5) * 0.08,
      longitude: data.longitude || 77.5946 + (Math.random() - 0.5) * 0.08,
      wasteCategory: data.wasteCategory,
      estimatedKg: data.estimatedKg,
      preferredDate: data.preferredDate,
      timeSlot: data.timeSlot,
      specialInstructions: data.specialInstructions,
      photoUrl: data.photoUrl,
      status: 'Pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      qrCodeToken,
    };

    this.requests = [newReq, ...this.requests];
    this.save(STORAGE_KEYS.REQUESTS, this.requests);
    this.notify();
    return newReq;
  }

  public assignCollector(requestId: string, collectorId: string, collectorName: string) {
    this.requests = this.requests.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          collectorId,
          collectorName,
          status: 'Assigned',
          updatedAt: new Date().toISOString(),
        };
      }
      return req;
    });
    this.save(STORAGE_KEYS.REQUESTS, this.requests);
    this.notify();
  }

  public updateRequestStatus(requestId: string, status: 'Accepted' | 'On the Way' | 'Collected' | 'Cancelled') {
    this.requests = this.requests.map(req => {
      if (req.id === requestId) {
        return {
          ...req,
          status,
          updatedAt: new Date().toISOString(),
        };
      }
      return req;
    });
    this.save(STORAGE_KEYS.REQUESTS, this.requests);
    this.notify();
  }

  // QR Code Verification Flow (Collector scans & verifies weight)
  public verifyQrCollection(qrToken: string, actualKg: number, collectorNotes?: string): {
    success: boolean;
    message: string;
    request?: CollectionRequest;
    pointsAwarded?: number;
  } {
    const target = this.requests.find(
      r => r.qrCodeToken.trim().toUpperCase() === qrToken.trim().toUpperCase() ||
           r.trackingNumber.trim().toUpperCase() === qrToken.trim().toUpperCase() ||
           r.id === qrToken
    );

    if (!target) {
      return { success: false, message: 'Invalid or unrecognized QR Code.' };
    }

    if (target.status === 'Verified') {
      return {
        success: false,
        message: 'This collection was already verified and rewarded. Duplicate verification prevented!',
      };
    }

    const ratePerKg = CATEGORY_POINTS_PER_KG[target.wasteCategory] || 10;
    const pointsAwarded = Math.round(actualKg * ratePerKg);
    const now = new Date().toISOString();

    // Update request
    const updatedRequest: CollectionRequest = {
      ...target,
      status: 'Verified',
      actualKg,
      specialInstructions: collectorNotes ? `${target.specialInstructions || ''} | Collector: ${collectorNotes}` : target.specialInstructions,
      verifiedAt: now,
      updatedAt: now,
      ecoPointsAwarded: pointsAwarded,
      collectorId: target.collectorId || this.currentUser.id,
      collectorName: target.collectorName || this.currentUser.name,
      recyclerId: 'rec_01',
      recyclerName: 'EcoVision Central MRF',
    };

    this.requests = this.requests.map(r => (r.id === target.id ? updatedRequest : r));
    this.save(STORAGE_KEYS.REQUESTS, this.requests);

    // Credit EcoPoints to citizen
    const citizen = DEMO_USERS.citizen;
    if (citizen.id === target.citizenId) {
      citizen.ecoPoints = (citizen.ecoPoints || 0) + pointsAwarded;
    }
    if (this.currentUser.id === target.citizenId) {
      this.currentUser.ecoPoints = (this.currentUser.ecoPoints || 0) + pointsAwarded;
      this.save(STORAGE_KEYS.CURRENT_USER, this.currentUser);
    }

    // Add transaction record
    const newTx: EcoPointsTransaction = {
      id: `tx_${Date.now()}`,
      userId: target.citizenId,
      type: 'earned',
      points: pointsAwarded,
      description: `Verified ${actualKg} kg ${target.wasteCategory} Collection (#${target.trackingNumber})`,
      timestamp: now,
      requestId: target.id,
    };
    this.transactions = [newTx, ...this.transactions];
    this.save(STORAGE_KEYS.TRANSACTIONS, this.transactions);

    // Update Challenge Progress
    this.challenges = this.challenges.map(ch => {
      if (ch.category === target.wasteCategory || ch.category === 'All Categories') {
        return {
          ...ch,
          currentKg: Math.min(ch.targetKg, Number((ch.currentKg + actualKg).toFixed(1))),
        };
      }
      return ch;
    });
    this.save(STORAGE_KEYS.CHALLENGES, this.challenges);

    // Update Recycling Center Inventory
    this.centres = this.centres.map(c => {
      if (c.acceptedCategories.includes(target.wasteCategory)) {
        return {
          ...c,
          currentCapacityKg: Math.min(c.maxCapacityKg, c.currentCapacityKg + actualKg),
        };
      }
      return c;
    });
    this.save(STORAGE_KEYS.CENTRES, this.centres);

    this.notify();
    return {
      success: true,
      message: `Collection verified successfully! ${pointsAwarded} EcoPoints credited to ${target.citizenName}.`,
      request: updatedRequest,
      pointsAwarded,
    };
  }

  // Rewards & Redemption
  public getRewards(): RewardItem[] {
    return [...this.rewards];
  }

  public getRedemptions(userId?: string): RewardRedemption[] {
    if (userId) {
      return this.redemptions.filter(r => r.userId === userId);
    }
    return [...this.redemptions];
  }

  public getTransactions(userId?: string): EcoPointsTransaction[] {
    if (userId) {
      return this.transactions.filter(t => t.userId === userId);
    }
    return [...this.transactions];
  }

  public redeemReward(rewardId: string): { success: boolean; message: string; redemption?: RewardRedemption } {
    const reward = this.rewards.find(r => r.id === rewardId);
    if (!reward) return { success: false, message: 'Reward not found.' };

    const userPoints = this.currentUser.ecoPoints || 0;
    if (userPoints < reward.pointsCost) {
      return {
        success: false,
        message: `Insufficient EcoPoints. You need ${reward.pointsCost} points, but have ${userPoints}.`,
      };
    }

    if (reward.remainingStock <= 0) {
      return { success: false, message: 'This reward is currently out of stock.' };
    }

    // Deduct points
    this.currentUser.ecoPoints = userPoints - reward.pointsCost;
    this.save(STORAGE_KEYS.CURRENT_USER, this.currentUser);

    // Decrement stock
    this.rewards = this.rewards.map(r =>
      r.id === rewardId ? { ...r, remainingStock: r.remainingStock - 1 } : r
    );
    this.save(STORAGE_KEYS.REWARDS, this.rewards);

    // Generate unique voucher code
    const voucherCode = `${reward.codePrefix}-${Math.floor(100000 + Math.random() * 900000)}`;
    const newRedemption: RewardRedemption = {
      id: `red_${Date.now()}`,
      userId: this.currentUser.id,
      userName: this.currentUser.name,
      rewardId: reward.id,
      rewardTitle: reward.title,
      pointsSpent: reward.pointsCost,
      voucherCode,
      redeemedAt: new Date().toISOString(),
      status: 'Active',
    };

    this.redemptions = [newRedemption, ...this.redemptions];
    this.save(STORAGE_KEYS.REDEMPTIONS, this.redemptions);

    // Add debit transaction
    const newTx: EcoPointsTransaction = {
      id: `tx_${Date.now()}`,
      userId: this.currentUser.id,
      type: 'redeemed',
      points: -reward.pointsCost,
      description: `Redeemed ${reward.title} (Code: ${voucherCode})`,
      timestamp: new Date().toISOString(),
    };
    this.transactions = [newTx, ...this.transactions];
    this.save(STORAGE_KEYS.TRANSACTIONS, this.transactions);

    this.notify();
    return {
      success: true,
      message: `Reward redeemed successfully! Your voucher code is ${voucherCode}.`,
      redemption: newRedemption,
    };
  }

  // Recycling Centres
  public getCentres(): RecyclingCentre[] {
    return [...this.centres];
  }

  public updateCentreStatus(centreId: string, status: 'Open' | 'Operating' | 'Maintenance') {
    this.centres = this.centres.map(c => (c.id === centreId ? { ...c, status } : c));
    this.save(STORAGE_KEYS.CENTRES, this.centres);
    this.notify();
  }

  // Challenges
  public getChallenges(): CommunityChallenge[] {
    return [...this.challenges];
  }

  public toggleJoinChallenge(challengeId: string) {
    this.challenges = this.challenges.map(ch => {
      if (ch.id === challengeId) {
        const nextState = !ch.isJoined;
        return {
          ...ch,
          isJoined: nextState,
          participantsCount: nextState ? ch.participantsCount + 1 : ch.participantsCount - 1,
        };
      }
      return ch;
    });
    this.save(STORAGE_KEYS.CHALLENGES, this.challenges);
    this.notify();
  }

  // Platform Aggregate Analytics
  public getPlatformKPIs() {
    const verified = this.requests.filter(r => r.status === 'Verified');
    const totalCollectedKg = verified.reduce((sum, r) => sum + (r.actualKg || r.estimatedKg), 0);
    const pendingCount = this.requests.filter(r => r.status === 'Pending').length;
    const completedCount = verified.length;

    const categoryBreakdown: Record<string, number> = {};
    verified.forEach(r => {
      const kg = r.actualKg || r.estimatedKg;
      categoryBreakdown[r.wasteCategory] = (categoryBreakdown[r.wasteCategory] || 0) + kg;
    });

    const impact = calculateEnvironmentalImpact(totalCollectedKg, categoryBreakdown);

    return {
      totalCitizens: 1420,
      totalCollectors: 48,
      totalCentres: this.centres.length,
      totalRequests: this.requests.length,
      pendingRequests: pendingCount,
      completedCollections: completedCount,
      totalWasteCollectedKg: Number(totalCollectedKg.toFixed(1)),
      totalWasteRecycledKg: Number((totalCollectedKg * 0.94).toFixed(1)), // 94% diversion efficiency
      categoryBreakdown,
      impact,
    };
  }

  // Reset to initial demo state
  public resetToFactoryDemo() {
    localStorage.clear();
    this.currentUser = DEMO_USERS.citizen;
    this.requests = INITIAL_REQUESTS;
    this.rewards = INITIAL_REWARDS;
    this.centres = INITIAL_CENTRES;
    this.challenges = INITIAL_CHALLENGES;
    this.transactions = [];
    this.redemptions = [];
    this.notify();
  }
}

export const store = new EcoLoopStore();
