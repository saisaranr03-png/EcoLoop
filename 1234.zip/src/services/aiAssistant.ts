/**
 * EcoLoop AI Waste Segregation Assistant Service
 * Natural language segregation matching with domain-specific recycling intelligence,
 * safety warnings, and cross-referencing against municipal guidelines.
 */

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  recommendedCategory?: string;
  safetyAlert?: string;
  quickActions?: string[];
}

export const FREQUENT_QUESTIONS = [
  'Where should I dispose of plastic bottles?',
  'Can food waste and kitchen scraps be recycled?',
  'How should I safely dispose of old batteries?',
  'Can greasy pizza cardboard boxes be recycled?',
  'What should I do with old smartphones and cables?',
  'How do I earn EcoPoints for glass bottles?',
];

export function answerSegregationQuestion(question: string): {
  answer: string;
  recommendedCategory?: string;
  safetyAlert?: string;
  quickActions?: string[];
} {
  const q = question.toLowerCase();

  if (q.includes('battery') || q.includes('batteries') || q.includes('lithium') || q.includes('cell')) {
    return {
      answer: `Old batteries are classified as **Hazardous Waste**. They contain toxic heavy metals (lithium, cadmium, lead, nickel) that can leach into groundwater or trigger severe thermal fires in garbage trucks if crushed.\n\n**Segregation Instructions:**\n1. Cover both the positive (+) and negative (-) terminals with transparent tape to prevent accidental short-circuits.\n2. Store in a dry plastic container away from flammable items.\n3. Request a specialized **Hazardous Waste Collection** on EcoLoop or drop them at a certified e-waste kiosk.`,
      recommendedCategory: 'Hazardous Waste',
      safetyAlert: 'CRITICAL SAFETY: Never throw lithium batteries in regular trash. Truck compactor blades crush them, sparking explosive chemical fires.',
      quickActions: ['Schedule Hazardous Pickup', 'Find E-Waste Dropoff'],
    };
  }

  if (q.includes('plastic bottle') || (q.includes('plastic') && (q.includes('pet') || q.includes('bottle') || q.includes('jug')))) {
    return {
      answer: `Plastic beverage bottles (PET #1) and milk/detergent jugs (HDPE #2) are **100% recyclable** and yield 15 EcoPoints per kg on EcoLoop!\n\n**How to segregate:**\n• Empty any leftover liquid completely.\n• Give it a quick 3-second rinse.\n• Crush the bottle flat with your hand or foot to save 75% truck volume.\n• Replace the plastic cap back on the crushed bottle before scheduling pickup.`,
      recommendedCategory: 'Plastic',
      quickActions: ['Schedule Plastic Pickup', 'View EcoPoints Rewards'],
    };
  }

  if (q.includes('food') || q.includes('organic') || q.includes('kitchen') || q.includes('vegetable') || q.includes('fruit') || q.includes('wet waste')) {
    return {
      answer: `Food waste and kitchen scraps are **Organic Waste**. While they cannot be mechanically recycled into new products, they are aerobically composted into nutrient-rich organic manure or converted to bio-methane clean energy!\n\n**Best Practices:**\n• Keep food waste in a dedicated aerated green bin.\n• Do NOT wrap kitchen waste in single-use plastic bags.\n• Peelings, coffee grounds, eggshells, and tea leaves make phenomenal compost.`,
      recommendedCategory: 'Organic',
      quickActions: ['Schedule Compost Pickup', 'Nearby Compost Centers'],
    };
  }

  if (q.includes('pizza') || (q.includes('cardboard') && q.includes('grease')) || q.includes('oil')) {
    return {
      answer: `Great question! **Clean cardboard** is 100% recyclable, but **greasy pizza box bases** soaked with oil and cheese CANNOT be recycled via paper mills because oil cannot be separated from paper pulp fibers.\n\n**What to do:**\n1. Tear off the clean top lid of the pizza box and place it in your **Paper Recycling Bin**.\n2. The greasy, cheese-stained bottom section should go into the **Organic Compost** or general waste bin.`,
      recommendedCategory: 'Paper / Organic Split',
      safetyAlert: 'Oil contamination ruins entire vat batches of recycled paper pulp in processing facilities.',
      quickActions: ['Learn Cardboard Guidelines'],
    };
  }

  if (q.includes('cardboard') || q.includes('paper') || q.includes('newspaper') || q.includes('book')) {
    return {
      answer: `Clean cardboard and paper are prime recyclables that save trees and save 60% energy compared to virgin pulp manufacturing!\n\n**Disposal Checklist:**\n• Flatten all corrugated shipping boxes flat.\n• Remove excessive synthetic packing tape.\n• Keep dry. Wet or moldy paper cannot be reprocessed.`,
      recommendedCategory: 'Paper',
      quickActions: ['Schedule Paper Pickup'],
    };
  }

  if (q.includes('glass') || q.includes('jar') || q.includes('bottle') || q.includes('mirror') || q.includes('window')) {
    return {
      answer: `Container glass (sauce jars, beverage bottles) is **infinitely recyclable** without degrading in purity or strength!\n\n**Important Distinction:**\n• Recyclable: Food jars, condiment bottles, drink bottles.\n• NOT Recyclable in glass bins: Window panes, mirrors, light bulbs, or Pyrex bakeware (these have chemical additives with much higher melting points).\n\n**Preparation:** Rinse out food sauces and separate metal caps.`,
      recommendedCategory: 'Glass',
      safetyAlert: 'If glass is broken, wrap securely in several layers of newspaper to protect sanitation workers.',
      quickActions: ['Schedule Glass Pickup'],
    };
  }

  if (q.includes('phone') || q.includes('electronic') || q.includes('e-waste') || q.includes('laptop') || q.includes('cable') || q.includes('wire')) {
    return {
      answer: `Electronic Waste (E-Waste) is high-value! Recyclers recover precious metals like gold, silver, copper, and rare earths, while preventing lead and mercury from contaminating soil.\n\nEcoLoop awards **40 EcoPoints per kg** for certified e-waste.\n\n**Before Handing Over:**\n• Back up your personal photos/data and perform a factory reset.\n• Bundle chargers and peripheral cords with rubber bands.`,
      recommendedCategory: 'Electronic Waste',
      quickActions: ['Schedule E-Waste Pickup', 'Locate E-Waste Facility'],
    };
  }

  if (q.includes('point') || q.includes('reward') || q.includes('earn') || q.includes('money')) {
    return {
      answer: `You earn **EcoPoints** on EcoLoop for every verified kilogram of recyclable waste collected by municipal staff:\n• Metal: 25 pts/kg\n• E-Waste: 40 pts/kg\n• Plastic: 15 pts/kg\n• Glass: 12 pts/kg\n• Paper: 10 pts/kg\n• Organic: 8 pts/kg\n\nPoints are instantly deposited into your EcoWallet upon collector QR scanning and can be redeemed for supermarket discount vouchers, stainless steel flasks, or municipal utility bill credits!`,
      quickActions: ['View Rewards Catalogue', 'View EcoWallet'],
    };
  }

  // Fallback answer
  return {
    answer: `For general domestic waste, the primary rule is **clean, dry segregation**:\n\n1. **Dry Recyclables (Blue/Green Bin):** Clean paper, cardboard, plastics, metals, and glass containers.\n2. **Wet Organic (Green Bin):** Fruit/vegetable peels, leftover food, garden foliage.\n3. **Hazardous / E-Waste (Red Bin):** Batteries, medicine strips, paint chemicals, broken electricals.\n\nYou can also take a photo in the **Smart Waste Identifier** tab for instant optical category detection!`,
    quickActions: ['Open Waste Camera', 'Browse 50+ Item Encyclopedia'],
  };
}
