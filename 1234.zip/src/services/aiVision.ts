/**
 * EcoLoop Smart Waste Identification Service
 * Provides transparent computer vision classification heuristics, preset sample items,
 * and detailed disposal recommendations compliant with environmental standards.
 */

import { WasteAnalysisResult, WasteCategory } from '../types';

export interface SampleWasteTestItem {
  id: string;
  label: string;
  category: WasteCategory;
  thumbnail: string;
  expectedResult: WasteAnalysisResult;
}

export const SAMPLE_WASTE_ITEMS: SampleWasteTestItem[] = [
  {
    id: 'sample_pet',
    label: 'PET Water Bottle',
    category: 'Plastic',
    thumbnail: '🧴',
    expectedResult: {
      category: 'Plastic',
      confidence: 96.4,
      materialDetected: 'Polyethylene Terephthalate (PET / Resin Code #1)',
      disposalBin: 'Blue Recyclables Bin',
      binHex: '#2563EB',
      recyclabilityRate: '100% Highly Recyclable',
      recommendedAction: 'Empty liquids completely, rinse residue, crush bottle flat to conserve collection vehicle volume, and twist the cap back on.',
      safetyGuidelines: [
        'Do not burn; emits toxic chemical fumes',
        'Store dry to prevent mold growth before scheduled pickup',
        'Remove any non-plastic shrink sleeves if easily peelable'
      ],
      ecoPointsEstimated: 15,
      isDemoAnalysis: true,
    },
  },
  {
    id: 'sample_cardboard',
    label: 'Corrugated Shipping Box',
    category: 'Paper',
    thumbnail: '📦',
    expectedResult: {
      category: 'Paper',
      confidence: 98.1,
      materialDetected: 'Unbleached Kraft Corrugated Fiberboard',
      disposalBin: 'Green Paper & Fiber Bin',
      binHex: '#16A34A',
      recyclabilityRate: '100% Recyclable into new packaging pulp',
      recommendedAction: 'Break down and flatten boxes completely. Remove thick synthetic shipping tape. Keep away from rain or dampness.',
      safetyGuidelines: [
        'Do not recycle greasy or oil-soaked sections (compost them instead)',
        'Tie stacks with biodegradable twine for easy handling'
      ],
      ecoPointsEstimated: 10,
      isDemoAnalysis: true,
    },
  },
  {
    id: 'sample_battery',
    label: 'Lithium-Ion Phone Battery',
    category: 'Hazardous Waste',
    thumbnail: '🔋',
    expectedResult: {
      category: 'Hazardous Waste',
      confidence: 94.8,
      materialDetected: 'Lithium Cobalt Oxide Secondary Cell (UN 3480)',
      disposalBin: 'Red Specialized Hazardous Container',
      binHex: '#DC2626',
      recyclabilityRate: 'Critical Specialized Extraction Required',
      recommendedAction: 'Cover both terminal contacts with insulating electrical tape. Place in a dry non-conductive plastic bag. Schedule priority hazardous waste collection.',
      safetyGuidelines: [
        'DANGER: Never place in general trash or curbside bins',
        'Crushing in waste compactor trucks causes high-intensity thermal runaway fires',
        'Keep away from high heat or direct sunlight'
      ],
      ecoPointsEstimated: 35,
      isDemoAnalysis: true,
    },
  },
  {
    id: 'sample_glass',
    label: 'Clear Beverage Jar',
    category: 'Glass',
    thumbnail: '🫙',
    expectedResult: {
      category: 'Glass',
      confidence: 97.2,
      materialDetected: 'Soda-Lime Container Glass (Flint / Clear)',
      disposalBin: 'Teal Glass Reclamation Bin',
      binHex: '#0D9488',
      recyclabilityRate: '100% Infinitely Recyclable without loss of purity',
      recommendedAction: 'Rinse sauces or jams clean. Remove the metal or plastic twist lid and place lid in the appropriate metal/plastic bin.',
      safetyGuidelines: [
        'Do not mix with ceramic mugs, drinking glasses, or window panes',
        'If jar is cracked, wrap securely in newsprint to protect collection workers'
      ],
      ecoPointsEstimated: 12,
      isDemoAnalysis: true,
    },
  },
  {
    id: 'sample_can',
    label: 'Aluminum Beverage Can',
    category: 'Metal',
    thumbnail: '🥫',
    expectedResult: {
      category: 'Metal',
      confidence: 99.0,
      materialDetected: 'Wrought Aluminum Alloy 3004 / 5182',
      disposalBin: 'Yellow Scrap Metal Bin',
      binHex: '#EAB308',
      recyclabilityRate: '100% Recycled with 95% energy savings vs primary bauxite smelting',
      recommendedAction: 'Empty remaining liquid, rinse lightly with cold water, and compress flat.',
      safetyGuidelines: [
        'Leave the pull-tab intact on the can so it does not get lost during mechanical sorting',
        'Never mix aerosol pressurized spray cans without completely discharging propellant'
      ],
      ecoPointsEstimated: 25,
      isDemoAnalysis: true,
    },
  },
  {
    id: 'sample_organic',
    label: 'Vegetable & Fruit Peels',
    category: 'Organic',
    thumbnail: '🥬',
    expectedResult: {
      category: 'Organic',
      confidence: 95.3,
      materialDetected: 'Bio-Degradable Wet Kitchen Biomass',
      disposalBin: 'Lime Green Organic Compost Bin',
      binHex: '#65A30D',
      recyclabilityRate: '100% Aerobic Compostable into nutrient fertilizer',
      recommendedAction: 'Drain excess wet broth or liquid. Place directly into aerated compost bin or biodegradable cellulose bag.',
      safetyGuidelines: [
        'Remove synthetic plastic fruit stickers and rubber bands',
        'Keep separate from non-compostable sanitary waste'
      ],
      ecoPointsEstimated: 8,
      isDemoAnalysis: true,
    },
  },
];

/**
 * Analyzes an uploaded image file or data URI using transparent heuristics.
 * Clearly marked as a Demonstration Computer Vision system.
 */
export async function analyzeWasteImage(
  imageSrc: string,
  fileName?: string
): Promise<WasteAnalysisResult> {
  // Simulate rapid vision tensor processing latency
  await new Promise(resolve => setTimeout(resolve, 850));

  const lowerName = (fileName || '').toLowerCase();

  if (lowerName.includes('bottle') || lowerName.includes('plastic') || lowerName.includes('jug') || lowerName.includes('pet')) {
    return SAMPLE_WASTE_ITEMS[0].expectedResult;
  }
  if (lowerName.includes('box') || lowerName.includes('carton') || lowerName.includes('paper') || lowerName.includes('cardboard')) {
    return SAMPLE_WASTE_ITEMS[1].expectedResult;
  }
  if (lowerName.includes('battery') || lowerName.includes('cell') || lowerName.includes('chemical') || lowerName.includes('spray')) {
    return SAMPLE_WASTE_ITEMS[2].expectedResult;
  }
  if (lowerName.includes('glass') || lowerName.includes('jar') || lowerName.includes('wine')) {
    return SAMPLE_WASTE_ITEMS[3].expectedResult;
  }
  if (lowerName.includes('can') || lowerName.includes('tin') || lowerName.includes('metal') || lowerName.includes('aluminum')) {
    return SAMPLE_WASTE_ITEMS[4].expectedResult;
  }
  if (lowerName.includes('food') || lowerName.includes('peel') || lowerName.includes('vegetable') || lowerName.includes('fruit') || lowerName.includes('organic')) {
    return SAMPLE_WASTE_ITEMS[5].expectedResult;
  }

  // Default heuristic classification for general upload
  return {
    category: 'Plastic',
    confidence: 91.2,
    materialDetected: 'Mixed Thermoplastic Polymers (Identified via optical surface reflection)',
    disposalBin: 'Blue Recyclables Bin',
    binHex: '#2563EB',
    recyclabilityRate: 'Recyclable if segregated clean and dry',
    recommendedAction: 'Clean thoroughly to remove contamination. Segregate from organic or wet domestic refuse.',
    safetyGuidelines: [
      'Ensure material is dry before packaging',
      'Bundle with like materials for efficient depot sorting'
    ],
    ecoPointsEstimated: 15,
    isDemoAnalysis: true,
  };
}
