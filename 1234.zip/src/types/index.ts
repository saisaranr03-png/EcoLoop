/**
 * EcoLoop Core Types & Data Contracts
 */

export type UserRole = 'citizen' | 'collector' | 'recycler' | 'admin';

export type WasteCategory =
  | 'Plastic'
  | 'Paper'
  | 'Glass'
  | 'Metal'
  | 'Organic'
  | 'Electronic Waste'
  | 'Hazardous Waste'
  | 'Mixed Waste';

export type CollectionStatus =
  | 'Pending'
  | 'Assigned'
  | 'Accepted'
  | 'On the Way'
  | 'Collected'
  | 'Verified'
  | 'Cancelled';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone: string;
  address: string;
  avatar?: string;
  ecoPoints?: number;
  rating?: number;
  assignedZone?: string;
  facilityName?: string;
}

export interface CollectionRequest {
  id: string;
  trackingNumber: string;
  citizenId: string;
  citizenName: string;
  citizenPhone: string;
  address: string;
  latitude: number;
  longitude: number;
  wasteCategory: WasteCategory;
  estimatedKg: number;
  actualKg?: number;
  photoUrl?: string;
  preferredDate: string;
  timeSlot: string;
  specialInstructions?: string;
  status: CollectionStatus;
  collectorId?: string;
  collectorName?: string;
  recyclerId?: string;
  recyclerName?: string;
  createdAt: string;
  updatedAt: string;
  verifiedAt?: string;
  qrCodeToken: string;
  ecoPointsAwarded?: number;
}

export interface EcoPointsTransaction {
  id: string;
  userId: string;
  type: 'earned' | 'redeemed';
  points: number;
  description: string;
  timestamp: string;
  requestId?: string;
}

export interface RewardItem {
  id: string;
  title: string;
  category: 'Discount Voucher' | 'Eco Merchandise' | 'Tree Planting' | 'Utility Rebate';
  pointsCost: number;
  partnerName: string;
  description: string;
  remainingStock: number;
  image?: string;
  codePrefix: string;
}

export interface RewardRedemption {
  id: string;
  userId: string;
  userName: string;
  rewardId: string;
  rewardTitle: string;
  pointsSpent: number;
  voucherCode: string;
  redeemedAt: string;
  status: 'Active' | 'Used' | 'Expired';
}

export interface RecyclingCentre {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  phone: string;
  email: string;
  openHours: string;
  acceptedCategories: WasteCategory[];
  currentCapacityKg: number;
  maxCapacityKg: number;
  status: 'Open' | 'Operating' | 'Maintenance';
  efficiencyRating: number;
  facilityType: 'MRF (Material Recovery Facility)' | 'Compost Center' | 'E-Waste Recycler' | 'Glass Works';
}

export interface CommunityChallenge {
  id: string;
  title: string;
  category: WasteCategory | 'All Categories';
  targetKg: number;
  currentKg: number;
  participantsCount: number;
  rewardPoints: number;
  deadline: string;
  badgeName: string;
  description: string;
  isJoined?: boolean;
}

export interface WasteGuideItem {
  id: string;
  name: string;
  category: WasteCategory;
  binColor: string;
  recyclability: '100% Recyclable' | 'Special Handling' | 'Compostable' | 'Hazardous Drop-off';
  instructions: string;
  dos: string[];
  donts: string[];
  safetyWarning?: string;
}

export interface WasteAnalysisResult {
  category: WasteCategory;
  confidence: number;
  materialDetected: string;
  disposalBin: string;
  binHex: string;
  recyclabilityRate: string;
  recommendedAction: string;
  safetyGuidelines: string[];
  ecoPointsEstimated: number;
  isDemoAnalysis?: boolean;
}
