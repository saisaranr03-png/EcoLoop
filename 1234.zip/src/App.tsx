/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { UserRole } from './types';
import { store } from './services/store';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { CitizenDashboard } from './components/CitizenDashboard';
import { CollectorDashboard } from './components/CollectorDashboard';
import { RecyclingCentreDashboard } from './components/RecyclingCentreDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { SchedulePickupModal } from './components/SchedulePickupModal';
import { SmartWasteIdentifierModal } from './components/SmartWasteIdentifierModal';

export default function App() {
  const [currentView, setCurrentView] = useState<'landing' | UserRole>('landing');
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [isVisionOpen, setIsVisionOpen] = useState(false);

  useEffect(() => {
    const unsub = store.subscribe(() => {
      // Keep view in sync if role switched via store
      const user = store.getCurrentUser();
      if (currentView !== 'landing' && currentView !== user.role) {
        setCurrentView(user.role);
      }
    });
    return unsub;
  }, [currentView]);

  const handleRoleSelect = (role: UserRole) => {
    store.switchRole(role);
    setCurrentView(role);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-neutral-50/70 text-neutral-900 flex flex-col font-sans antialiased selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Bar Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={view => {
          setCurrentView(view);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenSchedule={() => setIsScheduleOpen(true)}
        onOpenVision={() => setIsVisionOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {currentView === 'landing' && (
          <LandingPage
            onSelectRole={handleRoleSelect}
            onOpenSchedule={() => setIsScheduleOpen(true)}
            onOpenVision={() => setIsVisionOpen(true)}
          />
        )}

        {currentView === 'citizen' && <CitizenDashboard />}

        {currentView === 'collector' && <CollectorDashboard />}

        {currentView === 'recycler' && <RecyclingCentreDashboard />}

        {currentView === 'admin' && <AdminDashboard />}
      </main>

      {/* Global Shared Modals */}
      <SchedulePickupModal
        isOpen={isScheduleOpen}
        onClose={() => setIsScheduleOpen(false)}
        onSuccess={() => {
          // If in landing page, route to citizen dashboard
          if (currentView === 'landing') {
            handleRoleSelect('citizen');
          }
        }}
      />

      <SmartWasteIdentifierModal
        isOpen={isVisionOpen}
        onClose={() => setIsVisionOpen(false)}
        onScheduleForCategory={cat => {
          setIsScheduleOpen(true);
        }}
      />
    </div>
  );
}
